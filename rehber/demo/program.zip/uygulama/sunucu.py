#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Öğrenci Rehberlik Takip Sistemi — sunucu
=========================================

Tek kullanıcılı, yerel çalışan; Python standart kütüphanesi dışında hiçbir
şey gerektirmeyen (pypdf hariç — o da bu klasörün içinde "kutuphane/pypdf"
altında birlikte gelir, ayrıca kurulum gerekmez) basit bir HTTP sunucusu.

Veri, "veri/" klasöründe öğrenci başına bir JSON dosyası olarak tutulur.
Her yazma işlemi atomiktir (geçici dosyaya yazılır, sonra tek hamlede
yerine konur) — program veya bilgisayar aniden kapansa bile yarım yazılmış
bir dosya kalmaz.

Bu dosyayı elle çalıştırmak yerine üst klasördeki Baslat.bat / Baslat.command
kullanılmalıdır; onlar bu dosyayı doğru Python ile başlatıp tarayıcıyı açar.
"""

import os
import re
import io
import csv
import sys
import json
import time
import uuid
import socket
import shutil
import hashlib
import secrets
import zipfile
import getpass
import platform
import threading
import unicodedata
import subprocess
import webbrowser
import xml.etree.ElementTree as ET
from datetime import datetime, date, timedelta
from urllib.parse import urlparse, parse_qs, unquote
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SURUM = "3.4"

# ---------------------------------------------------------------- yayın bilgileri
# Kullanım koşulları metni değişirse KOSUL_SURUMU artırılır; program açılışta
# kullanıcıdan koşulları yeniden kabul etmesini ister (web/kullanim-kosullari.html).
KOSUL_SURUMU = "1.0"
# "Hakkında" bölümünde görünen geliştirici bilgileri. Boş bırakılan alanlar gösterilmez.
GELISTIRICI = {
    "ad": "",        # ör. geliştiricinin adı ya da marka adı
    "web": "",       # ör. https://www.siteniz.com
    "eposta": "",    # ör. iletisim@siteniz.com
}

# ---------------------------------------------------------------- yollar

BASE = os.path.dirname(os.path.abspath(__file__))          # .../uygulama
KOK = os.path.dirname(BASE)                                 # proje kökü
WEB = os.path.join(BASE, "web")
KUTUPHANE = os.path.join(BASE, "kutuphane")
VERI = os.path.join(KOK, "veri")
OGRENCI_DIZIN = os.path.join(VERI, "ogrenciler")
YEDEK_DIZIN = os.path.join(VERI, "yedek")

os.makedirs(OGRENCI_DIZIN, exist_ok=True)
os.makedirs(YEDEK_DIZIN, exist_ok=True)

if os.path.isdir(KUTUPHANE) and KUTUPHANE not in sys.path:
    sys.path.insert(0, KUTUPHANE)

AYARLAR_YOLU = os.path.join(VERI, "ayarlar.json")
ETIKETLER_YOLU = os.path.join(VERI, "etiketler.json")
SINIFLAR_YOLU = os.path.join(VERI, "siniflar.json")
LISANS_YOLU = os.path.join(VERI, "lisans.json")
ETKINLIK_TURLERI_YOLU = os.path.join(VERI, "etkinlik-turleri.json")
SINIF_ETKINLIKLERI_YOLU = os.path.join(VERI, "sinif-etkinlikleri.json")
TOPLANTI_TURLERI_YOLU = os.path.join(VERI, "toplanti-turleri.json")
TOPLANTILAR_YOLU = os.path.join(VERI, "toplantilar.json")
OKUL_LOGO_YOLU = os.path.join(VERI, "okul-logo.png")
OKUL_LOGO_AZAMI = 3 * 1024 * 1024   # 3 MB


def okul_logo_surum():
    """Logo yoksa 0, varsa önbellek kırmak için değişiklik zamanı."""
    try:
        return int(os.path.getmtime(OKUL_LOGO_YOLU))
    except OSError:
        return 0


def okul_logo_yaz(veri_url):
    """Tarayıcıda PNG'ye çevrilmiş logoyu (data:image/png;base64,...) veri/ klasörüne yazar."""
    import base64
    m = re.match(r"^data:image/png;base64,(.+)$", veri_url or "", re.S)
    if not m:
        raise ValueError("Logo PNG biçiminde gönderilmelidir.")
    ham = base64.b64decode(m.group(1))
    if not ham.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Geçersiz resim dosyası.")
    if len(ham) > OKUL_LOGO_AZAMI:
        raise ValueError("Logo dosyası çok büyük (en fazla 3 MB).")
    os.makedirs(VERI, exist_ok=True)
    gecici = OKUL_LOGO_YOLU + ".tmp"
    with open(gecici, "wb") as f:
        f.write(ham)
    os.replace(gecici, OKUL_LOGO_YOLU)
    return okul_logo_surum()

# ---------------------------------------------------------------- sabit seçenekler
# (Gerçek MEB Öğrenci / Veli Görüşme Formu'ndaki seçenekler birebir)

BASVURMA_SECENEKLERI = [
    "Kendi İsteğiyle", "Öğretmenin İsteğiyle", "Velisinin İsteğiyle",
    "Arkadaş İsteğiyle", "Okul İdaresinin İsteğiyle", "Diğer",
]
KONU_SECENEKLERI = [
    "Sağlıkla İlgili Konular", "Sosyoekonomik Konular", "Yöneltme ve Yerleştirme",
    "Akademik Konular", "Sosyal Uyum", "Davranış Sorunu",
    "Okula ve Çevreye Uyum", "Ailevi Konular", "Psikolojik Uyum", "Diğer",
]
CALISMA_SECENEKLERI = [
    "Kişisel Rehberlik", "Eğitsel Rehberlik", "Mesleki Rehberlik",
    "Bireysel Psikolojik Danışma",
]
KURUM_SECENEKLERI = ["RAM", "HAST.", "ASPİM", "STK", "ÇİM", "Diğer"]
ETIKET_RENKLERI = ["mavi", "turkuaz", "yesil", "acikyesil", "hardal", "turuncu",
                   "mercan", "kirmizi", "pembe", "mor", "kahverengi", "gri"]

VARSAYILAN_AYARLAR = {
    "okulAdi": "", "ilceIl": "", "rehberAdSoyad": "", "unvan": "Rehber Öğretmen",
}
VARSAYILAN_ETIKETLER = [
    {"ad": "Kaynaştırma", "renk": "mavi"},
    {"ad": "Öksüz / Yetim", "renk": "turuncu"},
    {"ad": "Devamsızlık Riski", "renk": "kirmizi"},
    {"ad": "Maddi Destek İhtiyacı", "renk": "yesil"},
    {"ad": "Üstün Yetenek", "renk": "mor"},
]

GUN_ADI_KISA = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"]
AY_ADI = ["", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
          "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]

# ---------------------------------------------------------------- Türkçe yardımcılar

TR_HARF = str.maketrans({
    "İ": "i", "I": "i", "ı": "i", "Ş": "s", "ş": "s", "Ğ": "g", "ğ": "g",
    "Ü": "u", "ü": "u", "Ö": "o", "ö": "o", "Ç": "c", "ç": "c",
})
TR_KUCUK_MAP = {"İ": "i", "I": "ı", "Ç": "ç", "Ğ": "ğ", "Ö": "ö", "Ş": "ş", "Ü": "ü"}
TR_BUYUK_MAP = {"i": "İ", "ı": "I", "ç": "Ç", "ğ": "Ğ", "ö": "Ö", "ş": "Ş", "ü": "Ü"}


def normalize(metin):
    """Türkçe karakterleri sadeleştirip küçük harfe çevirir (arama için)."""
    if not metin:
        return ""
    metin = str(metin).translate(TR_HARF).lower()
    metin = unicodedata.normalize("NFKD", metin)
    metin = "".join(c for c in metin if not unicodedata.combining(c))
    return metin


def tr_kucuk(s):
    return "".join(TR_KUCUK_MAP.get(c, c.lower()) for c in (s or ""))


def tr_kelime_buyut(w):
    if not w:
        return w
    k = tr_kucuk(w)
    ilk = TR_BUYUK_MAP.get(k[0], k[0].upper())
    return ilk + k[1:]


def tr_baslik(s):
    """'ADI SOYADI' -> 'Adı Soyadı' (Türkçe İ/I kurallarına uygun)."""
    if not s:
        return ""
    parcalar = re.split(r"(\s+|-)", str(s).strip())
    return "".join(tr_kelime_buyut(p) if p.strip() and p not in ("-",) else p
                   for p in parcalar)


def tarih_coz(s):
    """'18.09.2026' veya '2026-09-18' kabul eder, date döndürür."""
    if not s:
        return None
    s = str(s).strip()
    for kalip in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s, kalip).date()
        except ValueError:
            continue
    return None


def tarih_yaz(d):
    return d.strftime("%d.%m.%Y") if d else ""


def bugun():
    return date.today()


def simdi_iso():
    return datetime.now().isoformat(timespec="seconds")


def simdi_goster():
    return datetime.now().strftime("%d.%m.%Y %H:%M")


def yeni_id():
    return uuid.uuid4().hex[:20]


def kullanici_adi():
    try:
        return getpass.getuser()
    except Exception:
        return "kullanıcı"


def guvenli_sinif_no(id_):
    return re.sub(r"[^a-zA-Z0-9_-]", "", str(id_ or ""))[:40]


# ---------------------------------------------------------------- atomik JSON okuma/yazma

_kilit = threading.RLock()


def atomik_yaz(yol, veri):
    dizin = os.path.dirname(yol)
    os.makedirs(dizin, exist_ok=True)
    gecici = yol + ".gecici-" + uuid.uuid4().hex
    with open(gecici, "w", encoding="utf-8") as f:
        json.dump(veri, f, ensure_ascii=False, indent=1)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    for deneme in range(4):
        try:
            os.replace(gecici, yol)
            return
        except OSError:
            if deneme < 3:
                time.sleep(0.15 * (deneme + 1))
            else:
                raise


def guvenli_oku(yol, varsayilan):
    if not os.path.exists(yol):
        return varsayilan
    try:
        with open(yol, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return varsayilan


# ---------------------------------------------------------------- öğrenci veri katmanı
#
# Bellek-içi önbellek: tüm öğrenci kayıtları program açılışında okunur ve
# bellekte tutulur; her yazma işlemi hem diske hem önbelleğe aynı anda
# yazılır. Tek kullanıcılı/yerel bir uygulama olduğundan (DavaTakip'in ortak
# ağ sürücüsü senaryosunun aksine) dosya sisteminin dışarıdan değiştirilme
# ihtimali yoktur; bu yüzden karmaşık çok-kullanıcılı çakışma denetimine
# gerek yoktur — yine de her kayıt kendi dosyasında tutulur ve yazma atomik
# yapılır (ani kapanmaya karşı).

_ogrenciler = {}   # id -> kayıt (dict)


def _ogrenci_yolu(id_):
    return os.path.join(OGRENCI_DIZIN, guvenli_sinif_no(id_) + ".json")


def ogrencileri_yukle():
    with _kilit:
        _ogrenciler.clear()
        if not os.path.isdir(OGRENCI_DIZIN):
            return
        for ad in os.listdir(OGRENCI_DIZIN):
            if not ad.endswith(".json"):
                continue
            yol = os.path.join(OGRENCI_DIZIN, ad)
            k = guvenli_oku(yol, None)
            if k and k.get("id"):
                _ogrenciler[k["id"]] = k


def tum_ogrenciler():
    with _kilit:
        return list(_ogrenciler.values())


def ogrenci_oku(id_):
    with _kilit:
        k = _ogrenciler.get(id_)
        return json.loads(json.dumps(k)) if k else None


def ogrenci_yaz(kayit):
    kayit["guncelleme"] = simdi_iso()
    with _kilit:
        atomik_yaz(_ogrenci_yolu(kayit["id"]), kayit)
        _ogrenciler[kayit["id"]] = kayit


def ogrenci_sil(id_):
    with _kilit:
        yol = _ogrenci_yolu(id_)
        if os.path.exists(yol):
            cop = os.path.join(YEDEK_DIZIN, os.path.basename(yol) + "." + str(int(time.time())) + ".silindi")
            try:
                shutil.move(yol, cop)
            except OSError:
                os.remove(yol)
        _ogrenciler.pop(id_, None)


def yeni_ogrenci_kaydi(alanlar):
    k = {
        "id": yeni_id(),
        "okulNo": str(alanlar.get("okulNo") or "").strip(),
        "adSoyad": str(alanlar.get("adSoyad") or "").strip(),
        "sinif": str(alanlar.get("sinif") or "").strip(),
        "cinsiyet": alanlar.get("cinsiyet") or "",
        "dogumTarihi": str(alanlar.get("dogumTarihi") or "").strip(),
        "sinifOgretmeni": str(alanlar.get("sinifOgretmeni") or "").strip(),
        "veliAdSoyad": str(alanlar.get("veliAdSoyad") or "").strip(),
        "veliYakinlik": str(alanlar.get("veliYakinlik") or "").strip(),
        "veliTelefon": str(alanlar.get("veliTelefon") or "").strip(),
        "etiketler": list(alanlar.get("etiketler") or []),
        "genelNot": "",
        "olusturma": simdi_iso(),
        "guncelleme": simdi_iso(),
        "gorusmeler": [],
        "zamanlamalar": [],
        "yorumlar": [],
    }
    return k


# ---------------------------------------------------------------- ayarlar / etiketler / sınıflar

def ayarlar_oku():
    a = dict(VARSAYILAN_AYARLAR)
    a.update(guvenli_oku(AYARLAR_YOLU, {}))
    return a


def ayarlar_yaz(a):
    mevcut = ayarlar_oku()
    mevcut.update(a or {})
    atomik_yaz(AYARLAR_YOLU, mevcut)
    return mevcut


def etiketler_oku():
    e = guvenli_oku(ETIKETLER_YOLU, None)
    if e is None:
        e = [dict(x, id=yeni_id()) for x in VARSAYILAN_ETIKETLER]
        atomik_yaz(ETIKETLER_YOLU, e)
    return e


def etiketler_yaz(e):
    atomik_yaz(ETIKETLER_YOLU, e)


def etiket_sozlugu():
    return {e["id"]: e for e in etiketler_oku()}


def siniflar_oku():
    return guvenli_oku(SINIFLAR_YOLU, {})


def siniflar_yaz(s):
    atomik_yaz(SINIFLAR_YOLU, s)


def sinif_ogretmeni_guncelle(sinif, ogretmen):
    s = siniflar_oku()
    s[sinif] = {"ogretmen": ogretmen}
    siniflar_yaz(s)


# ---------------------------------------------------------------- sınıf etkinlikleri
#
# "Sınıf Etkinliği": rehber öğretmenin önceden planlayarak bir sınıfa (tek bir
# öğrenciye değil) girip yaptığı grup çalışması (örn. "1-A / Rehberlik Tanıtım
# Dersi"). Öğrenci bazlı "zamanlama" kaydından farklı olarak tek bir öğrenciye
# değil doğrudan bir sınıf adına bağlıdır, bu yüzden öğrenci dosyalarının
# içinde değil, kendi başına iki ayrı liste halinde tutulur:
#   - etkinlik-turleri.json  : tanımlı etkinlik türleri (etiketler.json ile aynı
#     mantık — Ayarlar sayfasından veya Sınıf Etkinliği sayfasından eklenir)
#   - sinif-etkinlikleri.json: planlanan/gerçekleşen tekil etkinlik kayıtları

def etkinlik_turleri_oku():
    return guvenli_oku(ETKINLIK_TURLERI_YOLU, [])


def etkinlik_turleri_yaz(e):
    atomik_yaz(ETKINLIK_TURLERI_YOLU, e)


def etkinlik_turu_sozlugu():
    return {e["id"]: e for e in etkinlik_turleri_oku()}


def sinif_etkinlikleri_oku():
    return guvenli_oku(SINIF_ETKINLIKLERI_YOLU, [])


def sinif_etkinlikleri_yaz(e):
    atomik_yaz(SINIF_ETKINLIKLERI_YOLU, e)


def sinif_etkinligi_ozet(se, tur_sozluk):
    tur = tur_sozluk.get(se.get("etkinlikTuruId")) or {}
    d = dict(se)
    d["etkinlikAdi"] = tur.get("ad") or "(silinmiş etkinlik türü)"
    return d


# ---------------------------------------------------------------- toplantılar
def toplanti_turleri_oku():
    return guvenli_oku(TOPLANTI_TURLERI_YOLU, [])


def toplanti_turleri_yaz(t):
    atomik_yaz(TOPLANTI_TURLERI_YOLU, t)


def toplanti_turu_sozlugu():
    return {t["id"]: t for t in toplanti_turleri_oku()}


def toplantilar_oku():
    return guvenli_oku(TOPLANTILAR_YOLU, [])


def toplantilar_yaz(t):
    atomik_yaz(TOPLANTILAR_YOLU, t)


def toplanti_ozet(tp, tur_sozluk):
    tur = tur_sozluk.get(tp.get("toplantiTuruId")) or {}
    d = dict(tp)
    d["toplantiAdi"] = tur.get("ad") or "(silinmiş toplantı türü)"
    return d


def toplanti_saat_metni(tp):
    bas = tp.get("baslangicSaati") or ""
    bit = tp.get("bitisSaati") or ""
    if bas and bit:
        return bas + "–" + bit
    return bas or bit


# ---------------------------------------------------------------- kopya koruma / lisans
#
# Amaç: KVKK kapsamında öğrenci/veli kişisel verilerinin yetkisiz kişilerce
# erişilmesini/kopyalanmasını engellemek — programın izinsiz kopyalanıp başka
# bir bilgisayarda kullanılmasını zorlaştırmak (teknik olarak "kırılamaz" bir
# DRM değil — sadece sıradan bir kopyalamayı caydıran, tamamen çevrimdışı
# çalışan basit bir kontrol).
#
# İlk çalıştırmada kullanıcı bir şifre belirler; bu bilgisayarın donanım
# kimliği ile birlikte veri/lisans.json'a kaydedilir. Aynı bilgisayarda
# program hep serbest çalışır ("yetkili"). Klasör başka bir bilgisayara
# kopyalanırsa donanım kimliği uyuşmaz ve program o bilgisayarda ANINDA
# kilitlenir ("kilitli") — hiçbir tolerans/gecikme süresi yoktur; doğru şifre
# girilmeden hiçbir sayfa veya veri görüntülenemez.

def _makine_kimligi_ham():
    parcalar = [platform.node() or "", str(uuid.getnode())]
    try:
        if os.name == "nt":
            surucu = os.environ.get("SystemDrive", "C:")
            cikti = subprocess.check_output(
                "vol " + surucu, shell=True, text=True, stderr=subprocess.DEVNULL, timeout=5)
            parcalar.append(cikti.strip())
        elif sys.platform == "darwin":
            cikti = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                text=True, stderr=subprocess.DEVNULL, timeout=5)
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', cikti)
            if m:
                parcalar.append(m.group(1))
        else:
            for yol in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                if os.path.exists(yol):
                    with open(yol, "r", encoding="utf-8") as f:
                        parcalar.append(f.read().strip())
                    break
    except Exception:
        pass
    return "|".join(parcalar)


def makine_kimligi():
    return hashlib.sha256(_makine_kimligi_ham().encode("utf-8")).hexdigest()


def _sifre_ozeti(sifre, tuz):
    return hashlib.sha256((tuz + ":" + (sifre or "")).encode("utf-8")).hexdigest()


def lisans_oku():
    if not os.path.exists(LISANS_YOLU):
        return None
    try:
        with open(LISANS_YOLU, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def lisans_yaz(kayit):
    atomik_yaz(LISANS_YOLU, kayit)


def lisans_kur(sifre):
    tuz = secrets.token_hex(16)
    kayit = {
        "tuz": tuz,
        "sifreOzeti": _sifre_ozeti(sifre, tuz),
        "yetkiliMakine": makine_kimligi(),
        "ilkYetkilendirme": simdi_iso(),
    }
    lisans_yaz(kayit)
    return kayit


def lisans_sifre_dogrula(sifre):
    kayit = lisans_oku()
    if not kayit:
        return False
    return _sifre_ozeti(sifre, kayit.get("tuz", "")) == kayit.get("sifreOzeti")


def lisans_coz(sifre):
    """Doğru şifre girilirse BU bilgisayarı yeni yetkili makine yapar."""
    if not lisans_sifre_dogrula(sifre):
        return False
    kayit = lisans_oku()
    kayit["yetkiliMakine"] = makine_kimligi()
    lisans_yaz(kayit)
    return True


def lisans_sifre_degistir(eski_sifre, yeni_sifre):
    if not lisans_sifre_dogrula(eski_sifre):
        return False
    kayit = lisans_oku()
    tuz = secrets.token_hex(16)
    kayit["tuz"] = tuz
    kayit["sifreOzeti"] = _sifre_ozeti(yeni_sifre, tuz)
    lisans_yaz(kayit)
    return True


def lisans_durum():
    kayit = lisans_oku()
    if not kayit:
        return {"durum": "yok"}
    if kayit.get("yetkiliMakine") == makine_kimligi():
        return {"durum": "yetkili"}
    return {"durum": "kilitli"}


_LISANS_SERBEST_API = (
    "/api/lisans/durum", "/api/lisans/kur", "/api/lisans/coz", "/api/lisans/sifre-degistir",
)


def _lisans_statik_serbest_mi(yol):
    if yol in ("/web/lisans-kur.html", "/web/lisans-kilit.html", "/web/ortak.js",
               "/web/kullanim-kosullari.html",
               "/web/stil.css", "/web/tasarim.css", "/web/koyu.css", "/web/tema.js",
               "/favicon.ico"):
        return True
    if yol.startswith("/web/assets/"):
        return True
    return yol in _LISANS_SERBEST_API


# ---------------------------------------------------------------- hesaplanan alanlar

def gorusme_sirasi_ata(kayit):
    """Görüşmeleri tarihe göre kronolojik sıralar, her birine 'sira' atar."""
    def anahtar(g):
        d = tarih_coz(g.get("tarih")) or date.min
        return (d, g.get("olusturma") or "")
    sirali = sorted(kayit.get("gorusmeler") or [], key=anahtar)
    for i, g in enumerate(sirali, start=1):
        g["sira"] = i
    return kayit


def ogrenci_ozet(kayit, etiket_sozluk=None):
    etiket_sozluk = etiket_sozluk if etiket_sozluk is not None else etiket_sozlugu()
    gorusmeler = kayit.get("gorusmeler") or []
    tarihler = [tarih_coz(g.get("tarih")) for g in gorusmeler if tarih_coz(g.get("tarih"))]
    son = max(tarihler) if tarihler else None
    return {
        "id": kayit["id"],
        "okulNo": kayit.get("okulNo", ""),
        "adSoyad": kayit.get("adSoyad", ""),
        "sinif": kayit.get("sinif", ""),
        "cinsiyet": kayit.get("cinsiyet", ""),
        "etiketler": [etiket_sozluk[e] for e in (kayit.get("etiketler") or []) if e in etiket_sozluk],
        "toplamGorusme": len(gorusmeler),
        "sonGorusme": tarih_yaz(son),
        "_sonGorusmeTarih": son,
    }


def ogrenci_detay(kayit):
    kayit = gorusme_sirasi_ata(kayit)
    ozet = ogrenci_ozet(kayit)
    d = dict(kayit)
    d["toplamGorusme"] = ozet["toplamGorusme"]
    d["sonGorusme"] = ozet["sonGorusme"]
    d["ogrenciGorusmeSayisi"] = sum(1 for g in kayit.get("gorusmeler") or [] if g.get("tur") == "ogrenci")
    d["veliGorusmeSayisi"] = sum(1 for g in kayit.get("gorusmeler") or [] if g.get("tur") == "veli")
    d["etiketler"] = ozet["etiketler"]
    d["gorusmeler"] = sorted(kayit.get("gorusmeler") or [],
                              key=lambda g: (tarih_coz(g.get("tarih")) or date.min, g.get("olusturma") or ""),
                              reverse=True)
    d["zamanlamalar"] = sorted(kayit.get("zamanlamalar") or [],
                                key=lambda z: (tarih_coz(z.get("tarih")) or date.min, z.get("saat") or ""))
    d["yorumlar"] = sorted(kayit.get("yorumlar") or [], key=lambda y: y.get("olusturma") or "", reverse=True)
    return d


# ---------------------------------------------------------------- arama / listeleme

def ogrenci_arama_metni(kayit):
    parcalar = [kayit.get("adSoyad"), kayit.get("okulNo"), kayit.get("sinif"),
                kayit.get("sinifOgretmeni"), kayit.get("veliAdSoyad")]
    for g in kayit.get("gorusmeler") or []:
        parcalar.append(g.get("notMetin"))
        parcalar.append(g.get("sonucOneri"))
        parcalar.append(g.get("isbirligi"))
    for y in kayit.get("yorumlar") or []:
        parcalar.append(y.get("metin"))
    return normalize(" ".join(p for p in parcalar if p))


def bugunun_hatirlaticilari():
    """Bugün saati olan, tamamlanmamış sınıf etkinlikleri, toplantılar ve öğrenci
    hatırlatmaları — ekranın sağ üstündeki alarm bildirimleri için."""
    bug = bugun()
    liste = []
    tur_s = etkinlik_turu_sozlugu()
    for se in sinif_etkinlikleri_oku():
        if se.get("tamamlandi") or tarih_coz(se.get("tarih")) != bug or not se.get("saat"):
            continue
        liste.append({"tur": "etkinlik", "id": se["id"], "saat": se["saat"], "bitis": "",
                      "baslik": (tur_s.get(se.get("etkinlikTuruId")) or {}).get("ad") or "Sınıf etkinliği",
                      "alt": (se.get("sinif") or "") + " sınıfı" + (" · " + se["aciklama"] if se.get("aciklama") else ""),
                      "url": "sinif-etkinlik.html"})
    top_s = toplanti_turu_sozlugu()
    for tp in toplantilar_oku():
        if tp.get("tamamlandi") or tarih_coz(tp.get("tarih")) != bug or not tp.get("baslangicSaati"):
            continue
        liste.append({"tur": "toplanti", "id": tp["id"], "saat": tp["baslangicSaati"], "bitis": tp.get("bitisSaati") or "",
                      "baslik": (top_s.get(tp.get("toplantiTuruId")) or {}).get("ad") or "Toplantı",
                      "alt": tp.get("aciklama") or "", "url": "toplanti.html"})
    for k in tum_ogrenciler():
        for z in k.get("zamanlamalar") or []:
            if z.get("tamamlandi") or tarih_coz(z.get("tarih")) != bug or not z.get("saat"):
                continue
            liste.append({"tur": "hatirlatma", "id": z["id"], "ogrenciId": k["id"], "saat": z["saat"], "bitis": "",
                          "baslik": z.get("metin") or "Hatırlatma",
                          "alt": (k.get("adSoyad") or "") + (" (" + k["sinif"] + ")" if k.get("sinif") else ""),
                          "url": "dosya.html?id=" + k["id"]})
    liste.sort(key=lambda x: x["saat"])
    return {"tarih": tarih_yaz(bug), "kayitlar": liste}


def hatirlatici_tamamla(veri):
    """Bildirimden 'Tamamlandı': her zaman tamamlandı yapar (geri almaz)."""
    tur, id_ = veri.get("tur"), veri.get("id")
    if tur == "etkinlik":
        liste = sinif_etkinlikleri_oku()
        for se in liste:
            if se["id"] == id_:
                se["tamamlandi"] = True
                sinif_etkinlikleri_yaz(liste)
                return True
    elif tur == "toplanti":
        liste = toplantilar_oku()
        for tp in liste:
            if tp["id"] == id_:
                tp["tamamlandi"] = True
                toplantilar_yaz(liste)
                return True
    elif tur == "hatirlatma":
        k = ogrenci_oku(veri.get("ogrenciId") or "")
        if k:
            for z in k.get("zamanlamalar") or []:
                if z["id"] == id_:
                    z["tamamlandi"] = True
                    ogrenci_yaz(k)
                    return True
    return False


def toplu_gorusmeler(sorgu):
    """Toplu çıktı: tarih aralığındaki görüşmeleri öğrenci bilgileriyle birlikte döndürür."""
    bas = tarih_coz((sorgu.get("bas", [""])[0] or "").strip())
    bit = tarih_coz((sorgu.get("bit", [""])[0] or "").strip())
    tur = (sorgu.get("tur", [""])[0] or "").strip()
    sinif = (sorgu.get("sinif", [""])[0] or "").strip()
    konu = (sorgu.get("konu", [""])[0] or "").strip()
    if not bas or not bit:
        raise ValueError("Başlangıç ve bitiş tarihi gg.aa.yyyy biçiminde girilmelidir.")
    if bas > bit:
        bas, bit = bit, bas
    sonuc = []
    for k in tum_ogrenciler():
        if sinif and k.get("sinif") != sinif:
            continue
        k = gorusme_sirasi_ata(json.loads(json.dumps(k)))
        ogr = {a: k.get(a) for a in ("id", "adSoyad", "sinif", "cinsiyet", "okulNo", "dogumTarihi", "sinifOgretmeni",
                                     "veliAdSoyad", "veliYakinlik", "veliTelefon")}
        ogr["toplamGorusme"] = len(k.get("gorusmeler") or [])
        for g in k.get("gorusmeler") or []:
            d = tarih_coz(g.get("tarih"))
            if not d or d < bas or d > bit:
                continue
            if tur and g.get("tur") != tur:
                continue
            if konu and konu not in (g.get("konu") or []):
                continue
            sonuc.append({"ogrenci": ogr, "gorusme": g, "_d": d})
    sonuc.sort(key=lambda x: (x["_d"], x["gorusme"].get("saat") or "99:99", normalize(x["ogrenci"]["adSoyad"]),
                              x["gorusme"].get("olusturma") or ""))
    for x in sonuc:
        x.pop("_d", None)
    return {"kayitlar": sonuc, "sayi": len(sonuc), "bas": tarih_yaz(bas), "bit": tarih_yaz(bit)}


def ogrenciler_listele(sorgu):
    q = normalize((sorgu.get("q", [""])[0] or "").strip())
    sinif = (sorgu.get("sinif", [""])[0] or "").strip()
    ogretmen = (sorgu.get("ogretmen", [""])[0] or "").strip()
    durum = (sorgu.get("durum", [""])[0] or "").strip()
    etiket_id = (sorgu.get("etiket", [""])[0] or "").strip()
    konu = (sorgu.get("konu", [""])[0] or "").strip()
    etiket_sozluk = etiket_sozlugu()

    hepsi = tum_ogrenciler()
    sonuc = []
    for k in hepsi:
        if sinif and k.get("sinif") != sinif:
            continue
        if ogretmen and normalize(k.get("sinifOgretmeni")) != normalize(ogretmen):
            continue
        if etiket_id and etiket_id not in (k.get("etiketler") or []):
            continue
        gorusme_sayisi = len(k.get("gorusmeler") or [])
        if durum == "var" and gorusme_sayisi == 0:
            continue
        if durum == "yok" and gorusme_sayisi > 0:
            continue
        if q and q not in ogrenci_arama_metni(k) and q not in normalize(k.get("adSoyad")):
            continue
        konu_sayisi = 0
        if konu:
            konu_sayisi = sum(1 for g in (k.get("gorusmeler") or []) if konu in (g.get("konu") or []))
            if not konu_sayisi:
                continue
        oz = ogrenci_ozet(k, etiket_sozluk)
        if konu:
            oz["konuGorusmeSayisi"] = konu_sayisi
        sonuc.append(oz)

    sonuc.sort(key=lambda x: normalize(x["adSoyad"]))

    bulunan = len(sonuc)
    if (sorgu.get("tumu", [""])[0]) == "1":
        sayfa, toplam_sayfa = 1, 1
        sayfalanmis = sonuc
    else:
        SAYFA_BOYUTU = 10
        toplam_sayfa = max(1, -(-bulunan // SAYFA_BOYUTU))
        try:
            sayfa = int((sorgu.get("sayfa", ["1"])[0]) or "1")
        except ValueError:
            sayfa = 1
        sayfa = max(1, min(sayfa, toplam_sayfa))
        basla = (sayfa - 1) * SAYFA_BOYUTU
        sayfalanmis = sonuc[basla:basla + SAYFA_BOYUTU]
    for s in sayfalanmis:
        s.pop("_sonGorusmeTarih", None)

    siniflar = sorted({k.get("sinif") for k in hepsi if k.get("sinif")})
    ogretmenler = sorted({k.get("sinifOgretmeni") for k in hepsi if k.get("sinifOgretmeni")})

    return {
        "kayitlar": sayfalanmis, "toplam": len(hepsi), "bulunan": bulunan,
        "sayfa": sayfa, "toplamSayfa": toplam_sayfa,
        "siniflar": siniflar, "ogretmenler": ogretmenler,
        "etiketler": etiketler_oku(),
    }


# ---------------------------------------------------------------- panel / gündem / takvim

def panel_verisi():
    hepsi = tum_ogrenciler()
    bug = bugun()
    tum_gorusmeler = []
    for k in hepsi:
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if t:
                tum_gorusmeler.append((t, g, k))

    bugunku = [x for x in tum_gorusmeler if x[0] == bug]
    bugun_ogrenci = sum(1 for t, g, k in bugunku if g.get("tur") == "ogrenci")
    bugun_veli = sum(1 for t, g, k in bugunku if g.get("tur") == "veli")

    ay_toplam = sum(1 for t, g, k in tum_gorusmeler if t.year == bug.year and t.month == bug.month)

    siniflar = {k.get("sinif") for k in hepsi if k.get("sinif")}

    # bu ayın öğrenci/veli dağılımı ve eğitim-öğretim yılı (1 Eylül → bugün) özeti
    ay_ogrenci = sum(1 for t, g, k in tum_gorusmeler
                     if t.year == bug.year and t.month == bug.month and g.get("tur") == "ogrenci")
    ay_veli = sum(1 for t, g, k in tum_gorusmeler
                  if t.year == bug.year and t.month == bug.month and g.get("tur") == "veli")
    yil_bas = date(bug.year if bug.month >= 9 else bug.year - 1, 9, 1)
    yil_gorusmeleri = [(t, g, k) for t, g, k in tum_gorusmeler if yil_bas <= t <= bug]
    yil_ogrenci = sum(1 for t, g, k in yil_gorusmeleri if g.get("tur") == "ogrenci")
    yil_veli = sum(1 for t, g, k in yil_gorusmeleri if g.get("tur") == "veli")
    yil_gorusulen_idler = {k["id"] for t, g, k in yil_gorusmeleri}
    yil_gorusulen = sum(1 for k in hepsi if k["id"] in yil_gorusulen_idler)
    # aynı öğrenciyle birden çok görüşme olabildiği için "görüşme sayısı" ile
    # "farklı öğrenci sayısı" ayrı tutulur
    yil_ogrenci_kisi = len({k["id"] for t, g, k in yil_gorusmeleri if g.get("tur") == "ogrenci"})
    yil_veli_kisi = len({k["id"] for t, g, k in yil_gorusmeleri if g.get("tur") == "veli"})
    _bizzat = {k["id"] for t, g, k in yil_gorusmeleri if g.get("tur") == "ogrenci"}
    yil_yalniz_veli_kisi = len({k["id"] for t, g, k in yil_gorusmeleri
                                if g.get("tur") == "veli" and k["id"] not in _bizzat})

    bekleyen = 0
    for k in hepsi:
        for z in (k.get("zamanlamalar") or []):
            if not z.get("tamamlandi"):
                bekleyen += 1

    son7 = []
    for i in range(6, -1, -1):
        gun = bug - timedelta(days=i)
        sayi = sum(1 for t, g, k in tum_gorusmeler if t == gun)
        son7.append({"tarih": tarih_yaz(gun), "kisaAd": GUN_ADI_KISA[gun.weekday()],
                      "sayi": sayi, "bugunMu": gun == bug})

    konu_sayaci = {}
    for t, g, k in tum_gorusmeler:
        if t.year == bug.year and t.month == bug.month:
            for konu in (g.get("konu") or []):
                konu_sayaci[konu] = konu_sayaci.get(konu, 0) + 1
    konu_dagilim = sorted(konu_sayaci.items(), key=lambda x: -x[1])

    onceki_ay = (date(bug.year, bug.month, 1) - timedelta(days=1))
    # adil karşılaştırma: önceki ayın AYNI gün aralığı (örn. 1–10 Eylül ↔ 1–10 Ekim)
    onceki_ay_toplam = sum(1 for t, g, k in tum_gorusmeler
                           if t.year == onceki_ay.year and t.month == onceki_ay.month and t.day <= bug.day)
    takip = takip_uyarilari()

    son_gorusulenler = sorted(tum_gorusmeler, key=lambda x: (x[0], x[1].get("olusturma") or ""), reverse=True)[:8]
    son_liste = []
    for t, g, k in son_gorusulenler:
        son_liste.append({
            "ogrenciId": k["id"], "adSoyad": k.get("adSoyad"), "sinif": k.get("sinif"),
            "tur": g.get("tur"), "konu": ", ".join(g.get("konu") or []) or "—",
            "tarih": tarih_yaz(t),
        })

    return {
        "bugunToplam": len(bugunku), "bugunOgrenci": bugun_ogrenci, "bugunVeli": bugun_veli,
        "ayToplam": ay_toplam, "ayAdi": AY_ADI[bug.month] + " " + str(bug.year),
        "toplamOgrenci": len(hepsi), "sinifDuzeyi": len(siniflar),
        "bekleyenIzleme": bekleyen,
        "ayOgrenci": ay_ogrenci, "ayVeli": ay_veli,
        "egitimYili": "%d–%d" % (yil_bas.year, yil_bas.year + 1), "yilBaslangic": tarih_yaz(yil_bas),
        "yilToplam": len(yil_gorusmeleri), "yilOgrenci": yil_ogrenci, "yilVeli": yil_veli,
        "yilGorusulenOgrenci": yil_gorusulen, "yilOgrenciKisi": yil_ogrenci_kisi, "yilVeliKisi": yil_veli_kisi, "yilYalnizVeliKisi": yil_yalniz_veli_kisi,
        "kapsamaOrani": round(100.0 * yil_gorusulen / len(hepsi)) if hepsi else 0,
        "son7Gun": son7,
        "konuDagilimi": [{"konu": k, "sayi": s} for k, s in konu_dagilim],
        "sonGorusulenler": son_liste,
        "oncekiAyToplam": onceki_ay_toplam, "oncekiAyAdi": AY_ADI[onceki_ay.month],
        "takipUyarilari": takip[:6], "takipToplam": len(takip), "takipEsikGun": TAKIP_ESIK_GUN,
    }


def gundem_verisi():
    hepsi = tum_ogrenciler()
    bug = bugun()
    ogeler = {}   # tarih(date) -> liste

    def ekle(t, oge):
        ogeler.setdefault(t, []).append(oge)

    for k in hepsi:
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if t == bug:
                tur_ad = "Öğrenci görüşmesi" if g.get("tur") == "ogrenci" else "Veli görüşmesi"
                ekle(t, {
                    "ogrenciId": k["id"], "adSoyad": k.get("adSoyad"), "sinif": k.get("sinif"),
                    "metin": tur_ad + " yapıldı" + ((" — " + g.get("sonucOneri")) if g.get("sonucOneri") else ""),
                    "saat": g.get("saat") or "", "kaynak": "Görüşme Geçmişi",
                })
        for z in (k.get("zamanlamalar") or []):
            if z.get("tamamlandi"):
                continue
            t = tarih_coz(z.get("tarih"))
            if t and t >= bug:
                ekle(t, {
                    "ogrenciId": k["id"], "adSoyad": k.get("adSoyad"), "sinif": k.get("sinif"),
                    "metin": ((z.get("saat") + " — ") if z.get("saat") else "") + z.get("metin"),
                    "saat": z.get("saat") or "", "kaynak": "Zamanlama",
                })

    tur_sozluk = etkinlik_turu_sozlugu()
    for se in sinif_etkinlikleri_oku():
        if se.get("tamamlandi"):
            continue
        t = tarih_coz(se.get("tarih"))
        if not (t and t >= bug):
            continue
        tur = tur_sozluk.get(se.get("etkinlikTuruId")) or {}
        etkinlik_ad = tur.get("ad") or "(silinmiş etkinlik türü)"
        metin = etkinlik_ad + ((" — " + se.get("aciklama")) if se.get("aciklama") else "")
        ekle(t, {
            "etkinlikId": se["id"], "sinif": se.get("sinif") or "—",
            "metin": ((se.get("saat") + " — ") if se.get("saat") else "") + metin,
            "saat": se.get("saat") or "", "kaynak": "Sınıf Etkinliği",
        })

    top_tur_sozluk = toplanti_turu_sozlugu()
    for tp in toplantilar_oku():
        if tp.get("tamamlandi"):
            continue
        t = tarih_coz(tp.get("tarih"))
        if not (t and t >= bug):
            continue
        tur = top_tur_sozluk.get(tp.get("toplantiTuruId")) or {}
        toplanti_ad = tur.get("ad") or "(silinmiş toplantı türü)"
        saat_metni = toplanti_saat_metni(tp)
        metin = toplanti_ad + ((" — " + tp.get("aciklama")) if tp.get("aciklama") else "")
        ekle(t, {
            "toplantiId": tp["id"],
            "metin": ((saat_metni + " — ") if saat_metni else "") + metin,
            "saat": saat_metni, "kaynak": "Toplantı",
        })

    gunler = []
    for t in sorted(ogeler.keys())[:30]:
        fark = (t - bug).days
        if fark == 0:
            baslik = "Bugün · " + str(t.day) + " " + AY_ADI[t.month] + " " + ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"][t.weekday()]
        elif fark == 1:
            baslik = "Yarın · " + str(t.day) + " " + AY_ADI[t.month] + " " + ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"][t.weekday()]
        else:
            baslik = str(t.day) + " " + AY_ADI[t.month] + " " + ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"][t.weekday()]
        gunler.append({
            "tarih": tarih_yaz(t), "baslik": baslik, "gecikmis": fark < 0, "bugunMu": fark == 0,
            "yakinMi": 0 <= fark <= 3,
            "gunKisa": str(t.day), "ayKisa": AY_ADI[t.month][:3] + " " + ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"][t.weekday()],
            "ogeler": ogeler[t],
        })
    return {"gunler": gunler}


def takvim_verisi(yil, ay):
    hepsi = tum_ogrenciler()
    bug = bugun()
    ilk_gun = date(yil, ay, 1)
    if ay == 12:
        sonraki_ay_ilk = date(yil + 1, 1, 1)
    else:
        sonraki_ay_ilk = date(yil, ay + 1, 1)
    ay_gun_sayisi = (sonraki_ay_ilk - ilk_gun).days

    olaylar_gunluk = {}

    def ekle(t, olay):
        if t.year == yil and t.month == ay:
            olaylar_gunluk.setdefault(t.day, []).append(olay)

    for k in hepsi:
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if not t:
                continue
            kisa = (k.get("adSoyad") or "")
            kisa = (kisa.split(" ")[0][:1] + ". " + kisa.split(" ")[-1]) if " " in kisa else kisa
            if g.get("yonlendirilenKurum"):
                sinif = "ram"
                metin = kisa + " — RAM/kurum yönlendirme"
            elif g.get("tur") == "veli":
                sinif = "aile"
                metin = kisa + " — veli görüşmesi"
            else:
                sinif = "izleme"
                metin = kisa + " — görüşme"
            if g.get("saat"):
                metin = g["saat"] + " " + metin
            ekle(t, {"sinif": sinif, "metin": metin, "ogrenciId": k["id"]})
        for z in (k.get("zamanlamalar") or []):
            t = tarih_coz(z.get("tarih"))
            if not t:
                continue
            kisa = (k.get("adSoyad") or "")
            kisa = (kisa.split(" ")[0][:1] + ". " + kisa.split(" ")[-1]) if " " in kisa else kisa
            if z.get("tamamlandi"):
                continue
            sinif = "gecmis" if t < bug else "plan"
            saat_on_ek = (z.get("saat") + " ") if z.get("saat") else ""
            ekle(t, {"sinif": sinif, "metin": saat_on_ek + kisa + " — " + (z.get("metin") or ""), "ogrenciId": k["id"]})

    tur_sozluk = etkinlik_turu_sozlugu()
    for se in sinif_etkinlikleri_oku():
        t = tarih_coz(se.get("tarih"))
        if not t:
            continue
        tamamlandi = bool(se.get("tamamlandi"))
        if tamamlandi:
            continue
        gorunum = "gecmis" if t < bug else "etkinlik"
        tur = tur_sozluk.get(se.get("etkinlikTuruId")) or {}
        etkinlik_ad = tur.get("ad") or "(silinmiş etkinlik türü)"
        saat_on_ek = (se.get("saat") + " ") if se.get("saat") else ""
        metin = saat_on_ek + (se.get("sinif") or "—") + " — " + etkinlik_ad
        ekle(t, {"sinif": gorunum, "metin": metin, "etkinlikId": se["id"]})

    top_tur_sozluk = toplanti_turu_sozlugu()
    for tp in toplantilar_oku():
        t = tarih_coz(tp.get("tarih"))
        if not t:
            continue
        if tp.get("tamamlandi"):
            continue
        gorunum = "gecmis" if t < bug else "toplanti"
        tur = top_tur_sozluk.get(tp.get("toplantiTuruId")) or {}
        toplanti_ad = tur.get("ad") or "(silinmiş toplantı türü)"
        saat_metni = toplanti_saat_metni(tp)
        saat_on_ek = (saat_metni + " ") if saat_metni else ""
        metin = saat_on_ek + toplanti_ad
        ekle(t, {"sinif": gorunum, "metin": metin, "toplantiId": tp["id"]})

    # haftanın ilk günü Pazartesi olacak şekilde ızgara
    bas_bosluk = ilk_gun.weekday()  # 0=Pazartesi
    son_gun = date(yil, ay, ay_gun_sayisi)
    son_bosluk = 6 - son_gun.weekday()

    hucreler = []
    for i in range(bas_bosluk):
        hucreler.append({"disari": True, "gun": None, "olaylar": []})
    for gun in range(1, ay_gun_sayisi + 1):
        t = date(yil, ay, gun)
        hucreler.append({
            "disari": False, "gun": gun, "bugunMu": t == bug,
            # saati olanlar saat sırasıyla önce, saatsizler sonra
            "olaylar": sorted(olaylar_gunluk.get(gun, []),
                              key=lambda o: o["metin"][:5] if re.match(r"\d\d:\d\d", o.get("metin") or "") else "99:99")[:4],
        })
    for i in range(son_bosluk):
        hucreler.append({"disari": True, "gun": None, "olaylar": []})

    return {
        "yil": yil, "ay": ay, "ayAdi": AY_ADI[ay] + " " + str(yil),
        "hucreler": hucreler,
    }


HAFTA_GUN_KISA = ["Pzt", "Sal", "Çar", "Per", "Cum"]


def takvim_hafta_verisi(pazartesi):
    """pazartesi: o haftanın Pazartesi günü (date). Sadece Pazartesi-Cuma (5 gün) döner —
    öğretmenlerin hafta sonunu ayrıca görmesine gerek olmadığı için hafta sonu eklenmez."""
    hepsi = tum_ogrenciler()
    bug = bugun()
    gunler_tarih = [pazartesi + timedelta(days=i) for i in range(5)]
    gun_index = {t: i for i, t in enumerate(gunler_tarih)}
    tum_gun = [[] for _ in range(5)]
    saatli = [[] for _ in range(5)]

    def dakika_coz(saat_str):
        if not saat_str:
            return None
        try:
            sa, dk = saat_str.strip().split(":")
            return int(sa) * 60 + int(dk)
        except (ValueError, AttributeError):
            return None

    def ekle(t, saat_bas, saat_bit, kategori, metin, ekstra=None):
        i = gun_index.get(t)
        if i is None:
            return
        bas_dk = dakika_coz(saat_bas)
        temel = dict(ekstra or {})
        temel["kategori"] = kategori
        temel["metin"] = metin
        if bas_dk is None:
            tum_gun[i].append(temel)
            return
        bit_dk = dakika_coz(saat_bit)
        if not bit_dk or bit_dk <= bas_dk:
            bit_dk = bas_dk + 30
        temel["baslangicDk"] = bas_dk
        temel["bitisDk"] = bit_dk
        temel["saatMetni"] = saat_bas + ((" – " + saat_bit) if saat_bit else "")
        saatli[i].append(temel)

    for k in hepsi:
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if t not in gun_index:
                continue
            kisa = (k.get("adSoyad") or "")
            kisa = (kisa.split(" ")[0][:1] + ". " + kisa.split(" ")[-1]) if " " in kisa else kisa
            if g.get("yonlendirilenKurum"):
                kategori = "ram"
                metin = kisa + " — RAM/kurum yönlendirme"
            elif g.get("tur") == "veli":
                kategori = "aile"
                metin = kisa + " — veli görüşmesi"
            else:
                kategori = "izleme"
                metin = kisa + " — görüşme"
            ekle(t, g.get("saat") or None, None, kategori, metin, {"ogrenciId": k["id"]})
        for z in (k.get("zamanlamalar") or []):
            if z.get("tamamlandi"):
                continue
            t = tarih_coz(z.get("tarih"))
            if t not in gun_index:
                continue
            kisa = (k.get("adSoyad") or "")
            kisa = (kisa.split(" ")[0][:1] + ". " + kisa.split(" ")[-1]) if " " in kisa else kisa
            kategori = "gecmis" if t < bug else "plan"
            ekle(t, z.get("saat") or None, None, kategori, kisa + " — " + (z.get("metin") or ""), {"ogrenciId": k["id"]})

    tur_sozluk = etkinlik_turu_sozlugu()
    for se in sinif_etkinlikleri_oku():
        if se.get("tamamlandi"):
            continue
        t = tarih_coz(se.get("tarih"))
        if t not in gun_index:
            continue
        kategori = "gecmis" if t < bug else "etkinlik"
        tur = tur_sozluk.get(se.get("etkinlikTuruId")) or {}
        etkinlik_ad = tur.get("ad") or "(silinmiş etkinlik türü)"
        metin = (se.get("sinif") or "—") + " — " + etkinlik_ad
        ekle(t, se.get("saat") or None, None, kategori, metin, {"etkinlikId": se["id"]})

    top_tur_sozluk = toplanti_turu_sozlugu()
    for tp in toplantilar_oku():
        if tp.get("tamamlandi"):
            continue
        t = tarih_coz(tp.get("tarih"))
        if t not in gun_index:
            continue
        kategori = "gecmis" if t < bug else "toplanti"
        tur = top_tur_sozluk.get(tp.get("toplantiTuruId")) or {}
        toplanti_ad = tur.get("ad") or "(silinmiş toplantı türü)"
        ekle(t, tp.get("baslangicSaati") or None, tp.get("bitisSaati") or None, kategori, toplanti_ad,
             {"toplantiId": tp["id"]})

    gunler = []
    for i, t in enumerate(gunler_tarih):
        gunler.append({
            "tarih": tarih_yaz(t), "gun": t.day, "ayKisa": AY_ADI[t.month][:3],
            "gunAdiKisa": HAFTA_GUN_KISA[i], "bugunMu": t == bug,
            "tumGunOlaylar": tum_gun[i],
            "saatliOlaylar": sorted(saatli[i], key=lambda o: o["baslangicDk"]),
        })
    return {
        "pazartesi": tarih_yaz(pazartesi), "pazar": tarih_yaz(pazartesi + timedelta(days=6)),
        "baslangicSaat": 8, "bitisSaat": 17, "gunler": gunler,
    }


# ---------------------------------------------------------------- raporlar

def _saat_dk(saat):
    """'13:30' -> 810 (dakika). Geçersizse None."""
    try:
        sa, dk = str(saat or "").split(":")
        return int(sa) * 60 + int(dk)
    except (ValueError, AttributeError):
        return None


TAKIP_ESIK_GUN = 30


def takip_uyarilari(sinif_f="", esik_gun=TAKIP_ESIK_GUN):
    """Etiketi olan (Kaynaştırma, Devamsızlık Riski vb.) ama son `esik_gun` gündür
    hiç görüşülmemiş (veya hiç görüşülmemiş) öğrencileri döndürür. Tarih aralığından
    bağımsızdır — her zaman BUGÜNE göre hesaplanır."""
    bug = bugun()
    etiket_sozluk = etiket_sozlugu()
    sonuc = []
    for k in tum_ogrenciler():
        if sinif_f and k.get("sinif") != sinif_f:
            continue
        etiketler = [etiket_sozluk[e] for e in (k.get("etiketler") or []) if e in etiket_sozluk]
        if not etiketler:
            continue
        tarihler = [tarih_coz(g.get("tarih")) for g in (k.get("gorusmeler") or [])]
        tarihler = [t for t in tarihler if t and t <= bug]
        son = max(tarihler) if tarihler else None
        gecen = (bug - son).days if son else None
        if son is not None and gecen < esik_gun:
            continue
        sonuc.append({
            "ogrenciId": k["id"], "adSoyad": k.get("adSoyad"), "sinif": k.get("sinif"),
            "etiketler": [{"ad": e["ad"], "renk": e.get("renk") or "mavi"} for e in etiketler],
            "sonGorusme": tarih_yaz(son) if son else "", "gecenGun": gecen,
        })
    # hiç görüşülmeyenler en üstte, sonra en uzun süredir görüşülmeyenler
    sonuc.sort(key=lambda x: (x["gecenGun"] is not None, -(x["gecenGun"] or 0), x["adSoyad"] or ""))
    return sonuc


def raporlar_verisi(sorgu):
    hepsi = tum_ogrenciler()
    bas = tarih_coz((sorgu.get("baslangic", [""])[0] or "")) or date(bugun().year, 1, 1)
    bit = tarih_coz((sorgu.get("bitis", [""])[0] or "")) or bugun()
    sinif_f = (sorgu.get("sinif", [""])[0] or "").strip()
    konu_f = (sorgu.get("konu", [""])[0] or "").strip()
    tur_f = (sorgu.get("tur", [""])[0] or "").strip()

    kayitlar = []
    for k in hepsi:
        if sinif_f and k.get("sinif") != sinif_f:
            continue
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if not t or not (bas <= t <= bit):
                continue
            if tur_f and g.get("tur") != tur_f:
                continue
            if konu_f and konu_f not in (g.get("konu") or []):
                continue
            kayitlar.append((t, g, k))

    toplam = len(kayitlar)
    ogr_sayisi = sum(1 for t, g, k in kayitlar if g.get("tur") == "ogrenci")
    veli_sayisi = sum(1 for t, g, k in kayitlar if g.get("tur") == "veli")

    # aylık trend: eğitim-öğretim yılına göre sabit pencere (Eylül → Temmuz, 11 ay).
    # Hangi eğitim-öğretim yılı gösterileceği rapor bitiş tarihine (bit) göre belirlenir
    # (frontend'deki yilBasiDD() ile aynı kural: Ağustos ve sonrası o yılın Eylül'ünden
    # başlayan dönemi, Ocak-Temmuz ise bir önceki yılın Eylül'ünden başlayan dönemi gösterir).
    aylik = []
    akademik_bas_yili = bit.year if bit.month >= 8 else bit.year - 1
    ay_listesi = []
    for i in range(11):
        yy, mm = akademik_bas_yili, 9 + i
        if mm > 12:
            mm -= 12
            yy += 1
        ay_listesi.append((yy, mm))
    for yy, mm in ay_listesi:
        sayi = sum(1 for t, g, k in
                    [(tarih_coz(g2.get("tarih")), g2, k2)
                     for k2 in hepsi for g2 in (k2.get("gorusmeler") or [])]
                    if t and t.year == yy and t.month == mm)
        aylik.append({"ay": AY_ADI[mm], "yil": yy, "sayi": sayi})

    konu_sayaci = {}
    for t, g, k in kayitlar:
        for konu in (g.get("konu") or []):
            konu_sayaci[konu] = konu_sayaci.get(konu, 0) + 1
    konu_dagilim = sorted(konu_sayaci.items(), key=lambda x: -x[1])

    sinif_sayaci = {}
    for t, g, k in kayitlar:
        s = k.get("sinif") or "—"
        sinif_sayaci[s] = sinif_sayaci.get(s, 0) + 1
    sinif_dagilim = sorted(sinif_sayaci.items(), key=lambda x: -x[1])

    etiket_sozluk = etiket_sozlugu()
    etiket_ogrenci = {}
    for t, g, k in kayitlar:
        for eid in (k.get("etiketler") or []):
            etiket_ogrenci.setdefault(eid, set()).add(k["id"])
    etiket_dagilim = sorted(
        [(etiket_sozluk[eid]["ad"], len(ids), etiket_sozluk[eid].get("renk") or "mavi")
         for eid, ids in etiket_ogrenci.items() if eid in etiket_sozluk],
        key=lambda x: -x[1])

    kurum_sayaci = {}
    kurum_ogrenci = {}
    for t, g, k in kayitlar:
        for kurum in (g.get("yonlendirilenKurum") or []):
            kurum_sayaci[kurum] = kurum_sayaci.get(kurum, 0) + 1
            kurum_ogrenci.setdefault(kurum, set()).add(k["id"])
    kurum_dagilim = sorted(kurum_sayaci.items(), key=lambda x: -x[1])
    yonlendirilenToplamOgrenci = len(set().union(*kurum_ogrenci.values())) if kurum_ogrenci else 0

    # ---- kayıtlı öğrenci sayısı: tarih aralığından bağımsız, sadece sınıf
    # filtresine uyar (Panel'deki "Toplam Öğrenci Dosyası" ile aynı mantık) ----
    kayitli_ogrenciler = [k for k in hepsi if not sinif_f or k.get("sinif") == sinif_f]
    toplam_ogrenci_dosyasi = len(kayitli_ogrenciler)
    sinif_duzeyi = len({k.get("sinif") for k in hepsi if k.get("sinif")})

    # ---- etiket x sınıf matrisi: her sınıfta hangi etiketten kaç öğrenci var
    # (görüşme tarihinden bağımsız — mevcut öğrenci kayıtlarının tamamına göre) ----
    tum_etiketler = etiketler_oku()
    matris_sayac = {}   # sinif -> etiket_id -> sayi
    for k in kayitli_ogrenciler:
        s = k.get("sinif") or "—"
        for eid in (k.get("etiketler") or []):
            if eid not in etiket_sozluk:
                continue
            matris_sayac.setdefault(s, {})
            matris_sayac[s][eid] = matris_sayac[s].get(eid, 0) + 1
    kullanilan_etiketler = [e for e in tum_etiketler if any(eid == e["id"] for satir in matris_sayac.values() for eid in satir)]
    etiket_matrisi = {
        "etiketler": [{"id": e["id"], "ad": e["ad"], "renk": e.get("renk")} for e in kullanilan_etiketler],
        "satirlar": [
            {
                "sinif": s,
                "toplamOgrenci": sum(1 for k in kayitli_ogrenciler if (k.get("sinif") or "—") == s),
                "sayilar": matris_sayac.get(s, {}),
            }
            for s in sorted(matris_sayac.keys())
        ],
    }

    # ---- yapılan sınıf etkinlikleri x sınıf matrisi (solda etkinlik adı,
    # sağda sınıf adı) — rapor tarih aralığına göre, yalnızca TAMAMLANDI
    # işaretlenmiş etkinlikleri sayar; açıkta (tamamlanmamış) olanlar tarih
    # aralığından bağımsız ayrı bir sayaç olarak bildirilir ----
    tum_etkinlik_turleri = etkinlik_turleri_oku()
    etkinlik_matris_sayac = {}   # etkinlikTuruId -> sinif -> sayi
    yapilan_sinif_etkinligi = 0
    acik_sinif_etkinligi = 0
    for se in sinif_etkinlikleri_oku():
        s = se.get("sinif") or "—"
        if sinif_f and s != sinif_f:
            continue
        if se.get("tamamlandi"):
            t = tarih_coz(se.get("tarih"))
            if not t or not (bas <= t <= bit):
                continue
            yapilan_sinif_etkinligi += 1
            eid = se.get("etkinlikTuruId")
            etkinlik_matris_sayac.setdefault(eid, {})
            etkinlik_matris_sayac[eid][s] = etkinlik_matris_sayac[eid].get(s, 0) + 1
        else:
            acik_sinif_etkinligi += 1
    kullanilan_turler = [e for e in tum_etkinlik_turleri if e["id"] in etkinlik_matris_sayac]
    sinif_etkinlik_matrisi = {
        "siniflar": sorted({k.get("sinif") for k in hepsi if k.get("sinif")}),
        "satirlar": [
            {
                "etkinlikAdi": e["ad"],
                "toplam": sum(etkinlik_matris_sayac.get(e["id"], {}).values()),
                "sayilar": etkinlik_matris_sayac.get(e["id"], {}),
            }
            for e in kullanilan_turler
        ],
    }

    # ---- KAPSAMA: kayıtlı öğrencilerin kaçıyla bu dönemde en az bir görüşme yapıldı ----
    gorusulen_idler = {k["id"] for t, g, k in kayitlar}
    kapsama_siniflar = []
    for s_ad in sorted({k.get("sinif") or "—" for k in kayitli_ogrenciler}):
        sinif_ogr = [k for k in kayitli_ogrenciler if (k.get("sinif") or "—") == s_ad]
        gor = sum(1 for k in sinif_ogr if k["id"] in gorusulen_idler)
        kapsama_siniflar.append({"sinif": s_ad, "toplam": len(sinif_ogr), "gorusulen": gor,
                                 "oran": round(100.0 * gor / len(sinif_ogr)) if sinif_ogr else 0})
    gorusulen_sayi = sum(1 for k in kayitli_ogrenciler if k["id"] in gorusulen_idler)
    kapsama = {"toplamOgrenci": len(kayitli_ogrenciler), "gorusulenOgrenci": gorusulen_sayi,
               "oran": round(100.0 * gorusulen_sayi / len(kayitli_ogrenciler)) if kayitli_ogrenciler else 0,
               "siniflar": kapsama_siniflar}

    # ---- BAŞVURU ŞEKLİ ve YAPILAN ÇALIŞMA dağılımı (öğrenci görüşme formundan) ----
    def _sayac(alan):
        say = {}
        for t, g, k in kayitlar:
            if g.get("tur") != "ogrenci":
                continue
            for d in (g.get(alan) or []):
                say[d] = say.get(d, 0) + 1
        return [{"ad": a, "sayi": n} for a, n in sorted(say.items(), key=lambda x: -x[1])]
    basvuru_dagilimi = _sayac("basvurma")
    calisma_dagilimi = _sayac("calisma")

    # ---- ÖNCEKİ DÖNEM: aynı uzunluktaki bir önceki dönemle karşılaştırma ----
    sure = (bit - bas).days + 1
    o_bit = bas - timedelta(days=1)
    o_bas = o_bit - timedelta(days=sure - 1)
    o_toplam = o_ogr = o_veli = 0
    o_gorusulen = set()
    for k in hepsi:
        if sinif_f and k.get("sinif") != sinif_f:
            continue
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if not t or not (o_bas <= t <= o_bit):
                continue
            if tur_f and g.get("tur") != tur_f:
                continue
            if konu_f and konu_f not in (g.get("konu") or []):
                continue
            o_toplam += 1
            o_gorusulen.add(k["id"])
            if g.get("tur") == "ogrenci":
                o_ogr += 1
            elif g.get("tur") == "veli":
                o_veli += 1
    onceki_donem = {"baslangic": tarih_yaz(o_bas), "bitis": tarih_yaz(o_bit),
                    "toplamGorusme": o_toplam, "ogrenciGorusme": o_ogr, "veliGorusme": o_veli,
                    "gorusulenOgrenci": len(o_gorusulen)}

    # ---- TOPLANTI RAPORU: dönemdeki toplantılar türe göre (sayı ve süre) ----
    t_sozluk = toplanti_turu_sozlugu()
    toplanti_sayac = {}
    toplanti_toplam_dk = 0
    toplanti_tamamlanan = 0
    for tp in toplantilar_oku():
        t = tarih_coz(tp.get("tarih"))
        if not t or not (bas <= t <= bit):
            continue
        ad = (t_sozluk.get(tp.get("toplantiTuruId")) or {}).get("ad") or "Diğer"
        kayit = toplanti_sayac.setdefault(ad, {"tur": ad, "adet": 0, "tamamlanan": 0, "dakika": 0})
        kayit["adet"] += 1
        if tp.get("tamamlandi"):
            kayit["tamamlanan"] += 1
            toplanti_tamamlanan += 1
            b1, b2 = _saat_dk(tp.get("baslangicSaati")), _saat_dk(tp.get("bitisSaati"))
            if b1 is not None and b2 is not None and b2 > b1:
                kayit["dakika"] += b2 - b1
                toplanti_toplam_dk += b2 - b1
    toplanti_raporu = {"turler": sorted(toplanti_sayac.values(), key=lambda x: -x["adet"]),
                       "toplamAdet": sum(x["adet"] for x in toplanti_sayac.values()),
                       "tamamlanan": toplanti_tamamlanan, "toplamDakika": toplanti_toplam_dk}

    return {
        "toplamGorusme": toplam, "ogrenciGorusme": ogr_sayisi, "veliGorusme": veli_sayisi,
        "aylikTrend": aylik, "konuDagilimi": [{"konu": k, "sayi": s} for k, s in konu_dagilim],
        "sinifDagilimi": [{"sinif": s, "sayi": n} for s, n in sinif_dagilim],
        "etiketDagilimi": [{"etiket": e, "sayi": n, "renk": r} for e, n, r in etiket_dagilim],
        "kurumDagilimi": [{"kurum": kur, "sayi": s, "ogrenciSayisi": len(kurum_ogrenci.get(kur, ()))}
                           for kur, s in kurum_dagilim],
        "yonlendirilenToplamOgrenci": yonlendirilenToplamOgrenci,
        "toplamOgrenciDosyasi": toplam_ogrenci_dosyasi, "sinifDuzeyi": sinif_duzeyi,
        "etiketMatrisi": etiket_matrisi,
        "sinifEtkinlikMatrisi": sinif_etkinlik_matrisi,
        "yapilanSinifEtkinligi": yapilan_sinif_etkinligi, "acikSinifEtkinligi": acik_sinif_etkinligi,
        "siniflar": sorted({k.get("sinif") for k in hepsi if k.get("sinif")}),
        "kapsama": kapsama, "basvuruDagilimi": basvuru_dagilimi, "calismaDagilimi": calisma_dagilimi,
        "oncekiDonem": onceki_donem, "toplantiRaporu": toplanti_raporu,
        "takipUyarilari": takip_uyarilari(sinif_f), "takipEsikGun": TAKIP_ESIK_GUN,
        "donem": {"baslangic": tarih_yaz(bas), "bitis": tarih_yaz(bit)},
    }


# ---------------------------------------------------------------- OKUL RAPORU (birleşik)
#
# Okulda birden çok rehber öğretmen varsa her biri programı kendi bilgisayarında
# kullanır; birbirlerinin öğrencilerini görmezler. Okul geneli faaliyet raporu için
# her öğretmen "okul raporu paketi" (JSON) dışa aktarır ve başkan öğretmene gönderir.
# Paket İSİMSİZDİR: öğrenci adı, not, özet, telefon, adres içermez. Öğrenciler, okul
# numarasından üretilen geri çözülemeyen bir kodla temsil edilir (aynı öğrenci iki
# pakette görünse bile bir kez sayılsın diye). Paket birikimlidir: tüm veriyi taşır,
# dönemi başkan rapor alırken seçer; aynı kaynaktan gelen yeni paket eskisinin yerine geçer.

OKUL_PAKET_DIZIN = os.path.join(VERI, "okul-paketleri")
OKUL_PAKET_TURU = "rehberlik-okul-raporu-paketi"
OKUL_PAKET_BICIM = 1
DUZEY_SIRA = ["ana", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "diger"]


def duzey_bul(sinif):
    """'Ana/B', 'Anasınıfı-A', '1/A', '1-A', '2. Sınıf / C' -> 'ana', '1', '2' …"""
    n = normalize(sinif or "").strip()
    if not n:
        return "diger"
    if n.startswith("ana") or "anasinif" in n or "anaokul" in n:
        return "ana"
    m = re.match(r"^\s*(\d{1,2})", n)
    if m and 1 <= int(m.group(1)) <= 12:
        return str(int(m.group(1)))
    return "diger"


def duzey_adi(d):
    if d == "ana":
        return "Ana sınıfı"
    if d == "diger":
        return "Diğer"
    return d + ". Sınıf"


def kurulum_kimligi():
    a = ayarlar_oku()
    kid = a.get("kurulumId")
    if not kid:
        kid = uuid.uuid4().hex
        ayarlar_yaz({"kurulumId": kid})
    return kid


def ogrenci_kodu(k):
    no = re.sub(r"\D", "", str(k.get("okulNo") or ""))
    ham = ("no|" + no) if no else ("id|" + str(k.get("id")))
    return hashlib.sha256(("rehberlik-okul|" + ham).encode("utf-8")).hexdigest()[:16]


def _paket_ozeti(paket):
    icerik = {x: paket[x] for x in paket if x != "ozet"}
    return hashlib.sha256(json.dumps(icerik, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def okul_paketi_olustur():
    a = ayarlar_oku()
    esoz = etiket_sozlugu()
    ogrenciler, gorusmeler = [], []
    for k in tum_ogrenciler():
        kod = ogrenci_kodu(k)
        s = (k.get("sinif") or "").strip()
        ogrenciler.append({"k": kod, "s": s,
                           "e": [esoz[e]["ad"] for e in (k.get("etiketler") or []) if e in esoz]})
        for g in (k.get("gorusmeler") or []):
            t = tarih_coz(g.get("tarih"))
            if not t:
                continue
            gorusmeler.append({
                "t": tarih_yaz(t), "tur": g.get("tur") or "", "k": kod, "s": s,
                "konu": list(g.get("konu") or []), "basvurma": list(g.get("basvurma") or []),
                "calisma": list(g.get("calisma") or []), "kurum": list(g.get("yonlendirilenKurum") or []),
            })
    etsoz = etkinlik_turu_sozlugu()
    etkinlikler = []
    for se in sinif_etkinlikleri_oku():
        t = tarih_coz(se.get("tarih"))
        if not t:
            continue
        etkinlikler.append({"t": tarih_yaz(t), "s": (se.get("sinif") or "").strip(),
                            "ad": (etsoz.get(se.get("etkinlikTuruId")) or {}).get("ad") or "Diğer",
                            "tamam": bool(se.get("tamamlandi"))})
    tsoz = toplanti_turu_sozlugu()
    toplantilar = []
    for tp in toplantilar_oku():
        t = tarih_coz(tp.get("tarih"))
        if not t:
            continue
        b1, b2 = _saat_dk(tp.get("baslangicSaati")), _saat_dk(tp.get("bitisSaati"))
        toplantilar.append({"t": tarih_yaz(t), "ad": (tsoz.get(tp.get("toplantiTuruId")) or {}).get("ad") or "Diğer",
                            "tamam": bool(tp.get("tamamlandi")),
                            "dk": (b2 - b1) if (b1 is not None and b2 is not None and b2 > b1) else 0})
    paket = {
        "tur": OKUL_PAKET_TURU, "bicim": OKUL_PAKET_BICIM, "programSurumu": SURUM,
        "kaynakId": kurulum_kimligi(), "ogretmen": a.get("rehberAdSoyad") or "",
        "unvan": a.get("unvan") or "", "okulAdi": a.get("okulAdi") or "",
        "olusturma": datetime.now().strftime("%d.%m.%Y %H:%M"),
        "ogrenciler": ogrenciler, "gorusmeler": gorusmeler,
        "etkinlikler": etkinlikler, "toplantilar": toplantilar,
    }
    paket["ozet"] = _paket_ozeti(paket)
    return paket


def _paket_zamani(p):
    try:
        return datetime.strptime(p.get("olusturma") or "", "%d.%m.%Y %H:%M")
    except ValueError:
        return datetime.min


def _paket_yolu(kaynak_id):
    if not re.match(r"^[0-9a-f]{32}$", kaynak_id or ""):
        raise ValueError("Geçersiz paket kimliği.")
    return os.path.join(OKUL_PAKET_DIZIN, kaynak_id + ".json")


def okul_paketi_ekle(paket):
    if not isinstance(paket, dict) or paket.get("tur") != OKUL_PAKET_TURU:
        raise ValueError("Bu dosya bir okul raporu paketi değil. Öğretmenin Okul Raporu sayfasından "
                         "\"Paketimi indir\" ile aldığı .json dosyasını seçin.")
    if int(paket.get("bicim") or 0) > OKUL_PAKET_BICIM:
        raise ValueError("Bu paket programın daha yeni bir sürümüyle oluşturulmuş. Lütfen programınızı güncelleyin.")
    if paket.get("ozet") != _paket_ozeti(paket):
        raise ValueError("Paket bozulmuş ya da elle değiştirilmiş görünüyor. Öğretmenden paketi yeniden göndermesini isteyin.")
    for alan in ("ogrenciler", "gorusmeler", "etkinlikler", "toplantilar"):
        if not isinstance(paket.get(alan), list):
            raise ValueError("Paket eksik ya da hatalı (%s)." % alan)
    kid = paket.get("kaynakId") or ""
    if kid == kurulum_kimligi():
        raise ValueError("Bu paket bu bilgisayarda oluşturulmuş. Kendi verileriniz rapora zaten otomatik olarak eklenir.")
    yol = _paket_yolu(kid)
    with _kilit:
        eski = guvenli_oku(yol, None)
        if eski and _paket_zamani(eski) > _paket_zamani(paket):
            raise ValueError("Bu kaynaktan daha yeni bir paket (%s) zaten yüklü; eski paket yüklenmedi." % eski.get("olusturma"))
        atomik_yaz(yol, paket)
    return {"guncellendi": bool(eski), "ogretmen": paket.get("ogretmen") or "", "olusturma": paket.get("olusturma")}


def _yuklu_paketler():
    sonuc = []
    if os.path.isdir(OKUL_PAKET_DIZIN):
        for ad in sorted(os.listdir(OKUL_PAKET_DIZIN)):
            if ad.endswith(".json"):
                p = guvenli_oku(os.path.join(OKUL_PAKET_DIZIN, ad), None)
                if isinstance(p, dict) and p.get("tur") == OKUL_PAKET_TURU:
                    sonuc.append(p)
    return sonuc


def _paket_bilgisi(p, kendi=False):
    duzeyler = sorted({duzey_bul(o.get("s")) for o in p.get("ogrenciler") or []},
                      key=lambda d: DUZEY_SIRA.index(d) if d in DUZEY_SIRA else 99)
    tarihler = [tarih_coz(g.get("t")) for g in p.get("gorusmeler") or []]
    tarihler = [t for t in tarihler if t]
    return {
        "kaynakId": p.get("kaynakId"), "ogretmen": p.get("ogretmen") or "(adsız)", "kendi": kendi,
        "olusturma": p.get("olusturma"), "programSurumu": p.get("programSurumu"),
        "duzeyler": [duzey_adi(d) for d in duzeyler],
        "subeSayisi": len({o.get("s") for o in p.get("ogrenciler") or [] if o.get("s")}),
        "ogrenciSayisi": len(p.get("ogrenciler") or []), "gorusmeSayisi": len(p.get("gorusmeler") or []),
        "sonGorusme": tarih_yaz(max(tarihler)) if tarihler else "",
    }


def okul_raporu_kendi_dahil():
    return ayarlar_oku().get("okulRaporuKendiDahil", True) is not False


def _rapor_paketleri():
    paketler = [p for p in _yuklu_paketler() if p.get("kaynakId") != kurulum_kimligi()]
    kendi = okul_paketi_olustur() if okul_raporu_kendi_dahil() else None
    return kendi, paketler


def okul_paketleri_listesi():
    kendi = okul_paketi_olustur()
    yuklu = [p for p in _yuklu_paketler() if p.get("kaynakId") != kendi["kaynakId"]]
    liste = [_paket_bilgisi(kendi, True)] + [_paket_bilgisi(p) for p in yuklu]
    # uyarılar: aynı şube birden çok pakette / eski paket
    uyarilar = []
    sube_kaynak = {}
    for p in ([kendi] if okul_raporu_kendi_dahil() else []) + yuklu:
        for s in {o.get("s") for o in p.get("ogrenciler") or [] if o.get("s")}:
            sube_kaynak.setdefault(s, []).append(p.get("ogretmen") or "(adsız)")
    for s, kim in sorted(sube_kaynak.items()):
        if len(kim) > 1:
            uyarilar.append("%s şubesi birden çok pakette var (%s). Öğrenciler bir kez sayılır; "
                            "görüşmeler iki pakette de varsa iki kez sayılabilir." % (s, ", ".join(kim)))
    simdi = datetime.now()
    for p in yuklu:
        z = _paket_zamani(p)
        if z != datetime.min and (simdi - z).days > 35:
            uyarilar.append("%s paketi %d gün önce oluşturulmuş; güncel paket istemeniz önerilir." %
                            (p.get("ogretmen") or "(adsız)", (simdi - z).days))
    return {"paketler": liste, "uyarilar": uyarilar, "kendiDahil": okul_raporu_kendi_dahil()}


def okul_raporu_verisi(sorgu):
    bas = tarih_coz((sorgu.get("baslangic", [""])[0] or "")) or date(bugun().year if bugun().month >= 9 else bugun().year - 1, 9, 1)
    bit = tarih_coz((sorgu.get("bitis", [""])[0] or "")) or bugun()
    kendi, yuklu = _rapor_paketleri()
    paketler = ([kendi] if kendi else []) + yuklu
    paketler.sort(key=_paket_zamani)   # yeni paket öğrencinin sınıf bilgisini ezer

    # ---- kayıtlı öğrenciler (tarihten bağımsız), koda göre tekil
    ogr = {}
    for p in paketler:
        for o in p.get("ogrenciler") or []:
            ogr[o.get("k")] = {"s": o.get("s") or "", "d": duzey_bul(o.get("s")), "e": o.get("e") or []}
    # ---- dönemdeki görüşmeler
    gor = []
    for p in paketler:
        for g in p.get("gorusmeler") or []:
            t = tarih_coz(g.get("t"))
            if t and bas <= t <= bit:
                kayit = ogr.get(g.get("k"))
                d = kayit["d"] if kayit else duzey_bul(g.get("s"))
                gor.append(dict(g, _t=t, _d=d))
    etk = []
    for p in paketler:
        for x in p.get("etkinlikler") or []:
            t = tarih_coz(x.get("t"))
            if x.get("tamam") and t and bas <= t <= bit:
                etk.append(dict(x, _d=duzey_bul(x.get("s"))))

    mevcut = {o["d"] for o in ogr.values()} | {g["_d"] for g in gor} | {x["_d"] for x in etk}
    if not mevcut:
        mevcut = {"ana", "1", "2", "3", "4"}
    duzeyler = [d for d in DUZEY_SIRA if d in mevcut]

    def bos():
        return {d: 0 for d in duzeyler}

    kayitli, subeler = bos(), {d: set() for d in duzeyler}
    for o in ogr.values():
        kayitli[o["d"]] += 1
        if o["s"]:
            subeler[o["d"]].add(o["s"])
    toplam_g, ogr_g, veli_g = bos(), bos(), bos()
    gorusulen = {d: set() for d in duzeyler}
    yonl_ogr, yonl_say = {d: set() for d in duzeyler}, bos()
    for g in gor:
        d = g["_d"]
        toplam_g[d] += 1
        if g.get("tur") == "ogrenci":
            ogr_g[d] += 1
        elif g.get("tur") == "veli":
            veli_g[d] += 1
        if g.get("k") in ogr:
            gorusulen[d].add(g.get("k"))
        if g.get("kurum"):
            yonl_say[d] += 1
            yonl_ogr[d].add(g.get("k"))
    etk_say = bos()
    for x in etk:
        etk_say[x["_d"]] += 1

    def matris(alan, yalniz_ogrenci):
        say = {}
        for g in gor:
            if yalniz_ogrenci and g.get("tur") != "ogrenci":
                continue
            for deger in (g.get(alan) or []):
                satir = say.setdefault(deger, bos())
                satir[g["_d"]] += 1
        satirlar = [{"ad": ad, "sayilar": s, "toplam": sum(s.values())} for ad, s in say.items()]
        satirlar.sort(key=lambda x: -x["toplam"])
        return satirlar

    konu_m = matris("konu", False)
    basvuru_m = matris("basvurma", True)
    calisma_m = matris("calisma", True)

    # A: düzeylerin öne çıkan konuları
    one_cikan = []
    for d in duzeyler:
        dtop = sum(r["sayilar"][d] for r in konu_m)
        ilk = sorted([r for r in konu_m if r["sayilar"][d]], key=lambda r: -r["sayilar"][d])[:3]
        one_cikan.append({"duzey": duzey_adi(d), "gorusme": toplam_g[d],
                          "konular": [{"ad": r["ad"], "sayi": r["sayilar"][d],
                                       "oran": round(100.0 * r["sayilar"][d] / dtop) if dtop else 0} for r in ilk]})

    # 7: etkinlik x düzey
    etk_m = {}
    for x in etk:
        etk_m.setdefault(x.get("ad") or "Diğer", bos())[x["_d"]] += 1
    etkinlik_m = sorted([{"ad": a, "sayilar": s, "toplam": sum(s.values())} for a, s in etk_m.items()],
                        key=lambda r: -r["toplam"])

    # 8: toplantılar öğretmene göre (yalnız tamamlananlar)
    toplanti_ogr = []
    for p in paketler:
        turler, adet, dk = {}, 0, 0
        for tp in p.get("toplantilar") or []:
            t = tarih_coz(tp.get("t"))
            if not (tp.get("tamam") and t and bas <= t <= bit):
                continue
            turler[tp.get("ad") or "Diğer"] = turler.get(tp.get("ad") or "Diğer", 0) + 1
            adet += 1
            dk += int(tp.get("dk") or 0)
        if adet:
            toplanti_ogr.append({"ogretmen": p.get("ogretmen") or "(adsız)",
                                 "turler": [{"ad": a, "adet": n} for a, n in sorted(turler.items(), key=lambda x: -x[1])],
                                 "adet": adet, "dakika": dk})

    # E: aylık görüşme dağılımı (dönem içindeki aylar, en fazla 12)
    aylik = []
    y, m = bas.year, bas.month
    while (y, m) <= (bit.year, bit.month) and len(aylik) < 12:
        ogr_ay = sum(1 for g in gor if g["_t"].year == y and g["_t"].month == m and g.get("tur") == "ogrenci")
        veli_ay = sum(1 for g in gor if g["_t"].year == y and g["_t"].month == m and g.get("tur") == "veli")
        aylik.append({"ay": AY_ADI[m], "yil": y, "ogrenci": ogr_ay, "veli": veli_ay, "toplam": ogr_ay + veli_ay})
        m += 1
        if m > 12:
            y, m = y + 1, 1

    # F: ihtiyaç etiketleri x düzey (+ dönemde görüşülen)
    tum_gorusulen = set().union(*gorusulen.values()) if gorusulen else set()
    et_m = {}
    for kod, o in ogr.items():
        for e in o["e"]:
            r = et_m.setdefault(e, {"sayilar": bos(), "gorusulen": 0})
            r["sayilar"][o["d"]] += 1
            if kod in tum_gorusulen:
                r["gorusulen"] += 1
    etiket_m = sorted([{"ad": a, "sayilar": r["sayilar"], "toplam": sum(r["sayilar"].values()), "gorusulen": r["gorusulen"]}
                       for a, r in et_m.items()], key=lambda r: -r["toplam"])

    duzey_tablo = []
    for d in duzeyler:
        n_g = len(gorusulen[d])
        duzey_tablo.append({
            "duzey": duzey_adi(d), "kod": d, "kayitli": kayitli[d], "sube": len(subeler[d]),
            "toplam": toplam_g[d], "ogrenci": ogr_g[d], "veli": veli_g[d],
            "veliOrani": round(100.0 * veli_g[d] / toplam_g[d]) if toplam_g[d] else 0,
            "gorusulen": n_g, "kapsama": round(100.0 * n_g / kayitli[d]) if kayitli[d] else 0,
            "yuzOgrenci": round(100.0 * toplam_g[d] / kayitli[d], 1) if kayitli[d] else 0,
            "ogrenciBasina": round(1.0 * toplam_g[d] / n_g, 1) if n_g else 0,
            "yonlendirilenOgrenci": len(yonl_ogr[d]), "yonlendirmeSayisi": yonl_say[d],
            "etkinlik": etk_say[d],
        })
    T_kayitli = sum(kayitli.values())
    T_gor = sum(toplam_g.values())
    T_gorusulen = sum(len(x) for x in gorusulen.values())
    toplam_satir = {
        "duzey": "Toplam", "kayitli": T_kayitli, "sube": sum(len(x) for x in subeler.values()),
        "toplam": T_gor, "ogrenci": sum(ogr_g.values()), "veli": sum(veli_g.values()),
        "veliOrani": round(100.0 * sum(veli_g.values()) / T_gor) if T_gor else 0,
        "gorusulen": T_gorusulen, "kapsama": round(100.0 * T_gorusulen / T_kayitli) if T_kayitli else 0,
        "yuzOgrenci": round(100.0 * T_gor / T_kayitli, 1) if T_kayitli else 0,
        "ogrenciBasina": round(1.0 * T_gor / T_gorusulen, 1) if T_gorusulen else 0,
        "yonlendirilenOgrenci": sum(len(x) for x in yonl_ogr.values()), "yonlendirmeSayisi": sum(yonl_say.values()),
        "etkinlik": sum(etk_say.values()),
    }

    # H: veri güncelliği (öğretmen adı olmadan)
    guncellik = []
    for p in paketler:
        b = _paket_bilgisi(p, p is kendi)
        guncellik.append({"duzeyler": b["duzeyler"], "olusturma": (p.get("olusturma") or "").split(" ")[0],
                          "sonGorusme": b["sonGorusme"]})

    return {
        "donem": {"baslangic": tarih_yaz(bas), "bitis": tarih_yaz(bit)},
        "duzeyler": [duzey_adi(d) for d in duzeyler], "duzeyKodlari": duzeyler,
        "duzeyTablo": duzey_tablo, "toplam": toplam_satir,
        "toplantiToplam": {"adet": sum(x["adet"] for x in toplanti_ogr), "dakika": sum(x["dakika"] for x in toplanti_ogr)},
        "konu": konu_m, "basvuru": basvuru_m, "calisma": calisma_m,
        "oneCikan": one_cikan, "etkinlik": etkinlik_m, "toplantiOgretmen": toplanti_ogr,
        "aylik": aylik, "etiket": etiket_m, "guncellik": guncellik,
        "paketSayisi": len(paketler),
    }


# ---------------------------------------------------------------- e-Okul içe aktarma
#
# Desteklenen dosyalar: e-Okul "Sınıf Listesi" PDF çıktısı (metin tabanlı,
# taranmış görüntü değil), CSV ve Excel (.xlsx). Her biri aynı ortak
# yapıya (şube listesi + öğrenci satırları) dönüştürülür.

_PDF_SATIR = re.compile(
    r"^\s*(\d+)\s+(.+?)\s+(Erkek|Kız)\s+(.+?)\s+(\d+)\s*$", re.MULTILINE)
# e-Okul sınıf listesi başlığı iki biçimde gelir: sayılı sınıflarda "5. Sınıf / A Şubesi",
# anasınıfı/anaokulu şubelerinde ise sayı olmadan "Ana Sınıfı / B Şubesi" ya da "Anasınıfı / B Şubesi".
_PDF_SINIF_SUBE = re.compile(
    r"(?:(\d+)\.\s*Sınıf|(Ana\s*Sınıf[ıi]?))\s*/\s*([A-ZÇĞİÖŞÜa-zçğıöşü]+)\s*Şubesi")
_PDF_OGRETMEN = re.compile(r"Sınıf Öğretmeni\s*:\s*(.+)")
_PDF_OKUL = re.compile(r"^(.+?)\s*/\s*(.+?)\s*Müdürlüğü\s*$", re.MULTILINE)


def pdf_sinif_listesi_coz(veri_bytes):
    try:
        from pypdf import PdfReader
    except Exception as e:
        raise ValueError(
            "PDF okunamadı: pypdf kütüphanesi yüklenemedi (%s). "
            "Lütfen e-Okul'dan Excel veya CSV olarak dışa aktarıp onu yükleyin." % e)
    okuyucu = PdfReader(io.BytesIO(veri_bytes))
    subeler = []
    for sayfa in okuyucu.pages:
        try:
            metin = sayfa.extract_text() or ""
        except Exception:
            continue
        if not metin.strip():
            continue
        sinif_m = _PDF_SINIF_SUBE.search(metin)
        ogretmen_m = _PDF_OGRETMEN.search(metin)
        okul_m = _PDF_OKUL.search(metin)
        if not sinif_m:
            continue
        sinif_duzey = sinif_m.group(1) if sinif_m.group(1) else "Ana"
        sinif_ad = sinif_duzey + "/" + sinif_m.group(3).upper()
        ogretmen = tr_baslik(ogretmen_m.group(1).strip()) if ogretmen_m else ""
        okul_adi = ""
        ilce = ""
        if okul_m:
            ilce = tr_baslik(okul_m.group(1).strip())
            okul_adi = re.sub(r"\s*Müdürlüğü\s*$", "", okul_m.group(2).strip())
            okul_adi = tr_baslik(okul_adi)

        ogrenciler = []
        for m in _PDF_SATIR.finditer(metin):
            okul_no, ad, cinsiyet, soyad, sno = m.groups()
            ogrenciler.append({
                "okulNo": okul_no.strip(),
                "adSoyad": tr_baslik(ad.strip()) + " " + tr_baslik(soyad.strip()),
                "cinsiyet": "E" if cinsiyet == "Erkek" else "K",
            })
        if ogrenciler:
            subeler.append({"sinif": sinif_ad, "ogretmenAdi": ogretmen,
                             "okulAdi": okul_adi, "ilceIl": ilce, "ogrenciler": ogrenciler})
    return subeler


_BASLIK_ESLESME = {
    "okulNo": ["okul no", "ogrenci no", "no"],
    "ad": ["adi", "ad", "adı"],
    "soyad": ["soyadi", "soyad", "soyadı"],
    "adSoyad": ["adi soyadi", "ad soyad", "adı soyadı", "adisoyadi"],
    "cinsiyet": ["cinsiyeti", "cinsiyet"],
    "sinif": ["sinif", "sinif sube", "sinif/sube", "sinifsube", "sınıf"],
    "ogretmen": ["sinif ogretmeni", "ogretmen", "sınıf öğretmeni"],
}


def _basligi_tani(hucre):
    n = normalize(hucre).replace("/", " ").strip()
    n = re.sub(r"\s+", " ", n)
    for alan, adaylar in _BASLIK_ESLESME.items():
        for aday in adaylar:
            if normalize(aday) == n:
                return alan
    return None


def satirlardan_subeler_uret(satirlar):
    """Başlık satırını bulup, kalan satırları şube+öğrenci yapısına çevirir."""
    if not satirlar:
        return []
    baslik_idx = None
    esleme = {}
    for i, satir in enumerate(satirlar[:5]):
        e = {}
        for j, hucre in enumerate(satir):
            alan = _basligi_tani(hucre)
            if alan:
                e[alan] = j
        if len(e) >= 2:
            baslik_idx = i
            esleme = e
            break
    if baslik_idx is None:
        raise ValueError("Dosyanın başlık satırı tanınamadı (Okul No / Adı Soyadı / Sınıf sütunları bulunamadı).")

    gruplar = {}
    for satir in satirlar[baslik_idx + 1:]:
        if not any((h or "").strip() for h in satir):
            continue

        def al(alan):
            j = esleme.get(alan)
            return (satir[j].strip() if j is not None and j < len(satir) else "")

        sinif = al("sinif")
        if not sinif:
            continue
        if "adSoyad" in esleme:
            ad_soyad = al("adSoyad")
        else:
            ad_soyad = (al("ad") + " " + al("soyad")).strip()
        if not ad_soyad:
            continue
        cinsiyet_ham = normalize(al("cinsiyet"))
        cinsiyet = "K" if cinsiyet_ham.startswith("k") else ("E" if cinsiyet_ham.startswith("e") else "")
        ogretmen = al("ogretmen")
        g = gruplar.setdefault(sinif, {"sinif": sinif, "ogretmenAdi": ogretmen, "ogrenciler": []})
        if ogretmen and not g["ogretmenAdi"]:
            g["ogretmenAdi"] = ogretmen
        g["ogrenciler"].append({
            "okulNo": al("okulNo"), "adSoyad": tr_baslik(ad_soyad) if ad_soyad.isupper() else ad_soyad,
            "cinsiyet": cinsiyet,
        })
    return list(gruplar.values())


def csv_sinif_listesi_coz(veri_bytes):
    for kodlama in ("utf-8-sig", "cp1254", "latin-9"):
        try:
            metin = veri_bytes.decode(kodlama)
            break
        except Exception:
            continue
    else:
        metin = veri_bytes.decode("utf-8", "ignore")
    ayrac = ";" if metin.count(";") > metin.count(",") else ","
    okuyucu = csv.reader(io.StringIO(metin), delimiter=ayrac)
    satirlar = [row for row in okuyucu]
    return satirlardan_subeler_uret(satirlar)


def _xlsx_ilk_sayfa_yolu(z):
    try:
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
              "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
        sheet = wb.find(".//m:sheets/m:sheet", ns)
        rid = sheet.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        for rel in rels:
            if rel.get("Id") == rid:
                hedef = rel.get("Target").lstrip("/")      # bazı programlar "/xl/..." mutlak yol yazar
                yol = hedef if hedef.startswith("xl/") else "xl/" + hedef
                if yol in z.namelist():
                    return yol
    except Exception:
        pass
    return "xl/worksheets/sheet1.xml"


def xlsx_satirlari_oku(kaynak):
    with zipfile.ZipFile(kaynak) as z:
        paylasilan = []
        if "xl/sharedStrings.xml" in z.namelist():
            kok = ET.fromstring(z.read("xl/sharedStrings.xml"))
            ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
            for si in kok.findall(ns + "si"):
                metin = "".join((t.text or "") for t in si.iter(ns + "t"))
                paylasilan.append(metin)
        sayfa_yolu = _xlsx_ilk_sayfa_yolu(z)
        kok = ET.fromstring(z.read(sayfa_yolu))
        ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
        satirlar = []
        for row in kok.findall(".//" + ns + "sheetData/" + ns + "row"):
            hucreler = {}
            for c in row.findall(ns + "c"):
                ref = c.get("r") or ""
                harf = re.match(r"[A-Z]+", ref)
                sutun = harf.group(0) if harf else ""
                tur = c.get("t")
                v = c.find(ns + "v")
                deger = v.text if v is not None else ""
                if tur == "inlineStr":
                    deger = "".join((t.text or "") for t in c.iter(ns + "t"))
                elif tur == "s" and deger != "":
                    try:
                        deger = paylasilan[int(deger)]
                    except (ValueError, IndexError):
                        deger = ""
                hucreler[sutun] = deger or ""
            if not hucreler:
                satirlar.append([])
                continue
            sutun_sirasi = sorted(hucreler.keys(), key=lambda s: (len(s), s))
            satir = [hucreler[s] for s in sutun_sirasi]
            satirlar.append(satir)
        return satirlar


def xlsx_sinif_listesi_coz(veri_bytes):
    satirlar = xlsx_satirlari_oku(io.BytesIO(veri_bytes))
    return satirlardan_subeler_uret(satirlar)


def ice_aktar_coz(dosya_adi, veri_bytes):
    uzanti = os.path.splitext(dosya_adi or "")[1].lower()
    if uzanti == ".pdf":
        return pdf_sinif_listesi_coz(veri_bytes)
    if uzanti == ".csv":
        return csv_sinif_listesi_coz(veri_bytes)
    if uzanti in (".xlsx", ".xlsm"):
        return xlsx_sinif_listesi_coz(veri_bytes)
    raise ValueError("Desteklenmeyen dosya türü. PDF, CSV veya Excel (.xlsx) yükleyin.")


def ice_aktar_onizle_hesapla(subeler):
    mevcutlar = {k.get("okulNo"): k for k in tum_ogrenciler() if k.get("okulNo")}
    yeni = 0
    guncellenecek = 0
    for sube in subeler:
        for o in sube["ogrenciler"]:
            if o.get("okulNo") and o["okulNo"] in mevcutlar:
                guncellenecek += 1
            else:
                yeni += 1
    return yeni, guncellenecek


def ice_aktar_uygula(subeler):
    mevcutlar = {k.get("okulNo"): k for k in tum_ogrenciler() if k.get("okulNo")}
    yeni_sayisi = 0
    guncellenen_sayisi = 0
    for sube in subeler:
        sinif = sube.get("sinif")
        ogretmen = sube.get("ogretmenAdi") or ""
        if sinif:
            sinif_ogretmeni_guncelle(sinif, ogretmen)
        for o in sube.get("ogrenciler") or []:
            okul_no = o.get("okulNo")
            if okul_no and okul_no in mevcutlar:
                k = mevcutlar[okul_no]
                k["sinif"] = sinif
                if ogretmen:
                    k["sinifOgretmeni"] = ogretmen
                if o.get("cinsiyet") and not k.get("cinsiyet"):
                    k["cinsiyet"] = o["cinsiyet"]
                ogrenci_yaz(k)
                guncellenen_sayisi += 1
            else:
                k = yeni_ogrenci_kaydi({
                    "okulNo": okul_no, "adSoyad": o.get("adSoyad"), "sinif": sinif,
                    "cinsiyet": o.get("cinsiyet"), "sinifOgretmeni": ogretmen,
                })
                ogrenci_yaz(k)
                if okul_no:
                    mevcutlar[okul_no] = k
                yeni_sayisi += 1
    return yeni_sayisi, guncellenen_sayisi


# ---------------------------------------------------------------- multipart/form-data

# ---------------------------------------------------------------- sınıf etkinliği planı içe aktarma
#
# Rehber öğretmenin hazırladığı "REHBERLİK DERSİ: <konu>" başlıklı tarih / ders saati /
# sınıf / sınıf öğretmeni çizelgesini (PDF, Word, Excel, CSV) okuyup sınıf etkinliği
# önerisine çevirir. Tamamen çevrimdışı: PDF için yerel pypdf, Word/Excel için zip+XML.
# Fotoğraf/taranmış belge (yazı katmanı olmayan) okunamaz; kullanıcıya aslı istenir.

VARSAYILAN_DERS_SAATLERI = {"1": "08:30", "2": "09:20", "3": "10:10", "4": "11:00",
                            "5": "11:50", "6": "12:40", "7": "13:30", "8": "14:20"}
_GUNLER = r"(?:pazartesi|salı|sali|çarşamba|carsamba|perşembe|persembe|cuma|cumartesi|pazar)"
_ET_TARIH = re.compile(r"(?<!\d)(\d{1,2})\s*[./\-]\s*(\d{1,2})\s*[./\-]\s*(\d{4})(?!\d)")
_ET_SAAT = re.compile(r"(?<!\d)([01]?\d|2[0-3])[:.]([0-5]\d)(?!\d)")
_ET_SINIF = re.compile(r"(?<![\w])((?:1[0-2]|[1-9])|ana(?:\s*sınıfı)?)\s*[-/.]?\s*([A-ZÇĞİÖŞÜa-zçğıöşü])(?![\wçğıöşüÇĞİÖŞÜ])"
                       r"(?:\s*(?:sınıfı|şubesi))?", re.I)
_KUCUK_KALAN = {"ve", "ile", "ya", "da", "de", "ki", "veya", "için"}


def etkinlik_basligi_duzelt(s):
    s = re.sub(r"\s+", " ", (s or "")).strip(" :-–")
    kelimeler = tr_baslik(tr_kucuk(s)).split(" ")
    return " ".join(k if i == 0 else (tr_kucuk(k) if tr_kucuk(k) in _KUCUK_KALAN else k)
                    for i, k in enumerate(kelimeler))


def tr_kucuk(s):
    return (s or "").replace("I", "ı").replace("İ", "i").lower()


def ders_saatleri_oku():
    d = dict(VARSAYILAN_DERS_SAATLERI)
    d.update(ayarlar_oku().get("dersSaatleri") or {})
    return d


def _pdf_konumlu_satirlar(sayfa):
    """PDF tablosunu konumlarıyla okur: aynı yükseklikteki parçalar bir satır, aynı x'teki
    parçalar bir hücre olur. Hücre içinde alt satıra kayan yazılar (ör. gün adı, uzun isim)
    tarih içermeyen satırlar olarak gelir ve üstteki satırın aynı sütununa eklenir."""
    parcalar = []

    def gor(text, cm, tm, font, boyut):
        if text and text.strip():
            x = tm[4] * cm[0] + tm[5] * cm[2] + cm[4]
            y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
            parcalar.append((y, x, text.strip()))
    try:
        sayfa.extract_text(visitor_text=gor)
    except Exception:
        return []
    parcalar.sort(key=lambda p: (-p[0], p[1]))
    satirlar = []          # [(y, {x: metin})]
    for y, x, t in parcalar:
        if satirlar and abs(satirlar[-1][0] - y) <= 2.5:
            hucre = satirlar[-1][1]
            anahtar = next((k for k in hucre if abs(k - x) < 3), x)
            hucre[anahtar] = (hucre.get(anahtar, "") + " " + t).strip()
        else:
            satirlar.append((y, {x: t}))
    birlesik = []
    for y, hucre in satirlar:
        metin = "  ".join(hucre[k] for k in sorted(hucre))
        if birlesik and not _ET_TARIH.search(metin) and _ET_TARIH.search(birlesik[-1][1]) \
                and all(any(abs(k - k2) < 3 for k2 in birlesik[-1][0]) for k in hucre):
            onceki = birlesik[-1][0]
            for k in hucre:
                k2 = next(k2 for k2 in onceki if abs(k - k2) < 3)
                onceki[k2] = onceki[k2] + " " + hucre[k]
            birlesik[-1] = (onceki, "  ".join(onceki[k] for k in sorted(onceki)))
        else:
            birlesik.append((dict(hucre), metin))
    return [m for _, m in birlesik]


# Fotoğraf okuma (OCR): Windows 10/11'in kendi içindeki yazı tanıma motoru
# (Windows.Media.Ocr) PowerShell ile çağrılır. İnternet gerekmez, ek kurulum gerekmez;
# resim bu bilgisayardan dışarı çıkmaz.
_OCR_PS1 = r"""
param([string]$Giris, [string]$Cikis)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
try { $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] } catch {}
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Bekle($is, $tur) {
    $t = $asTaskGeneric.MakeGenericMethod($tur).Invoke($null, @($is)); $t.Wait(-1) | Out-Null; $t.Result }
$dosya = Bekle ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Giris)) ([Windows.Storage.StorageFile])
$akis = Bekle ($dosya.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$coz = Bekle ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($akis)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Bekle ($coz.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$motor = $null
try { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language 'tr')) } catch {}
if ($motor -eq $null) { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if ($motor -eq $null) { throw 'OCR motoru yok' }
$sonuc = Bekle ($motor.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
$kel = New-Object System.Collections.ArrayList
foreach ($satir in $sonuc.Lines) { foreach ($k in $satir.Words) {
    $r = $k.BoundingRect
    [void]$kel.Add([ordered]@{ t = $k.Text; x = [int]$r.X; y = [int]$r.Y; w = [int]$r.Width; h = [int]$r.Height }) } }
$aci = 0; if ($sonuc.TextAngle -ne $null) { $aci = [double]$sonuc.TextAngle }
$json = ConvertTo-Json -Depth 4 -Compress (@{ aci = $aci; dil = $motor.RecognizerLanguage.LanguageTag; kelimeler = $kel })
[System.IO.File]::WriteAllText($Cikis, $json, (New-Object System.Text.UTF8Encoding($false)))
"""


def resim_ocr(veri, uzanti):
    if os.name != "nt":
        raise ValueError("Fotoğraftan okuma yalnızca Windows'ta çalışır (Windows'un kendi yazı tanıma "
                         "özelliği kullanılır). Bu bilgisayarda Word/Excel/PDF aslını yükleyin.")
    import tempfile
    klasor = tempfile.mkdtemp(prefix="rehberlik-ocr-")
    try:
        giris = os.path.join(klasor, "resim" + (uzanti or ".jpg"))
        cikis = os.path.join(klasor, "sonuc.json")
        betik = os.path.join(klasor, "ocr.ps1")
        with open(giris, "wb") as f:
            f.write(veri)
        with open(betik, "w", encoding="utf-8-sig") as f:
            f.write(_OCR_PS1)
        try:
            sonuc = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                 "-File", betik, "-Giris", giris, "-Cikis", cikis],
                capture_output=True, timeout=90,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except subprocess.TimeoutExpired:
            raise ValueError("Fotoğraf okuma çok uzun sürdü. Daha küçük/net bir fotoğraf deneyin.")
        if not os.path.isfile(cikis):
            hata = (sonuc.stderr or b"").decode("utf-8", "replace")[-300:]
            raise ValueError("Fotoğraf okunamadı (Windows yazı tanıma çalışmadı). Çizelgenin Word/PDF "
                             "aslını yükleyin. Ayrıntı: " + hata.strip())
        with open(cikis, encoding="utf-8-sig") as f:
            return json.load(f)
    finally:
        shutil.rmtree(klasor, ignore_errors=True)


def _kelimelerden_satirlar(ocr):
    """OCR kelime kutularından tablo satırları kurar. Fotoğraf hafif eğik çekilmiş olabilir:
    eğim, tarih sütunuyla sınıf sütunundaki kelimeler sırayla eşleştirilerek ölçülür."""
    kel = [k for k in (ocr or {}).get("kelimeler") or [] if (k.get("t") or "").strip()]
    if not kel:
        raise ValueError("Fotoğrafta okunabilir yazı bulunamadı. Kâğıdı düz ve aydınlık bir yerde, "
                         "tablonun tamamı görünecek şekilde yeniden çekin.")
    for k in kel:
        k["cx"] = k["x"] + k["w"] / 2.0
        k["cy"] = k["y"] + k["h"] / 2.0
    yuks = sorted(k["h"] for k in kel)
    orta_h = yuks[len(yuks) // 2] or 10
    tarihler = sorted((k for k in kel if _ET_TARIH.search(k["t"])), key=lambda k: k["cy"])
    siniflar = sorted((k for k in kel if re.fullmatch(r"\d{1,2}\s*[-/.]\s*[A-Za-zÇĞİÖŞÜçğıöşü]", k["t"])),
                      key=lambda k: k["cy"])
    egim = 0.0
    if len(tarihler) >= 3 and len(tarihler) == len(siniflar):
        oranlar = sorted((s["cy"] - t["cy"]) / (s["cx"] - t["cx"]) for t, s in zip(tarihler, siniflar)
                         if abs(s["cx"] - t["cx"]) > 50)
        if oranlar:
            egim = oranlar[len(oranlar) // 2]
    elif ocr.get("aci"):
        import math
        egim = math.tan(math.radians(float(ocr["aci"])))
    for k in kel:
        k["dy"] = k["cy"] - egim * k["cx"]
    kel.sort(key=lambda k: k["dy"])
    satirlar = []
    for k in kel:
        if satirlar and abs(k["dy"] - satirlar[-1]["dy"]) <= 0.6 * orta_h:
            s = satirlar[-1]
            s["k"].append(k)
            s["dy"] = sum(x["dy"] for x in s["k"]) / len(s["k"])
        else:
            satirlar.append({"dy": k["dy"], "k": [k]})
    sonuc = []
    for s in satirlar:
        parca = sorted(s["k"], key=lambda k: k["x"])
        metin, onceki = "", None
        for k in parca:
            if onceki is not None:
                metin += "  " if k["x"] - (onceki["x"] + onceki["w"]) > 1.2 * orta_h else " "
            metin += k["t"]
            onceki = k
        sonuc.append(metin)
    return sonuc


def _etkinlik_belge_satirlari(dosya_adi, veri):
    """Belgeyi metin satırlarına çevirir (tablo hücreleri boşlukla birleştirilir)."""
    ad = (dosya_adi or "").lower()
    if ad.endswith((".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff")):
        return _kelimelerden_satirlar(resim_ocr(veri, os.path.splitext(ad)[1]))
    if ad.endswith((".heic", ".webp")):
        raise ValueError("Bu resim biçimi okunamıyor. Fotoğrafı JPG olarak kaydedip yükleyin.")
    if ad.endswith(".pdf") or veri[:4] == b"%PDF":
        try:
            from pypdf import PdfReader
        except Exception as e:
            raise ValueError("PDF okunamadı (pypdf yüklenemedi: %s)." % e)
        okuyucu = PdfReader(io.BytesIO(veri))
        satirlar = []
        for sayfa in okuyucu.pages:
            satirlar += _pdf_konumlu_satirlar(sayfa)
        if not any(_ET_TARIH.search(l) for l in satirlar):      # konumlu okuma işe yaramadıysa düz metin
            satirlar = []
            for sayfa in okuyucu.pages:
                try:
                    satirlar += (sayfa.extract_text() or "").splitlines()
                except Exception:
                    pass
        if not "".join(satirlar).strip():
            raise ValueError("Bu PDF taranmış (resim) görünüyor; içinde okunabilir yazı yok. "
                             "Çizelgenin Word'den kaydedilmiş PDF'ini ya da Word/Excel aslını yükleyin.")
        return satirlar
    if ad.endswith(".docx"):
        ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        with zipfile.ZipFile(io.BytesIO(veri)) as z:
            kok = ET.fromstring(z.read("word/document.xml"))
        satirlar = []
        govde = kok.find(ns + "body")
        for oge in list(govde if govde is not None else []):
            if oge.tag == ns + "p":
                satirlar.append("".join(t.text or "" for t in oge.iter(ns + "t")))
            elif oge.tag == ns + "tbl":
                for tr in oge.iter(ns + "tr"):
                    hucreler = [" ".join("".join(t.text or "" for t in p.iter(ns + "t")) for p in tc.iter(ns + "p")).strip()
                                for tc in tr.findall(ns + "tc")]
                    satirlar.append("  ".join(hucreler))
        return satirlar
    if ad.endswith(".xlsx"):
        satirlar = []
        for satir in xlsx_satirlari_oku(io.BytesIO(veri)):
            hucreler = []
            for h in satir:
                h = str(h or "").strip()
                if re.fullmatch(r"\d{5}(\.0+)?", h) and 30000 < float(h) < 60000:   # Excel tarih seri no
                    h = (date(1899, 12, 30) + timedelta(days=int(float(h)))).strftime("%d.%m.%Y")
                elif re.fullmatch(r"0?\.\d+", h):                                      # Excel saat (gün kesri)
                    dk = round(float(h) * 1440)
                    h = "%02d:%02d" % (dk // 60, dk % 60)
                hucreler.append(h)
            satirlar.append("  ".join(hucreler))
        return satirlar
    if ad.endswith((".csv", ".txt")):
        metin = veri.decode("utf-8-sig", errors="replace")
        if "�" in metin:
            metin = veri.decode("cp1254", errors="replace")
        return [re.sub(r"[;,\t]", "  ", l) for l in metin.splitlines()]
    if ad.endswith(".doc") or ad.endswith(".xls"):
        raise ValueError("Eski biçim (.doc/.xls) okunamıyor. Dosyayı Word/Excel'de açıp "
                         "'Farklı Kaydet' ile .docx/.xlsx ya da PDF olarak kaydedin.")
    raise ValueError("Desteklenen dosyalar: PDF, Word (.docx), Excel (.xlsx), CSV.")


def _sinif_anahtari(s):
    return re.sub(r"[^0-9a-zçğıöşü]", "", tr_kucuk(s or "").replace("sınıfı", "").replace("anasınıfı", "ana"))


def etkinlik_plani_coz(dosya_adi, veri):
    satirlar = [re.sub(r"\s+", " ", l).strip() for l in _etkinlik_belge_satirlari(dosya_adi, veri)]
    satirlar = [l for l in satirlar if l]
    # mevcut sınıflar (yazılış biçimi korunsun: 1/A, 1-A …)
    mevcut = {}
    for ad in list(siniflar_oku().keys()) + [k.get("sinif") for k in tum_ogrenciler()]:
        if ad:
            mevcut.setdefault(_sinif_anahtari(ad), ad)
    ders = ders_saatleri_oku()

    baslik = ""
    for l in satirlar[:15]:
        if _ET_TARIH.search(l):
            break
        n = normalize(l)
        if ":" in l and ("ders" in n or "rehberlik" in n or "etkinlik" in n):
            baslik = l.split(":", 1)[1]
            break
        if not baslik and len(l) > 8 and not re.search(r"ders saati|sinif ogretmeni|tarih", n) \
                and not re.fullmatch(r"\(?\s*\d+\s*ders saati\s*\)?", n):
            baslik = l
    baslik = etkinlik_basligi_duzelt(baslik)

    kayitlar = []
    for l in satirlar:
        tm = _ET_TARIH.search(l)
        if not tm:
            continue
        try:
            d = date(int(tm.group(3)), int(tm.group(2)), int(tm.group(1)))
        except ValueError:
            continue
        geri = l[tm.end():]
        geri = re.sub(r"^\s*" + _GUNLER + r"\b", "", geri, flags=re.I).strip()
        saat = ""
        ders_saati = ""
        sm = _ET_SAAT.match(geri) or (_ET_SAAT.search(geri) if not re.match(r"\d", geri) else None)
        if sm and sm.start() < 3:
            saat = "%02d:%s" % (int(sm.group(1)), sm.group(2))
            geri = geri[sm.end():].strip()
        # ders saati: sınıftan önce gelen tek başına sayı ("3 1-K ...")
        sinif_m = None
        for cm in _ET_SINIF.finditer(geri):
            on = geri[:cm.start()].strip()
            if re.fullmatch(r"(\d{1,2})\s*(\.|\.?\s*ders)?", on) or on == "":
                sinif_m = cm
                if on:
                    ders_saati = re.match(r"\d{1,2}", on).group(0)
                break
        if not sinif_m:
            # fotoğraf okumasında sınıf yanlış okunmuş olabilir (1-I → "11", "1l"): satırı kaybetme,
            # tahminle ya da boş bırakıp kullanıcıya düzelttir
            parca = geri.split()
            ders_saati = parca[0] if parca and re.fullmatch(r"[1-8]", parca[0]) and len(parca) > 2 else ""
            if ders_saati:
                parca = parca[1:]
            tahmin = ""
            if parca and re.fullmatch(r"(1[0-2]|[1-9])[1lI|]", parca[0]):
                tahmin = parca[0][:-1] + "/I"
            ogretmen = " ".join(parca[1:] if parca else []).strip(" \\|/[]!-–")
            ogretmen = tr_baslik(tr_kucuk(ogretmen)) if ogretmen.isupper() else ogretmen
            anahtar = _sinif_anahtari(tahmin) if tahmin else ""
            kayitlar.append({"tarih": tarih_yaz(d), "dersSaati": ders_saati,
                             "saat": ders.get(ders_saati, "") if ders_saati else saat,
                             "sinifHam": parca[0] if parca else "", "sinif": mevcut.get(anahtar, tahmin) if tahmin else "",
                             "sinifVar": bool(tahmin and anahtar in mevcut), "ogretmen": ogretmen, "kontrol": True})
            continue
        duzey, sube = sinif_m.group(1), sinif_m.group(2)
        duzey = "Ana" if normalize(duzey).startswith("ana") else str(int(duzey))
        sube = sube.replace("i", "İ").upper() if sube == "i" else sube.upper()
        sinif_ham = sinif_m.group(0).strip()
        anahtar = _sinif_anahtari(duzey + sube)
        sinif = mevcut.get(anahtar) or (duzey + "/" + sube)
        ogretmen = geri[sinif_m.end():].strip(" -–|\\/[]!")
        ogretmen = tr_baslik(tr_kucuk(ogretmen)) if ogretmen.isupper() else ogretmen
        if not saat and ders_saati:
            saat = ders.get(str(int(ders_saati)), "")
        kayitlar.append({"tarih": tarih_yaz(d), "dersSaati": ders_saati, "saat": saat,
                         "sinifHam": sinif_ham, "sinif": sinif, "sinifVar": anahtar in mevcut,
                         "ogretmen": ogretmen})

    if not kayitlar:
        raise ValueError("Belgede tarih + sınıf içeren satır bulunamadı. Çizelgede her satırda "
                         "tarih (14/10/2026), sınıf (1-A) ve isteğe bağlı ders saati olmalı.")
    # aynı etkinlik zaten var mı (tür eşleşirse işaretlenir)
    turler = etkinlik_turleri_oku()
    tur = next((t for t in turler if normalize(t["ad"]) == normalize(baslik)), None)
    var_olanlar = {(se.get("etkinlikTuruId"), se.get("sinif"), se.get("tarih")) for se in sinif_etkinlikleri_oku()}
    for k in kayitlar:
        k["mevcut"] = bool(tur and (tur["id"], k["sinif"], k["tarih"]) in var_olanlar)
    return {"baslik": baslik, "turId": tur["id"] if tur else "", "satirlar": kayitlar,
            "dersSaatleri": ders, "turler": turler}


def etkinlik_plani_uygula(veri):
    tur_id = (veri.get("turId") or "").strip()
    yeni_ad = (veri.get("yeniTurAdi") or "").strip()
    turler = etkinlik_turleri_oku()
    if not tur_id:
        if not yeni_ad:
            raise ValueError("Etkinlik türü seçin ya da yeni tür adı yazın.")
        mevcut_tur = next((t for t in turler if normalize(t["ad"]) == normalize(yeni_ad)), None)
        if mevcut_tur:
            tur_id = mevcut_tur["id"]
        else:
            tur_id = yeni_id()
            turler.append({"id": tur_id, "ad": yeni_ad})
            etkinlik_turleri_yaz(turler)
    elif tur_id not in {t["id"] for t in turler}:
        raise ValueError("Etkinlik türü bulunamadı.")
    if isinstance(veri.get("dersSaatleri"), dict):
        temiz = {str(k): str(v).strip() for k, v in veri["dersSaatleri"].items() if re.fullmatch(r"\d{1,2}:\d{2}", str(v).strip())}
        ayarlar_yaz({"dersSaatleri": temiz})
    liste = sinif_etkinlikleri_oku()
    var_olanlar = {(se.get("etkinlikTuruId"), se.get("sinif"), se.get("tarih")) for se in liste}
    siniflar = siniflar_oku()
    eklenen, atlanan = 0, 0
    for k in veri.get("satirlar") or []:
        sinif = (k.get("sinif") or "").strip()
        d = tarih_coz(k.get("tarih"))
        if not sinif or not d:
            atlanan += 1
            continue
        tarih = tarih_yaz(d)
        if (tur_id, sinif, tarih) in var_olanlar:
            atlanan += 1
            continue
        aciklama = []
        if k.get("dersSaati"):
            aciklama.append("%s. ders saati" % k["dersSaati"])
        if k.get("ogretmen"):
            aciklama.append("Sınıf öğretmeni: %s" % k["ogretmen"])
        liste.append({"id": yeni_id(), "etkinlikTuruId": tur_id, "sinif": sinif, "tarih": tarih,
                      "saat": (k.get("saat") or "").strip(), "aciklama": " · ".join(aciklama),
                      "tamamlandi": bool(k.get("tamamlandi")), "olusturma": simdi_iso()})
        var_olanlar.add((tur_id, sinif, tarih))
        eklenen += 1
        # sınıf öğretmeni boşsa çizelgedekini kaydet (var olanın üzerine yazmaz)
        if k.get("ogretmen") and not (siniflar.get(sinif) or {}).get("ogretmen"):
            siniflar[sinif] = {"ogretmen": k["ogretmen"]}
    sinif_etkinlikleri_yaz(liste)
    siniflar_yaz(siniflar)
    return {"tamam": True, "eklenen": eklenen, "atlanan": atlanan, "turId": tur_id}


def multipart_coz(govde, sinir):
    parcalar = govde.split(b"--" + sinir)
    sonuc = []
    for p in parcalar:
        if not p or p in (b"--\r\n", b"--"):
            continue
        p = p.lstrip(b"\r\n")
        if b"\r\n\r\n" not in p:
            continue
        basliklar, icerik = p.split(b"\r\n\r\n", 1)
        if icerik.endswith(b"\r\n"):
            icerik = icerik[:-2]
        b_metin = basliklar.decode("utf-8", "ignore")
        ad = re.search(r'name="([^"]*)"', b_metin)
        dosya_adi = re.search(r'filename="([^"]*)"', b_metin)
        sonuc.append({
            "ad": ad.group(1) if ad else "",
            "dosyaAdi": dosya_adi.group(1) if dosya_adi else None,
            "icerik": icerik,
        })
    return sonuc


# ---------------------------------------------------------------- HTTP sunucu

class Istek(BaseHTTPRequestHandler):
    server_version = "OgrenciRehberlikTakip/" + SURUM

    def log_message(self, bicim, *args):
        pass

    # ---- yardımcı yanıtlar
    def json_yanit(self, veri, kod=200):
        govde = json.dumps(veri, ensure_ascii=False).encode("utf-8")
        self.send_response(kod)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(govde)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(govde)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def hata_yanit(self, mesaj, kod=400):
        self.json_yanit({"hata": mesaj}, kod)

    def govde_json_oku(self):
        try:
            uzunluk = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            uzunluk = 0
        if not uzunluk:
            return {}
        ham = self.rfile.read(uzunluk)
        try:
            return json.loads(ham.decode("utf-8"))
        except Exception:
            return {}

    def dosya_yanit(self, yol):
        if not os.path.isfile(yol):
            self.send_error(404, "Not Found")
            return
        uzanti = os.path.splitext(yol)[1].lower()
        tur = {
            ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".svg": "image/svg+xml", ".ico": "image/x-icon", ".webp": "image/webp",
            ".woff2": "font/woff2", ".txt": "text/plain; charset=utf-8",
        }.get(uzanti, "application/octet-stream")
        with open(yol, "rb") as f:
            govde = f.read()
        self.send_response(200)
        self.send_header("Content-Type", tur)
        self.send_header("Content-Length", str(len(govde)))
        if uzanti in (".html", ".css", ".js"):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.end_headers()
        try:
            self.wfile.write(govde)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _lisans_kapida_mi(self, yol):
        """Lisans durumu 'yetkili' değilse ilgisiz istekleri kurulum/kilit
        sayfasına yönlendirir. True dönerse yanıt zaten gönderilmiştir,
        çağıran taraf başka bir şey yapmamalıdır."""
        durum = lisans_durum().get("durum")
        if durum == "yetkili":
            return False
        if _lisans_statik_serbest_mi(yol):
            return False
        hedef = "/web/lisans-kur.html" if durum == "yok" else "/web/lisans-kilit.html"
        self.send_response(302)
        self.send_header("Location", hedef)
        self.send_header("Content-Length", "0")
        self.end_headers()
        return True

    # ================================================================ GET
    def do_GET(self):
        p = urlparse(self.path)
        yol = unquote(p.path)
        sorgu = parse_qs(p.query)
        if yol == "/api/okul-logo":
            # Okul logosu kişisel veri değildir; kilit ekranında da gösterilir.
            return self.dosya_yanit(OKUL_LOGO_YOLU)
        if self._lisans_kapida_mi(yol):
            return
        try:
            return self._do_get(yol, sorgu)
        except Exception as e:
            self.hata_yanit("Sunucu hatası: %s" % e, 500)

    def _do_get(self, yol, sorgu):
        if yol == "/" or yol == "":
            self.send_response(302)
            self.send_header("Location", "/web/panel.html")
            self.end_headers()
            return

        if yol == "/favicon.ico":
            return self.dosya_yanit(os.path.join(WEB, "assets", "favicon.ico"))

        if yol.startswith("/web/"):
            hedef = os.path.normpath(os.path.join(WEB, yol[len("/web/"):]))
            if hedef.startswith(os.path.normpath(WEB)):
                return self.dosya_yanit(hedef)
            return self.send_error(403)

        if yol == "/api/baslangic":
            return self.json_yanit({
                "surum": SURUM, "kullanici": kullanici_adi(), "bugun": tarih_yaz(bugun()),
                "ayarlar": ayarlar_oku(), "etiketler": etiketler_oku(),
                "etiketRenkleri": ETIKET_RENKLERI,
                "basvurmaSecenekleri": BASVURMA_SECENEKLERI, "konuSecenekleri": KONU_SECENEKLERI,
                "calismaSecenekleri": CALISMA_SECENEKLERI, "kurumSecenekleri": KURUM_SECENEKLERI,
                "siniflar": siniflar_oku(), "etkinlikTurleri": etkinlik_turleri_oku(),
                "toplantiTurleri": toplanti_turleri_oku(),
                "logoSurum": okul_logo_surum(),
                "kosulSurumu": KOSUL_SURUMU, "gelistirici": GELISTIRICI, "veriKlasoru": VERI,
            })

        if yol == "/api/kosullar":
            kabul = ayarlar_oku().get("kosulKabul") or {}
            return self.json_yanit({"surum": KOSUL_SURUMU, "kabul": kabul,
                                    "gerekli": kabul.get("surum") != KOSUL_SURUMU})

        if yol == "/api/panel":
            return self.json_yanit(panel_verisi())

        if yol == "/api/gundem":
            return self.json_yanit(gundem_verisi())

        if yol == "/api/takvim":
            bug = bugun()
            try:
                yil = int(sorgu.get("yil", [str(bug.year)])[0])
                ay = int(sorgu.get("ay", [str(bug.month)])[0])
            except ValueError:
                yil, ay = bug.year, bug.month
            return self.json_yanit(takvim_verisi(yil, ay))

        if yol == "/api/takvim-hafta":
            bug = bugun()
            tarih_p = tarih_coz((sorgu.get("tarih", [""])[0] or "")) or bug
            pazartesi = tarih_p - timedelta(days=tarih_p.weekday())
            return self.json_yanit(takvim_hafta_verisi(pazartesi))

        if yol == "/api/raporlar":
            return self.json_yanit(raporlar_verisi(sorgu))

        if yol == "/api/ogrenciler":
            return self.json_yanit(ogrenciler_listele(sorgu))

        if yol == "/api/yedekler":
            return self.json_yanit({"liste": yedekleri_listele(), "ayar": yedek_ayarlari(), "klasor": YEDEKLER_DIZIN})

        if yol == "/api/okul-paketleri":
            return self.json_yanit(okul_paketleri_listesi())

        if yol == "/api/okul-raporu":
            return self.json_yanit(okul_raporu_verisi(sorgu))

        if yol == "/api/okul-paketi/indir":
            paket = okul_paketi_olustur()
            govde = json.dumps(paket, ensure_ascii=False, indent=1).encode("utf-8")
            ad = re.sub(r"[^a-z0-9]+", "-", normalize(paket.get("ogretmen") or "ogretmen")).strip("-") or "ogretmen"
            dosya_adi = "okul-raporu-paketi_%s_%s.json" % (ad, datetime.now().strftime("%Y-%m-%d"))
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % dosya_adi)
            self.send_header("Content-Length", str(len(govde)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(govde)
            return

        if yol == "/api/yedekler/indir":
            try:
                dosya = _yedek_yolu((sorgu.get("ad", [""])[0] or ""))
            except ValueError as e:
                return self.hata_yanit(str(e), 404)
            with open(dosya, "rb") as f:
                govde = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % os.path.basename(dosya))
            self.send_header("Content-Length", str(len(govde)))
            self.end_headers()
            self.wfile.write(govde)
            return

        if yol == "/api/hatirlaticilar":
            return self.json_yanit(bugunun_hatirlaticilari())

        if yol == "/api/toplu-gorusmeler":
            try:
                return self.json_yanit(toplu_gorusmeler(sorgu))
            except ValueError as e:
                return self.hata_yanit(str(e), 400)

        m = re.match(r"^/api/ogrenci/([^/]+)$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/ogrenci/([^/]+)/gorusme/([^/]+)$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            g = next((x for x in k.get("gorusmeler") or [] if x["id"] == m.group(2)), None)
            if not g:
                return self.hata_yanit("Görüşme bulunamadı", 404)
            veri = dict(g)
            veri["ogrenci"] = {
                "id": k["id"], "adSoyad": k.get("adSoyad"), "sinif": k.get("sinif"),
                "cinsiyet": k.get("cinsiyet"), "okulNo": k.get("okulNo"),
                "veliAdSoyad": k.get("veliAdSoyad"), "veliYakinlik": k.get("veliYakinlik"),
                "veliTelefon": k.get("veliTelefon"), "toplamGorusme": len(k.get("gorusmeler") or []),
            }
            return self.json_yanit(veri)

        if yol == "/api/etiketler":
            return self.json_yanit(etiketler_oku())

        if yol == "/api/siniflar":
            return self.json_yanit(siniflar_oku())

        if yol == "/api/etkinlik-turleri":
            return self.json_yanit(etkinlik_turleri_oku())

        if yol == "/api/sinif-etkinlikleri":
            tur_sozluk = etkinlik_turu_sozlugu()
            hepsi_se = [sinif_etkinligi_ozet(se, tur_sozluk) for se in sinif_etkinlikleri_oku()]
            sinif_f = (sorgu.get("sinif", [""])[0] or "").strip()
            durum_f = (sorgu.get("durum", [""])[0] or "").strip()
            if sinif_f:
                hepsi_se = [se for se in hepsi_se if se.get("sinif") == sinif_f]
            if durum_f == "acik":
                hepsi_se = [se for se in hepsi_se if not se.get("tamamlandi")]
            elif durum_f == "tamamlandi":
                hepsi_se = [se for se in hepsi_se if se.get("tamamlandi")]
            hepsi_se.sort(key=lambda se: (tarih_coz(se.get("tarih")) or date.max, se.get("saat") or ""))
            return self.json_yanit({
                "kayitlar": hepsi_se,
                "siniflar": sorted({k.get("sinif") for k in tum_ogrenciler() if k.get("sinif")}),
            })

        if yol == "/api/toplanti-turleri":
            return self.json_yanit(toplanti_turleri_oku())

        if yol == "/api/toplantilar":
            tur_sozluk = toplanti_turu_sozlugu()
            hepsi_tp = [toplanti_ozet(tp, tur_sozluk) for tp in toplantilar_oku()]
            durum_f = (sorgu.get("durum", [""])[0] or "").strip()
            if durum_f == "acik":
                hepsi_tp = [tp for tp in hepsi_tp if not tp.get("tamamlandi")]
            elif durum_f == "tamamlandi":
                hepsi_tp = [tp for tp in hepsi_tp if tp.get("tamamlandi")]
            hepsi_tp.sort(key=lambda tp: (tarih_coz(tp.get("tarih")) or date.max, tp.get("baslangicSaati") or ""))
            return self.json_yanit({"kayitlar": hepsi_tp})

        if yol == "/api/ayarlar":
            return self.json_yanit(ayarlar_oku())

        if yol == "/api/lisans/durum":
            return self.json_yanit(lisans_durum())

        self.send_error(404, "Not Found")

    # ================================================================ POST
    def do_POST(self):
        p = urlparse(self.path)
        yol = unquote(p.path)
        if self._lisans_kapida_mi(yol):
            return
        try:
            return self._do_post(yol)
        except ValueError as e:
            self.hata_yanit(str(e), 400)
        except Exception as e:
            self.hata_yanit("Sunucu hatası: %s" % e, 500)

    def _icerik_turu_sinir(self):
        tur = self.headers.get("Content-Type", "")
        m = re.search(r"boundary=(.+)$", tur)
        return (m.group(1).strip('"').encode() if m else None), tur

    def _do_post(self, yol):
        if yol == "/api/ice-aktar/onizle":
            sinir, _ = self._icerik_turu_sinir()
            if not sinir:
                return self.hata_yanit("Geçersiz yükleme", 400)
            uzunluk = int(self.headers.get("Content-Length") or 0)
            govde = self.rfile.read(uzunluk)
            parcalar = multipart_coz(govde, sinir)
            dosya = next((p for p in parcalar if p["dosyaAdi"]), None)
            if not dosya:
                return self.hata_yanit("Dosya bulunamadı.", 400)
            subeler = ice_aktar_coz(dosya["dosyaAdi"], dosya["icerik"])
            if not subeler:
                return self.hata_yanit(
                    "Dosyadan öğrenci listesi okunamadı. Dosyanın e-Okul'un 'Sınıf Listesi' "
                    "çıktısı olduğundan emin olun.", 400)
            yeni, guncel = ice_aktar_onizle_hesapla(subeler)
            toplam_ogrenci = sum(len(s["ogrenciler"]) for s in subeler)
            return self.json_yanit({
                "subeler": subeler, "subeSayisi": len(subeler), "ogrenciSayisi": toplam_ogrenci,
                "yeniSayisi": yeni, "guncellenecekSayisi": guncel,
            })

        if yol == "/api/etkinlik-ice-aktar/onizle":
            sinir, _ = self._icerik_turu_sinir()
            if not sinir:
                return self.hata_yanit("Geçersiz yükleme", 400)
            uzunluk = int(self.headers.get("Content-Length") or 0)
            if uzunluk > 25 * 1024 * 1024:
                return self.hata_yanit("Dosya çok büyük (en fazla 25 MB).", 400)
            parcalar = multipart_coz(self.rfile.read(uzunluk), sinir)
            dosya = next((p for p in parcalar if p["dosyaAdi"]), None)
            if not dosya:
                return self.hata_yanit("Dosya bulunamadı.", 400)
            return self.json_yanit(etkinlik_plani_coz(dosya["dosyaAdi"], dosya["icerik"]))

        if yol == "/api/yedekler":
            return self.json_yanit({"tamam": True, "ad": yedek_al("elle")})

        if yol == "/api/okul-paketleri":
            return self.json_yanit(okul_paketi_ekle(self.govde_json_oku()))

        if yol == "/api/okul-paketleri/ayar":
            ayarlar_yaz({"okulRaporuKendiDahil": bool(self.govde_json_oku().get("kendiDahil", True))})
            return self.json_yanit(okul_paketleri_listesi())

        if yol == "/api/kosullar/kabul":
            ayarlar_yaz({"kosulKabul": {"surum": KOSUL_SURUMU, "tarih": datetime.now().strftime("%d.%m.%Y %H:%M")}})
            return self.json_yanit({"tamam": True, "surum": KOSUL_SURUMU})

        if yol == "/api/yedekler/geri-yukle":
            once = yedekten_geri_don((self.govde_json_oku().get("ad") or "").strip())
            return self.json_yanit({"tamam": True, "onceki": once})

        if yol == "/api/hatirlaticilar/tamamla":
            if not hatirlatici_tamamla(self.govde_json_oku()):
                return self.hata_yanit("Kayıt bulunamadı (silinmiş olabilir).", 404)
            return self.json_yanit({"tamam": True})

        if yol == "/api/etkinlik-ice-aktar/uygula":
            return self.json_yanit(etkinlik_plani_uygula(self.govde_json_oku()))

        if yol == "/api/ice-aktar/uygula":
            veri = self.govde_json_oku()
            subeler = veri.get("subeler") or []
            if not subeler:
                return self.hata_yanit("İçe aktarılacak veri yok.", 400)
            yeni, guncel = ice_aktar_uygula(subeler)
            return self.json_yanit({"tamam": True, "yeniSayisi": yeni, "guncellenenSayisi": guncel})

        if yol == "/api/lisans/kur":
            veri = self.govde_json_oku()
            if lisans_oku():
                return self.hata_yanit("Program bu bilgisayarda zaten etkinleştirilmiş.", 400)
            sifre = (veri.get("sifre") or "").strip()
            if len(sifre) < 4:
                return self.hata_yanit("Şifre en az 4 karakter olmalıdır.", 400)
            if not veri.get("kosulKabul"):
                return self.hata_yanit("Devam etmek için Kullanım Koşulları'nı kabul etmelisiniz.", 400)
            lisans_kur(sifre)
            ayarlar_yaz({"kosulKabul": {"surum": KOSUL_SURUMU, "tarih": datetime.now().strftime("%d.%m.%Y %H:%M")}})
            return self.json_yanit(lisans_durum())

        if yol == "/api/lisans/coz":
            veri = self.govde_json_oku()
            if not lisans_coz((veri.get("sifre") or "").strip()):
                return self.hata_yanit("Şifre yanlış.", 401)
            return self.json_yanit(lisans_durum())

        if yol == "/api/lisans/sifre-degistir":
            veri = self.govde_json_oku()
            yeni = (veri.get("yeniSifre") or "").strip()
            if len(yeni) < 4:
                return self.hata_yanit("Yeni şifre en az 4 karakter olmalıdır.", 400)
            if not lisans_sifre_degistir((veri.get("eskiSifre") or "").strip(), yeni):
                return self.hata_yanit("Mevcut şifre yanlış.", 401)
            return self.json_yanit({"tamam": True})

        veri = self.govde_json_oku()

        if yol == "/api/ogrenci":
            if not (veri.get("adSoyad") or "").strip():
                return self.hata_yanit("Adı soyadı zorunludur.", 400)
            k = yeni_ogrenci_kaydi(veri)
            if k.get("sinif") and k.get("sinifOgretmeni"):
                sinif_ogretmeni_guncelle(k["sinif"], k["sinifOgretmeni"])
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k), 201)

        m = re.match(r"^/api/ogrenci/([^/]+)/etiket$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            etiket_id = veri.get("etiketId")
            ekle = bool(veri.get("ekle"))
            etiketler = set(k.get("etiketler") or [])
            if ekle:
                etiketler.add(etiket_id)
            else:
                etiketler.discard(etiket_id)
            k["etiketler"] = list(etiketler)
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/ogrenci/([^/]+)/zamanlama$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            if not (veri.get("tarih") or "").strip() or not (veri.get("metin") or "").strip():
                return self.hata_yanit("Tarih ve metin zorunludur.", 400)
            z = {"id": yeni_id(), "tarih": veri.get("tarih").strip(),
                 "saat": (veri.get("saat") or "").strip(),
                 "metin": veri.get("metin").strip(), "tamamlandi": False,
                 "olusturma": simdi_iso()}
            k.setdefault("zamanlamalar", []).append(z)
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k), 201)

        m = re.match(r"^/api/ogrenci/([^/]+)/zamanlama/([^/]+)/tamamla$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            for z in k.get("zamanlamalar") or []:
                if z["id"] == m.group(2):
                    z["tamamlandi"] = not z.get("tamamlandi")
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/ogrenci/([^/]+)/yorum$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            if not (veri.get("metin") or "").strip():
                return self.hata_yanit("Yorum metni boş olamaz.", 400)
            ayar = ayarlar_oku()
            y = {"id": yeni_id(), "yazan": ayar.get("rehberAdSoyad") or kullanici_adi(),
                 "tarih": simdi_goster(), "metin": veri.get("metin").strip(),
                 "olusturma": simdi_iso()}
            k.setdefault("yorumlar", []).append(y)
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k), 201)

        m = re.match(r"^/api/ogrenci/([^/]+)/gorusme$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            tur = veri.get("tur")
            if tur not in ("ogrenci", "veli"):
                return self.hata_yanit("Görüşme türü geçersiz.", 400)
            g = _gorusme_alanlarini_hazirla(veri, tur, yeni=True)
            k.setdefault("gorusmeler", []).append(g)
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k), 201)

        if yol == "/api/etiketler":
            ad = (veri.get("ad") or "").strip()
            renk = veri.get("renk") or "mavi"
            if not ad:
                return self.hata_yanit("Etiket adı zorunludur.", 400)
            if renk not in ETIKET_RENKLERI:
                renk = "mavi"
            e = etiketler_oku()
            e.append({"id": yeni_id(), "ad": ad, "renk": renk})
            etiketler_yaz(e)
            return self.json_yanit(e, 201)

        if yol == "/api/siniflar":
            sinif = (veri.get("sinif") or "").strip()
            if not sinif:
                return self.hata_yanit("Sınıf adı zorunludur.", 400)
            sinif_ogretmeni_guncelle(sinif, (veri.get("ogretmen") or "").strip())
            return self.json_yanit(siniflar_oku())

        if yol == "/api/etkinlik-turleri":
            ad = (veri.get("ad") or "").strip()
            if not ad:
                return self.hata_yanit("Etkinlik türü adı zorunludur.", 400)
            e = etkinlik_turleri_oku()
            if any(normalize(x["ad"]) == normalize(ad) for x in e):
                return self.hata_yanit("Bu adda bir etkinlik türü zaten var.", 400)
            yeni_tur = {"id": yeni_id(), "ad": ad}
            e.append(yeni_tur)
            etkinlik_turleri_yaz(e)
            return self.json_yanit(e, 201)

        if yol == "/api/sinif-etkinlikleri":
            sinif = (veri.get("sinif") or "").strip()
            etkinlik_turu_id = (veri.get("etkinlikTuruId") or "").strip()
            tarih = (veri.get("tarih") or "").strip()
            if not sinif or not etkinlik_turu_id or not tarih:
                return self.hata_yanit("Sınıf, etkinlik türü ve tarih zorunludur.", 400)
            if etkinlik_turu_id not in etkinlik_turu_sozlugu():
                return self.hata_yanit("Etkinlik türü bulunamadı.", 404)
            se = {
                "id": yeni_id(), "etkinlikTuruId": etkinlik_turu_id, "sinif": sinif,
                "tarih": tarih, "saat": (veri.get("saat") or "").strip(),
                "aciklama": (veri.get("aciklama") or "").strip(),
                "tamamlandi": False, "olusturma": simdi_iso(),
            }
            liste = sinif_etkinlikleri_oku()
            liste.append(se)
            sinif_etkinlikleri_yaz(liste)
            return self.json_yanit(sinif_etkinligi_ozet(se, etkinlik_turu_sozlugu()), 201)

        m = re.match(r"^/api/sinif-etkinlikleri/([^/]+)/tamamla$", yol)
        if m:
            liste = sinif_etkinlikleri_oku()
            bulundu = None
            for se in liste:
                if se["id"] == m.group(1):
                    se["tamamlandi"] = not se.get("tamamlandi")
                    bulundu = se
            if not bulundu:
                return self.hata_yanit("Sınıf etkinliği bulunamadı", 404)
            sinif_etkinlikleri_yaz(liste)
            return self.json_yanit(sinif_etkinligi_ozet(bulundu, etkinlik_turu_sozlugu()))

        if yol == "/api/toplanti-turleri":
            ad = (veri.get("ad") or "").strip()
            if not ad:
                return self.hata_yanit("Toplantı türü adı zorunludur.", 400)
            t = toplanti_turleri_oku()
            if any(normalize(x["ad"]) == normalize(ad) for x in t):
                return self.hata_yanit("Bu adda bir toplantı türü zaten var.", 400)
            yeni_tur = {"id": yeni_id(), "ad": ad}
            t.append(yeni_tur)
            toplanti_turleri_yaz(t)
            return self.json_yanit(t, 201)

        if yol == "/api/toplantilar":
            toplanti_turu_id = (veri.get("toplantiTuruId") or "").strip()
            tarih = (veri.get("tarih") or "").strip()
            if not toplanti_turu_id or not tarih:
                return self.hata_yanit("Toplantı türü ve tarih zorunludur.", 400)
            if toplanti_turu_id not in toplanti_turu_sozlugu():
                return self.hata_yanit("Toplantı türü bulunamadı.", 404)
            bas_saat = (veri.get("baslangicSaati") or "").strip()
            bit_saat = (veri.get("bitisSaati") or "").strip()
            if bas_saat and bit_saat and bit_saat <= bas_saat:
                return self.hata_yanit("Bitiş saati başlangıç saatinden sonra olmalıdır.", 400)
            tp = {
                "id": yeni_id(), "toplantiTuruId": toplanti_turu_id,
                "tarih": tarih, "baslangicSaati": bas_saat, "bitisSaati": bit_saat,
                "aciklama": (veri.get("aciklama") or "").strip(),
                "tamamlandi": False, "olusturma": simdi_iso(),
            }
            liste = toplantilar_oku()
            liste.append(tp)
            toplantilar_yaz(liste)
            return self.json_yanit(toplanti_ozet(tp, toplanti_turu_sozlugu()), 201)

        m = re.match(r"^/api/toplantilar/([^/]+)/tamamla$", yol)
        if m:
            liste = toplantilar_oku()
            bulundu = None
            for tp in liste:
                if tp["id"] == m.group(1):
                    tp["tamamlandi"] = not tp.get("tamamlandi")
                    bulundu = tp
            if not bulundu:
                return self.hata_yanit("Toplantı bulunamadı", 404)
            toplantilar_yaz(liste)
            return self.json_yanit(toplanti_ozet(bulundu, toplanti_turu_sozlugu()))

        self.send_error(404, "Not Found")

    # ================================================================ PUT
    def do_PUT(self):
        p = urlparse(self.path)
        yol = unquote(p.path)
        if self._lisans_kapida_mi(yol):
            return
        try:
            return self._do_put(yol)
        except ValueError as e:
            self.hata_yanit(str(e), 400)
        except Exception as e:
            self.hata_yanit("Sunucu hatası: %s" % e, 500)

    def _do_put(self, yol):
        if yol == "/api/okul-logo":
            uzunluk = int(self.headers.get("Content-Length") or 0)
            if uzunluk > OKUL_LOGO_AZAMI * 2:
                return self.hata_yanit("Logo dosyası çok büyük (en fazla 3 MB).", 400)
            veri = self.govde_json_oku()
            return self.json_yanit({"tamam": True, "logoSurum": okul_logo_yaz(veri.get("resim"))})

        veri = self.govde_json_oku()

        if yol == "/api/ayarlar":
            return self.json_yanit(ayarlar_yaz(veri))

        m = re.match(r"^/api/ogrenci/([^/]+)$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            for alan in ("okulNo", "adSoyad", "sinif", "cinsiyet", "dogumTarihi",
                         "sinifOgretmeni", "veliAdSoyad", "veliYakinlik", "veliTelefon"):
                if alan in veri:
                    k[alan] = str(veri[alan] or "").strip()
            if k.get("sinif") and k.get("sinifOgretmeni"):
                sinif_ogretmeni_guncelle(k["sinif"], k["sinifOgretmeni"])
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/ogrenci/([^/]+)/not$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            k["genelNot"] = veri.get("metin") or ""
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/ogrenci/([^/]+)/gorusme/([^/]+)$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            gorusmeler = k.get("gorusmeler") or []
            idx = next((i for i, g in enumerate(gorusmeler) if g["id"] == m.group(2)), None)
            if idx is None:
                return self.hata_yanit("Görüşme bulunamadı", 404)
            mevcut = gorusmeler[idx]
            g = _gorusme_alanlarini_hazirla(veri, mevcut.get("tur"), yeni=False, mevcut=mevcut)
            gorusmeler[idx] = g
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/sinif-etkinlikleri/([^/]+)$", yol)
        if m:
            liste = sinif_etkinlikleri_oku()
            se = next((x for x in liste if x["id"] == m.group(1)), None)
            if not se:
                return self.hata_yanit("Sınıf etkinliği bulunamadı", 404)
            if "etkinlikTuruId" in veri:
                etkinlik_turu_id = (veri.get("etkinlikTuruId") or "").strip()
                if etkinlik_turu_id not in etkinlik_turu_sozlugu():
                    return self.hata_yanit("Etkinlik türü bulunamadı.", 404)
                se["etkinlikTuruId"] = etkinlik_turu_id
            if "sinif" in veri:
                sinif = (veri.get("sinif") or "").strip()
                if not sinif:
                    return self.hata_yanit("Sınıf adı zorunludur.", 400)
                se["sinif"] = sinif
            if "tarih" in veri:
                tarih = (veri.get("tarih") or "").strip()
                if not tarih:
                    return self.hata_yanit("Tarih zorunludur.", 400)
                se["tarih"] = tarih
            if "saat" in veri:
                se["saat"] = (veri.get("saat") or "").strip()
            if "aciklama" in veri:
                se["aciklama"] = (veri.get("aciklama") or "").strip()
            sinif_etkinlikleri_yaz(liste)
            return self.json_yanit(sinif_etkinligi_ozet(se, etkinlik_turu_sozlugu()))

        m = re.match(r"^/api/toplantilar/([^/]+)$", yol)
        if m:
            liste = toplantilar_oku()
            tp = next((x for x in liste if x["id"] == m.group(1)), None)
            if not tp:
                return self.hata_yanit("Toplantı bulunamadı", 404)
            if "toplantiTuruId" in veri:
                toplanti_turu_id = (veri.get("toplantiTuruId") or "").strip()
                if toplanti_turu_id not in toplanti_turu_sozlugu():
                    return self.hata_yanit("Toplantı türü bulunamadı.", 404)
                tp["toplantiTuruId"] = toplanti_turu_id
            if "tarih" in veri:
                tarih = (veri.get("tarih") or "").strip()
                if not tarih:
                    return self.hata_yanit("Tarih zorunludur.", 400)
                tp["tarih"] = tarih
            if "baslangicSaati" in veri:
                tp["baslangicSaati"] = (veri.get("baslangicSaati") or "").strip()
            if "bitisSaati" in veri:
                tp["bitisSaati"] = (veri.get("bitisSaati") or "").strip()
            if tp.get("baslangicSaati") and tp.get("bitisSaati") and tp["bitisSaati"] <= tp["baslangicSaati"]:
                return self.hata_yanit("Bitiş saati başlangıç saatinden sonra olmalıdır.", 400)
            if "aciklama" in veri:
                tp["aciklama"] = (veri.get("aciklama") or "").strip()
            toplantilar_yaz(liste)
            return self.json_yanit(toplanti_ozet(tp, toplanti_turu_sozlugu()))

        self.send_error(404, "Not Found")

    # ================================================================ DELETE
    def do_DELETE(self):
        p = urlparse(self.path)
        yol = unquote(p.path)
        if self._lisans_kapida_mi(yol):
            return
        try:
            return self._do_delete(yol)
        except Exception as e:
            self.hata_yanit("Sunucu hatası: %s" % e, 500)

    def _do_delete(self, yol):
        m = re.match(r"^/api/okul-paketleri/([0-9a-f]{32})$", yol)
        if m:
            yol_p = _paket_yolu(m.group(1))
            if os.path.isfile(yol_p):
                os.remove(yol_p)
            return self.json_yanit(okul_paketleri_listesi())

        if yol == "/api/okul-logo":
            if os.path.isfile(OKUL_LOGO_YOLU):
                os.remove(OKUL_LOGO_YOLU)
            return self.json_yanit({"tamam": True, "logoSurum": 0})

        m = re.match(r"^/api/ogrenci/([^/]+)$", yol)
        if m:
            if not ogrenci_oku(m.group(1)):
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            ogrenci_sil(m.group(1))
            return self.json_yanit({"tamam": True})

        m = re.match(r"^/api/ogrenci/([^/]+)/zamanlama/([^/]+)$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            k["zamanlamalar"] = [z for z in k.get("zamanlamalar") or [] if z["id"] != m.group(2)]
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/ogrenci/([^/]+)/gorusme/([^/]+)$", yol)
        if m:
            k = ogrenci_oku(m.group(1))
            if not k:
                return self.hata_yanit("Öğrenci bulunamadı", 404)
            k["gorusmeler"] = [g for g in k.get("gorusmeler") or [] if g["id"] != m.group(2)]
            ogrenci_yaz(k)
            return self.json_yanit(ogrenci_detay(k))

        m = re.match(r"^/api/etiketler/([^/]+)$", yol)
        if m:
            e = etiketler_oku()
            e2 = [x for x in e if x["id"] != m.group(1)]
            etiketler_yaz(e2)
            for k in tum_ogrenciler():
                if m.group(1) in (k.get("etiketler") or []):
                    k["etiketler"] = [x for x in k["etiketler"] if x != m.group(1)]
                    ogrenci_yaz(k)
            return self.json_yanit(e2)

        m = re.match(r"^/api/etkinlik-turleri/([^/]+)$", yol)
        if m:
            e = etkinlik_turleri_oku()
            e2 = [x for x in e if x["id"] != m.group(1)]
            etkinlik_turleri_yaz(e2)
            # bu türe bağlı planlanmış sınıf etkinlikleri de anlamsız kalacağından
            # (etiket silme davranışının aksine, bu kayıtların kendisi tür'e bağımlı
            # olduğundan) birlikte kaldırılır.
            liste = sinif_etkinlikleri_oku()
            liste2 = [se for se in liste if se.get("etkinlikTuruId") != m.group(1)]
            if len(liste2) != len(liste):
                sinif_etkinlikleri_yaz(liste2)
            return self.json_yanit(e2)

        m = re.match(r"^/api/sinif-etkinlikleri/([^/]+)$", yol)
        if m:
            liste = sinif_etkinlikleri_oku()
            liste2 = [se for se in liste if se["id"] != m.group(1)]
            if len(liste2) == len(liste):
                return self.hata_yanit("Sınıf etkinliği bulunamadı", 404)
            sinif_etkinlikleri_yaz(liste2)
            return self.json_yanit({"tamam": True})

        m = re.match(r"^/api/toplanti-turleri/([^/]+)$", yol)
        if m:
            t = toplanti_turleri_oku()
            t2 = [x for x in t if x["id"] != m.group(1)]
            toplanti_turleri_yaz(t2)
            # sınıf etkinliği türlerinde olduğu gibi, bu türe bağlı planlanmış
            # toplantılar da tür'e bağımlı olduğundan birlikte kaldırılır.
            liste = toplantilar_oku()
            liste2 = [tp for tp in liste if tp.get("toplantiTuruId") != m.group(1)]
            if len(liste2) != len(liste):
                toplantilar_yaz(liste2)
            return self.json_yanit(t2)

        m = re.match(r"^/api/toplantilar/([^/]+)$", yol)
        if m:
            liste = toplantilar_oku()
            liste2 = [tp for tp in liste if tp["id"] != m.group(1)]
            if len(liste2) == len(liste):
                return self.hata_yanit("Toplantı bulunamadı", 404)
            toplantilar_yaz(liste2)
            return self.json_yanit({"tamam": True})

        self.send_error(404, "Not Found")


def _gorusme_alanlarini_hazirla(veri, tur, yeni, mevcut=None):
    g = dict(mevcut) if mevcut else {}
    g["id"] = g.get("id") or yeni_id()
    g["tur"] = tur
    g["tarih"] = (veri.get("tarih") or g.get("tarih") or tarih_yaz(bugun())).strip()
    if "saat" in veri:                           # görüşme saati (ss:dd) — boş bırakılabilir
        saat = (veri.get("saat") or "").strip().replace(".", ":")
        m = re.fullmatch(r"([01]?\d|2[0-3]):([0-5]\d)", saat)
        if saat and not m:
            raise ValueError("Görüşme saati ss:dd biçiminde olmalıdır (ör. 10:30).")
        g["saat"] = ("%02d:%s" % (int(m.group(1)), m.group(2))) if m else ""
    g["konu"] = list(veri.get("konu") or [])
    g["notMetin"] = veri.get("notMetin") or ""
    if tur == "ogrenci":
        g["basvurma"] = list(veri.get("basvurma") or [])
        g["calisma"] = list(veri.get("calisma") or [])
        g["sonucOneri"] = veri.get("sonucOneri") or ""
        g["yonlendirilenKurum"] = list(veri.get("yonlendirilenKurum") or [])
    else:
        g["isbirligi"] = veri.get("isbirligi") or ""
    if yeni:
        g["olusturma"] = simdi_iso()
    g["guncelleme"] = simdi_iso()
    return g


# ---------------------------------------------------------------- örnek kayıt (ilk çalıştırma)

def ornek_kayit_olustur_gerekirse():
    """İlk çalıştırmada programın nasıl göründüğünü göstermek için TEK bir örnek
    kayıt ekler. Kayıttaki tüm bilgiler uydurma yer tutuculardır (gerçek kişi,
    okul, telefon ya da sağlık bilgisi içermez); okul/öğretmen ayarlarına
    dokunulmaz, kullanıcı kendisi girer."""
    if tum_ogrenciler():
        return
    bug = bugun()
    t1 = tarih_yaz(bug - timedelta(days=7))
    t2 = tarih_yaz(bug)
    k = yeni_ogrenci_kaydi({
        "okulNo": "0001", "adSoyad": "ÖRNEK ÖĞRENCİ", "sinif": "1/A", "cinsiyet": "K",
        "dogumTarihi": "", "sinifOgretmeni": "Örnek Sınıf Öğretmeni",
        "veliAdSoyad": "Örnek Veli", "veliYakinlik": "Anne", "veliTelefon": "",
        "etiketler": [],
    })
    k["genelNot"] = ("Bu bir örnek kayıttır; programın nasıl çalıştığını göstermek için eklenmiştir. "
                     "Gerçek veri girmeden önce bu kaydı silebilirsiniz.")
    k["gorusmeler"] = [
        {"id": yeni_id(), "tur": "ogrenci", "tarih": t1, "saat": "10:00", "basvurma": ["Öğretmenin İsteğiyle"],
         "konu": ["Okula ve Çevreye Uyum"], "calisma": ["Kişisel Rehberlik"],
         "notMetin": "Örnek görüşme notu: görüşmede konuşulan konular buraya yazılır.",
         "sonucOneri": "Örnek sonuç ve öneri metni.", "yonlendirilenKurum": [],
         "olusturma": simdi_iso(), "guncelleme": simdi_iso()},
        {"id": yeni_id(), "tur": "veli", "tarih": t2, "saat": "14:00", "konu": ["Okula ve Çevreye Uyum"],
         "isbirligi": "",
         "notMetin": "Örnek veli görüşmesi notu: veliyle konuşulanlar buraya yazılır.",
         "olusturma": simdi_iso(), "guncelleme": simdi_iso()},
    ]
    k["zamanlamalar"] = [
        {"id": yeni_id(), "tarih": tarih_yaz(bug + timedelta(days=7)), "saat": "10:30",
         "metin": "Örnek hatırlatma: takip görüşmesi yapılacak", "tamamlandi": False, "olusturma": simdi_iso()},
    ]
    k["yorumlar"] = []
    ogrenci_yaz(k)


# ---------------------------------------------------------------- port bulma / başlatma

def bos_port(tercih=8090, deneme=40):
    for p in range(tercih, tercih + deneme):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def calisan_ornek_bul():
    """Bu bilgisayarda program zaten açıksa portunu ve sürümünü döndürür.
    /api/lisans/durum lisans durumu ne olursa olsun (kurulmamış/izinli/
    kilitli/yetkili) her zaman yanıt verdiği için "zaten açık mı" kontrolü
    bunun üzerinden yapılır; sürüm bilgisi ise (varsa) ayrıca ve en iyi
    çaba ("best effort") ile /api/baslangic'ten alınmaya çalışılır."""
    import urllib.request
    for port in range(8090, 8130):
        try:
            istek = urllib.request.urlopen(
                "http://127.0.0.1:%d/api/lisans/durum" % port, timeout=0.4)
            veri = json.loads(istek.read().decode("utf-8"))
            if "durum" not in veri:
                continue
            surum = ""
            try:
                istek2 = urllib.request.urlopen(
                    "http://127.0.0.1:%d/api/baslangic" % port, timeout=0.4)
                veri2 = json.loads(istek2.read().decode("utf-8"))
                surum = str(veri2.get("surum") or "")
            except Exception:
                pass
            return port, surum
        except Exception:
            continue
    return 0, ""


# Bu değişken bilerek modül seviyesinde tutulur: içindeki dosya tanıtıcısı
# (file handle) program çalıştığı sürece AÇIK kalmalı ki işletim sistemi
# kilidi elde tutsun. Kapansa (veya çöp toplansa) kilit anında serbest kalır.
_TEKIL_ORNEK_DOSYASI = None


# ---------------------------------------------------------------- otomatik yedekleme
#
# Her gün (program açıkken) veri klasörünün tamamı tek bir zip olarak
# veri/yedekler/ içine alınır. Ayarlar > Yedekler'den istenen tarihe geri dönülebilir;
# geri dönmeden önce o anki durum da "geri dönüş öncesi" yedeği olarak saklanır,
# yani geri dönüş de geri alınabilir. İsteğe bağlı ikinci bir klasöre (USB bellek,
# başka disk) kopya bırakılabilir. İnternet kullanılmaz.

YEDEKLER_DIZIN = os.path.join(VERI, "yedekler")
_YEDEK_DISI = {"yedekler", "yedek", ".calisma.kilit"}
_YEDEK_TURLERI = {"otomatik": "Günlük otomatik", "elle": "Elle alınan", "geri-donus-oncesi": "Geri dönüş öncesi"}
_yedek_kilit = threading.Lock()


def yedek_ayarlari():
    a = {"gun": 30, "ekKlasor": ""}
    a.update(ayarlar_oku().get("yedek") or {})
    return a


def _veri_sayilari():
    ogr = tum_ogrenciler()
    return len(ogr), sum(len(k.get("gorusmeler") or []) for k in ogr)


def yedek_al(tur="elle"):
    with _yedek_kilit:
        os.makedirs(YEDEKLER_DIZIN, exist_ok=True)
        an = datetime.now()
        ad = "yedek-%s-%s.zip" % (an.strftime("%Y-%m-%d_%H%M%S"), tur)
        hedef = os.path.join(YEDEKLER_DIZIN, ad)
        gecici = hedef + ".gecici"
        ogr, gor = _veri_sayilari()
        with _kilit:
            with zipfile.ZipFile(gecici, "w", zipfile.ZIP_DEFLATED) as z:
                for kok, dizinler, dosyalar in os.walk(VERI):
                    goreli_kok = os.path.relpath(kok, VERI)
                    if goreli_kok == ".":
                        dizinler[:] = [d for d in dizinler if d not in _YEDEK_DISI]
                    for f in dosyalar:
                        if f in _YEDEK_DISI or ".gecici" in f:
                            continue
                        tam = os.path.join(kok, f)
                        z.write(tam, os.path.relpath(tam, VERI).replace(os.sep, "/"))
                z.writestr("_yedek.json", json.dumps({
                    "tarih": an.strftime("%d.%m.%Y %H:%M"), "tur": tur, "surum": SURUM,
                    "ogrenci": ogr, "gorusme": gor}, ensure_ascii=False))
        os.replace(gecici, hedef)
        ek = (yedek_ayarlari().get("ekKlasor") or "").strip()
        if ek:
            try:
                os.makedirs(ek, exist_ok=True)
                shutil.copy2(hedef, os.path.join(ek, ad))
            except OSError as e:
                print(" Ek yedek klasörüne yazılamadı: %s" % e)
        yedekleri_temizle()
        return ad


def yedekleri_listele():
    liste = []
    if os.path.isdir(YEDEKLER_DIZIN):
        for ad in sorted(os.listdir(YEDEKLER_DIZIN), reverse=True):
            if not (ad.startswith("yedek-") and ad.endswith(".zip")):
                continue
            yol = os.path.join(YEDEKLER_DIZIN, ad)
            bilgi = {}
            try:
                with zipfile.ZipFile(yol) as z:
                    bilgi = json.loads(z.read("_yedek.json").decode("utf-8"))
            except Exception:
                pass
            tur = bilgi.get("tur") or ad.rsplit("-", 1)[-1][:-4]
            liste.append({"ad": ad, "tarih": bilgi.get("tarih") or "", "tur": tur,
                          "turAdi": _YEDEK_TURLERI.get(tur, tur), "ogrenci": bilgi.get("ogrenci"),
                          "gorusme": bilgi.get("gorusme"), "boyut": os.path.getsize(yol)})
    return liste


def yedekleri_temizle():
    gun = int(yedek_ayarlari().get("gun") or 30)
    sinir = datetime.now() - timedelta(days=gun)
    for y in yedekleri_listele():
        try:
            t = datetime.strptime(y["ad"][6:23], "%Y-%m-%d_%H%M%S")
        except ValueError:
            continue
        if t < sinir and y["tur"] != "elle":       # elle alınanlar siz silene kadar kalır
            try:
                os.remove(os.path.join(YEDEKLER_DIZIN, y["ad"]))
            except OSError:
                pass


def _yedek_yolu(ad):
    if not re.fullmatch(r"yedek-[\w.-]+\.zip", ad or ""):
        raise ValueError("Geçersiz yedek adı.")
    yol = os.path.join(YEDEKLER_DIZIN, ad)
    if not os.path.isfile(yol):
        raise ValueError("Yedek bulunamadı.")
    return yol


def yedekten_geri_don(ad):
    yol = _yedek_yolu(ad)
    with zipfile.ZipFile(yol) as z:
        adlar = [n for n in z.namelist() if n != "_yedek.json"]
        for n in adlar:
            if n.startswith("/") or ".." in n.split("/") or ":" in n:
                raise ValueError("Yedek dosyası bozuk görünüyor.")
        if not any(n == "ayarlar.json" or n.startswith("ogrenciler/") for n in adlar):
            raise ValueError("Bu dosya bu programın yedeği değil.")
    once = yedek_al("geri-donus-oncesi")          # geri dönüş de geri alınabilsin
    with _kilit:
        for ad_ in os.listdir(VERI):
            if ad_ in _YEDEK_DISI or ad_ == "lisans.json":
                continue
            tam = os.path.join(VERI, ad_)
            if os.path.isdir(tam):
                shutil.rmtree(tam, ignore_errors=True)
            else:
                try:
                    os.remove(tam)
                except OSError:
                    pass
        with zipfile.ZipFile(yol) as z:
            for n in z.namelist():
                if n in ("_yedek.json", "lisans.json") or n.endswith("/"):
                    continue
                hedef = os.path.join(VERI, *n.split("/"))
                os.makedirs(os.path.dirname(hedef), exist_ok=True)
                with z.open(n) as kaynak, open(hedef, "wb") as f:
                    shutil.copyfileobj(kaynak, f)
        ogrencileri_yukle()
    return once


def _gunluk_yedek_dongusu():
    time.sleep(20)
    while True:
        try:
            bugun_ek = datetime.now().strftime("yedek-%Y-%m-%d")
            if not any(y["ad"].startswith(bugun_ek) and y["tur"] == "otomatik" for y in yedekleri_listele()):
                print(" Günlük yedek alındı: " + yedek_al("otomatik"))
        except Exception as e:
            print(" Günlük yedek alınamadı: %s" % e)
        time.sleep(30 * 60)


def tekil_ornek_kilidi_al():
    """Bu bilgisayarda aynı anda yalnızca bir kopyanın veri klasörüne
    yazmasını garanti eder — işletim sistemi seviyesinde "advisory lock"
    kullanır (dosya kilidi programın PID'siyle değil, açık dosya
    tanıtıcısıyla ilişkilidir; bu yüzden program aniden kapansa/çökse
    bile Windows/Mac/Linux kilidi anında kendiliğinden serbest bırakır —
    "bayat kilit dosyası" temizliği gerekmez).

    Önceki sürümde "zaten açık mı" kontrolü yalnızca bir HTTP isteğiyle
    yapılıyordu; önceki kopya tam o anda dosyaya yazıyorsa (örn. ilk
    kurulumda örnek kayıt oluşturulurken) veya HTTP sunucusu henüz ayağa
    kalkmadıysa bu kontrol kaçırılabiliyor, iki kopya aynı anda aynı
    dosyaya yazmaya çalışıp Windows'ta "dosya başka bir işlem tarafından
    kullanılıyor" hatasına yol açabiliyordu. Bu fonksiyon o yarışı
    (race condition) baştan engeller.

    Döner: True  -> kilit bu süreçte alındı, güvenle devam edilebilir.
            False -> başka bir kopya hâlihazırda kilidi tutuyor.
    """
    global _TEKIL_ORNEK_DOSYASI
    yol = os.path.join(VERI, ".calisma.kilit")
    try:
        f = open(yol, "a+")
    except OSError:
        return True  # kilit dosyası açılamıyorsa engellemeyelim, program yine çalışsın

    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return False

    _TEKIL_ORNEK_DOSYASI = f  # açık tut — kilidi serbest bırakmasın
    return True


def main():
    if not tekil_ornek_kilidi_al():
        # Başka bir kopya veri klasörünü kullanıyor. Onun adresini bulup
        # tarayıcıyı oraya yönlendirmeyi dene; bulunamazsa kullanıcıyı
        # bilgilendir (dosyaları bozmamak için burada devam etmiyoruz).
        acik, acik_surum = calisan_ornek_bul()
        print("=" * 62)
        if acik:
            adres = "http://localhost:%d/" % acik
            print(" Program zaten açık: " + adres)
            print(" Tarayıcı o pencereye yönlendiriliyor. Bu pencereyi kapatabilirsiniz.")
            if acik_surum and acik_surum != SURUM:
                print()
                print(" UYARI: Açık olan kopya ESKİ bir sürüm (%s), diskteki dosyalar ise" % acik_surum)
                print(" güncellenmiş (%s). Program dosyalarını güncellediyseniz ama hâlâ" % SURUM)
                print(" eski davranışı görüyorsanız, muhtemelen arka planda/simge durumunda")
                print(" eski program penceresi hâlâ açık kalmıştır. O pencereyi (varsa görev")
                print(" çubuğunda) bulup KAPATIN veya bilgisayarı yeniden başlatın, ardından")
                print(" bu dosyayı (Baslat.bat) tekrar çalıştırın.")
            webbrowser.open(adres)
        else:
            print(" Program zaten başka bir pencerede çalışıyor gibi görünüyor.")
            print(" Lütfen açık olan pencereyi bulup oradan devam edin; bulamazsanız")
            print(" birkaç saniye bekleyip bu dosyayı tekrar çalıştırın.")
        print("=" * 62)
        return

    try:
        ogrencileri_yukle()
        ornek_kayit_olustur_gerekirse()
        port = bos_port()
        sunucu = ThreadingHTTPServer(("127.0.0.1", port), Istek)
    except OSError as e:
        print("=" * 62)
        print(" Program başlatılırken bir dosya erişim sorunu oluştu:")
        print(" " + str(e))
        print()
        print(" Bu genellikle geçicidir (örn. antivirüs programı dosyayı")
        print(" o an taradığı için). Birkaç saniye bekleyip bu dosyayı")
        print(" tekrar çalıştırmayı deneyin. Sorun devam ederse bilgisayarı")
        print(" yeniden başlatıp tekrar deneyin.")
        print("=" * 62)
        sys.exit(1)

    adres = "http://localhost:%d/" % port
    print("=" * 62)
    print(" ÖĞRENCİ REHBERLİK TAKİP SİSTEMİ  (sürüm %s)" % SURUM)
    print("=" * 62)
    print(" Adres        : " + adres)
    print(" Veri klasörü : " + VERI)
    print(" Kullanıcı    : " + kullanici_adi())
    print("\n Bu pencereyi KAPATMAYIN. Programı kapatmak için bu pencereyi kapatın")
    print(" veya Ctrl+C yapın. Tarayıcı birazdan otomatik açılacak.")
    print("=" * 62)
    threading.Timer(1.0, lambda: webbrowser.open(adres)).start()
    threading.Thread(target=_gunluk_yedek_dongusu, daemon=True).start()
    try:
        sunucu.serve_forever()
    except KeyboardInterrupt:
        print("\nKapatılıyor...")


if __name__ == "__main__":
    main()
