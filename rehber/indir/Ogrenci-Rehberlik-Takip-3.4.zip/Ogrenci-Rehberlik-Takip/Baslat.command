#!/bin/bash
# Ogrenci Rehberlik Takip Sistemi - Mac / Linux baslatici
cd "$(dirname "$0")"

PYTHON_EXE=""

# 1) Once bu klasorun icindeki "python" adli tasinabilir Python'a bak
if [ -x "./python/bin/python3" ]; then
    PYTHON_EXE="./python/bin/python3"
fi

# 2) Yoksa sistemde kurulu "python3" komutuna bak
if [ -z "$PYTHON_EXE" ] && command -v python3 >/dev/null 2>&1; then
    PYTHON_EXE="python3"
fi

# 3) O da yoksa "python" komutuna bak (bazi sistemlerde python3 yerine boyle adlandirilir)
if [ -z "$PYTHON_EXE" ] && command -v python >/dev/null 2>&1; then
    PYTHON_EXE="python"
fi

if [ -z "$PYTHON_EXE" ]; then
    echo "================================================================"
    echo " HATA: Python bulunamadi."
    echo "================================================================"
    echo ""
    echo " Bu programin calismasi icin bilgisayarinizda Python 3 kurulu"
    echo " olmasi gerekir. Kurulum icin:"
    echo ""
    echo "   1. https://www.python.org/downloads/ adresine gidin"
    echo "   2. Mac icin indirilen .pkg dosyasini calistirip kurun"
    echo "      (Mac'lerde bazen Python zaten kuruludur - Terminal'de"
    echo "      'python3 --version' yazarak kontrol edebilirsiniz)"
    echo "   3. Kurulum bittikten sonra bu dosyaya tekrar cift tiklayin"
    echo ""
    echo "================================================================"
    read -p " Kapatmak icin Enter'a basin..." _
    exit 1
fi

# Masaustunde kisayol yoksa sessizce olustur (sadece macOS'ta calisir;
# basarisiz olursa program yine de normal calismaya devam eder).
if [ "$(uname)" = "Darwin" ] && [ ! -e "$HOME/Desktop/Ogrenci Rehberlik Takip.command" ]; then
    {
        ln -sf "$(pwd)/Baslat.command" "$HOME/Desktop/Ogrenci Rehberlik Takip.command"
        if [ -f "$(pwd)/simge.png" ]; then
            osascript -l JavaScript -e '
                ObjC.import("AppKit");
                var ws = $.NSWorkspace.sharedWorkspace;
                var icon = $.NSImage.alloc.initWithContentsOfFile("'"$(pwd)/simge.png"'");
                ws.setIconForFileOptions(icon, "'"$HOME/Desktop/Ogrenci Rehberlik Takip.command"'", 0);
            '
        fi
    } >/dev/null 2>&1 || true
fi

echo "Kullanilan Python: $PYTHON_EXE"
echo "Ogrenci Rehberlik Takip Sistemi baslatiliyor..."
echo ""

"$PYTHON_EXE" uygulama/sunucu.py

echo ""
echo "Sunucu kapandi."
read -p "Kapatmak icin Enter'a basin..." _
