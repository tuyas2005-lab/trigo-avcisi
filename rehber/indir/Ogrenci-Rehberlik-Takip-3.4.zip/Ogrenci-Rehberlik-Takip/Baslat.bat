@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title Ogrenci Rehberlik Takip Sistemi
cd /d "%~dp0"

rem Onceki calistirmalardan kalan gecici hata dosyalarini silmeyi dene
rem (basarisiz olsa bile sorun degil, asagida aciklaniyor).
del "%~dp0hata_*.tmp" >nul 2>nul

rem ONEMLI: hata ciktisi HER ZAMAN bu calistirmaya OZEL, benzersiz bir
rem dosya adina yazilir (sabit "hata.log" adina degil). Sebep: program
rem penceresi calisirken (sunucu acikken) pencere X ile kapatilirsa,
rem sabit adli bir hata dosyasi bos halde ortada kalabiliyor; hemen
rem ardindan bir sonraki acilista Windows/antivirus bu kucuk dosyayi kisa
rem bir sure tarayip kilitleyebiliyor, bu da cmd.exe'nin ayni dosyayi
rem yeniden acmaya calistigi anda "dosya baska bir islem tarafindan
rem kullaniliyor" hatasina yol aciyordu. Her calistirmada yeni/rastgele
rem bir dosya adi kullanildiginda ise, o dosya hicbir zaman daha once var
rem olmadigi icin kilitli olma ihtimali kalmiyor.
set "GECICI_HATA=%~dp0hata_%RANDOM%%RANDOM%.tmp"

set "PYTHON_EXE="

rem 1) Once bu klasorun icindeki "python" adli tasinabilir Python'a bak
if exist "%~dp0python\python.exe" (
    set "PYTHON_EXE=%~dp0python\python.exe"
)

rem 2) Yoksa sistemde kurulu "python" komutuna bak
if not defined PYTHON_EXE (
    where python >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=python"
)

rem 3) O da yoksa "py" baslaticisina bak (Windows'un resmi Python baslaticisi)
if not defined PYTHON_EXE (
    where py >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=py"
)

if not defined PYTHON_EXE (
    echo ================================================================
    echo  HATA: Python bulunamadi.
    echo ================================================================
    echo.
    echo  Bu programin calismasi icin bilgisayarinizda Python 3 kurulu
    echo  olmasi gerekir. Kurulum icin:
    echo.
    echo    1. https://www.python.org/downloads/ adresine gidin
    echo    2. "Download Python" butonuna tiklayip indirin
    echo    3. Kurulum sirasinda "Add python.exe to PATH" kutucugunu
    echo       MUTLAKA isaretleyin
    echo    4. Kurulum bittikten sonra Baslat.bat dosyasina tekrar
    echo       cift tiklayin
    echo.
    echo  Kurum bilgisayariniz varsa ve kurulum yetkiniz yoksa, BT
    echo  biriminden "Python 3 kurulumu" talep edebilirsiniz. Program
    echo  internete cikmaz, veri disari gondermez, sadece kendi
    echo  bilgisayarinizda calisir.
    echo ================================================================
    pause
    exit /b 1
)

call :KISAYOL_OLUSTUR

echo Kullanilan Python: %PYTHON_EXE%
echo Ogrenci Rehberlik Takip Sistemi baslatiliyor...
echo.

"%PYTHON_EXE%" uygulama\sunucu.py 2>"%GECICI_HATA%"

echo.
echo Sunucu kapandi.

if exist "%GECICI_HATA%" (
    for %%A in ("%GECICI_HATA%") do set HATA_BOYUTU=%%~zA
    if not "!HATA_BOYUTU!"=="0" (
        echo.
        echo ================ HATA MESAJI ================
        type "%GECICI_HATA%"
        echo ===============================================
        echo Bu mesaji oldugu gibi kopyalayip destek alacaginiz
        echo kisiye iletebilirsiniz. (Ayni mesaj bu klasordeki
        echo hata.log dosyasina da kaydedildi.)
        copy /y "%GECICI_HATA%" "%~dp0hata.log" >nul 2>nul
    )
    del "%GECICI_HATA%" >nul 2>nul
)

pause
goto :eof

:KISAYOL_OLUSTUR
rem Masaustunde kisayol yoksa sessizce olustur (ikon: simge.ico).
rem [Environment]::GetFolderPath('Desktop') kullanilir; boylece OneDrive
rem tarafindan yonlendirilmis bir Masaustu olsa bile kisayol kullanicinin
rem GERCEKTEN gordugu konuma eklenir. Kisayol zaten varsa tekrar
rem olusturulmaz. Basarisiz olursa program yine de normal calismaya devam
rem eder, hata gostermez. (Not: "-ExecutionPolicy Bypass -File <script>"
rem kalibi kimi antivirus yazilimlari tarafindan supheli kabul edilebildigi
rem icin bilerek kullanilmiyor; tek satirlik "-Command" kullanilir.)
powershell -NoProfile -WindowStyle Hidden -Command "$d=[Environment]::GetFolderPath('Desktop'); $p=Join-Path $d 'Ogrenci Rehberlik Takip.lnk'; if (-not (Test-Path -LiteralPath $p)) { $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%~dp0Baslat.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0simge.ico'; $s.Description='Ogrenci Rehberlik Takip Sistemi'; $s.Save() }" >nul 2>nul
goto :eof
