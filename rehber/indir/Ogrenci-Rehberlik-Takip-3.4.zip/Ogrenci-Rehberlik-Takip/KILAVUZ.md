# Öğrenci Rehberlik Takip Sistemi — Kurulum ve Kullanım Kılavuzu

Sürüm 1.1 · Rehberlik Servisi

---

## 1. Bu program ne yapar?

- Öğrenci ve veli görüşmelerinizi tek yerde tutar: görüşme tarihi, konusu, başvurma şekli, notlar, sonuç/öneri — resmi MEB form alanlarının tamamı.
- Görüşme notlarını **sesli olarak** dikte edebilirsiniz; yazdığınız metin doğrudan resmi görüşme formunu doldurur.
- Görüşmeleri, resmi **"Öğrenci Görüşme Formu"** veya **"Veli Görüşme Formu"** olarak, gerçek MEB form görünümünde **yazdırabilirsiniz**.
- **Gündem:** yaklaşan zamanlamaları (takip randevuları, hatırlatmalar) gösterir.
- **Takvim:** ayın tamamını görüşme ve zamanlamalarla birlikte gösterir.
- **Gösterge paneli:** görüşme sayıları, haftalık/aylık dağılım, en çok görüşülen öğrenciler — grafiklerle.
- **Raporlar:** tarih/sınıf/konu/tür bazında filtrelenebilir istatistikler; PDF olarak dışa aktarılabilir.
- Öğrenci listesini e-Okul'dan aldığınız **Sınıf Listesi** dosyasıyla (PDF, Excel veya CSV) toplu olarak yükleyebilirsiniz — tek tek elle girmenize gerek kalmaz.
- Her öğrenciye özel **etiketler** (örn. "Yakın Takip", "Yönlendirme Yapıldı") ekleyebilir, bunlara göre filtreleyebilirsiniz.

---

## 2. Nasıl çalışır? (önemli)

Program **kendi bilgisayarınızda** çalışır, ayrı bir sunucuya ihtiyaç duymaz.

- `Baslat` dosyasına çift tıkladığınızda program bilgisayarınızda başlar ve tarayıcınızda otomatik olarak açılır (`http://localhost:8090` gibi bir adreste).
- Veri, programın yanındaki `veri` klasöründe, **kendi bilgisayarınızda** tutulur. Hiçbir yere yüklenmez.
- Programı kapatmak için açılan siyah/koyu pencereyi kapatın veya içinde Ctrl+C yapın. Pencere kapanınca program durur.
- `Baslat` dosyasına birden fazla kez tıklarsanız ikinci bir kopya açılmaz; tarayıcı zaten açık olan pencereye yönlendirilir.

**Veri gizliliği:** Görüşme kayıtlarınız, öğrenci bilgileriniz ve notlarınız **internete gönderilmez** — hepsi kendi bilgisayarınızda kalır. Tek istisna **sesli yazım** özelliğidir: bu özellik Chrome/Edge tarayıcısının kendi ses tanıma servisini kullanır, bu nedenle sesli yazım sırasında söylediğiniz metin o servise gönderilir ve internet bağlantısı gerektirir. İstemezseniz notları elle yazabilirsiniz; sesli yazım tamamen isteğe bağlıdır.

---

## 3. Kurulum

### Adım 1 — Klasörü yerleştirin

`Ogrenci-Rehberlik-Takip` klasörünün tamamını istediğiniz bir yere kopyalayın.

**⚠️ Önemli — OneDrive'a koymayın:** Bu klasörü **OneDrive tarafından bulut ile eşitlenen (senkronize edilen)** bir konuma koymayın. Windows'ta "Masaüstü" ve "Belgelerim" klasörleri, "OneDrive - Bilgisayarımı Yedekle" özelliği açıksa, siz farkında olmadan OneDrive'a yönlendirilmiş olabilir. Program çalışırken verinizi sürekli küçük dosyalara yazar; OneDrive bu dosyaları aynı anda buluta yüklemeye çalışırsa dosyaları kilitleyip "dosya başka bir işlem tarafından kullanılıyor" hatasına, hatta klasörün silinememesine yol açabilir.

Klasörünüzün OneDrive'da olup olmadığını anlamak için: klasöre sağ tıklayın — bir OneDrive simgesi (bulut/senkron ikonu) görüyorsanız veya "Kullanılabilirlik durumu" satırında "Eşitleme bekliyor/beklemede" yazıyorsa, OneDrive içindedir. Bu durumda klasörü **OneDrive dışında, tamamen yerel bir konuma** taşıyın — örneğin doğrudan `C:\` altında `C:\OgrenciRehberlikTakip` gibi bir klasöre, ya da OneDrive simgesi OLMAYAN bir "Masaüstü"/"Belgelerim" konumuna. Emin değilseniz en güvenlisi `C:\` sürücüsünün köküne bir klasör açıp oraya koymaktır.

Klasör içindeki yapı:

| Klasör / dosya | İçeriği |
|---|---|
| `Baslat.bat` | Windows'ta programı başlatan dosya |
| `Baslat.command` | Mac'te programı başlatan dosya |
| `simge.ico`, `simge.png` | Masaüstü kısayolunun simgesi — **silmeyin** |
| `uygulama/` | Programın kendisi — **elle değiştirmeyin** |
| `veri/ogrenciler/` | Öğrenci ve görüşme kayıtları (her öğrenci bir dosya) |
| `veri/yedek/` | Silinen öğrenci kayıtlarının yedeği |
| `veri/ayarlar.json`, `etiketler.json`, `siniflar.json` | Ayarlar, etiketler, sınıf/şube listesi |
| `veri/lisans.json` | Kopyalamaya karşı etkinleştirme kaydı (bkz. Adım 4) — **silmeyin** |

İlk çalıştırmada `veri` klasörü otomatik oluşturulur; şu an klasörde görünmüyorsa normaldir.

### Adım 2 — Python'un çalıştığından emin olun

Program Python ile çalışır. İki ihtimal var:

**A) Bilgisayarda Python zaten kurulu (çoğu Mac'te ve birçok Windows bilgisayarda böyledir):**
`Baslat.bat` (Windows) veya `Baslat.command` (Mac) dosyasına çift tıklayın. Bir pencere açılır ve tarayıcı kendiliğinden gelir. Bu pencereyi kapatmayın — kapatınca program durur.

**B) Python kurulu değil:**

1. [python.org/downloads](https://www.python.org/downloads/) adresine gidin.
2. "Download Python" butonuna tıklayıp indirin (Python 3.9 veya üstü).
3. **Windows'ta kurulum ekranında "Add python.exe to PATH" kutucuğunu mutlaka işaretleyin.**
4. Kurulum bittikten sonra `Baslat` dosyasına tekrar çift tıklayın.

Mac'te Terminal'de `python3 --version` yazarak Python'un kurulu olup olmadığını kontrol edebilirsiniz.

**Mac'te "geliştirici doğrulanamadı" uyarısı çıkarsa:** `Baslat.command` dosyasına sağ tıklayıp **Aç**'ı seçin, açılan uyarıda tekrar **Aç**'a tıklayın. Bu, yalnızca ilk çalıştırmada bir kez gerekir.

### Adım 3 — Masaüstü kısayolu

`Baslat.bat` (Windows) veya `Baslat.command` (Mac) dosyasını ilk kez çalıştırdığınızda, programın kendi simgesiyle bir kısayol **otomatik olarak masaüstünüze eklenir** ("Ogrenci Rehberlik Takip"). Bir dahaki sefer programı bu kısayoldan açabilirsiniz, klasörü tekrar bulmanıza gerek kalmaz. (Windows'ta bu işlem sessizce yapılır; kısayol zaten varsa tekrar oluşturulmaz. Mac'te bazı sistem sürümlerinde simge otomatik uygulanamayabilir — kısayol yine de çalışır, sadece varsayılan simgeyle görünebilir.)

### Adım 4 — İlk etkinleştirme (kopyalamaya karşı şifre)

Program ilk kez tarayıcıda açıldığında sizden bir **"Kopyalamaya Karşı Şifre"** belirlemenizi ister. Bu **bir giriş şifresi değildir** — bu şifreyi her açılışta girmeniz gerekmez, programı hiçbir şekilde yavaşlatmaz. Tek amacı, program klasörünüz izinsiz olarak **başka bir bilgisayara kopyalanırsa** orada kullanılmasını engellemektir: klasör başka bir bilgisayara kopyalanırsa program orada **anında kilitlenir** ve doğru şifre girilmeden hiçbir öğrenci verisi görüntülenemez.

Nasıl belirlerseniz belirleyin, bu bilgisayarda program bundan sonra hep serbestçe çalışır. Belirlediğiniz şifreyi unutmamak için bir yere not edin; şifre daha sonra **Ayarlar → Lisans / Etkinleştirme** bölümünden değiştirilebilir.

**Yasal dayanak:** Bu koruma, 6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında öğrenci ve veli kişisel verilerinin yetkisiz kişilerce erişilmesini veya kopyalanmasını önlemek amacıyla uygulanmaktadır.

---

## 4. İlk kullanım

Program ilk açıldığında içinde **1 adet örnek öğrenci kaydı** vardır: **"ÖRNEK ÖĞRENCİ"**. Bu gerçek bir öğrenci değildir; programın nasıl çalıştığını görmeniz, örnek görüşme ve hatırlatma kayıtlarını incelemeniz içindir.

Gerçek veri girmeye başlamadan önce bu kaydı silin: öğrenciler listesinden "ÖRNEK ÖĞRENCİ" dosyasını açın, sağ üstteki **"Sil"** butonuna tıklayın.

### Öğrenci listesini yükleme

Elle tek tek girmek yerine, e-Okul'dan aldığınız **Sınıf Listesi** dosyasını kullanın:

1. e-Okul'da ilgili sınıfın/okulun **"Sınıf Listesi"** raporunu PDF, Excel (.xlsx) veya CSV olarak indirin.
2. Programda **"Öğrenci Kayıt"** ekranına girin, **"Toplu Liste Yükle"** sekmesinde dosyayı seçin.
3. Program dosyadaki öğrencileri okuyup bir önizleme gösterir (kaç yeni, kaç güncellenecek). Kontrol edip onaylayın.
4. Eşleştirme **okul numarasına** göre yapılır — aynı listeyi tekrar yüklerseniz (örn. yıl başında güncellenmiş bir liste), mevcut öğrencilerin görüşme geçmişi **korunur**, sadece sınıf/şube bilgisi güncellenir. Yeni öğrenci eklemek veya ayrılan öğrenciyi işaretlemek için güvenle tekrar tekrar kullanabilirsiniz.

Tek bir öğrenciyi elle eklemek isterseniz aynı ekranda **"Tek Öğrenci Ekle"** sekmesini kullanın.

### Bir görüşme kaydederken

- Öğrenci dosyasını açın → **"+ Yeni Görüşme"** → Öğrenci veya Veli görüşmesi seçin.
- Formda konu, başvurma şekli gibi seçenekleri işaretleyin; not alanına **mikrofon simgesine tıklayıp konuşarak** veya elle yazın.
- **"Kaydet"** ile görüşme öğrencinin dosyasına eklenir; **"Yazdır"** ile resmi form görünümünde (gerçek MEB başlığıyla) yazdırabilirsiniz.
- Kaydedilen her görüşmeyi daha sonra dosya sayfasındaki **Görüşme Geçmişi** bölümünden açıp düzenleyebilir, tekrar yazdırabilir veya silebilirsiniz.

### Zamanlama ve etiketler

- **Zamanlama:** bir öğrenciyle ileride tekrar görüşmeniz gerekiyorsa dosyasına zamanlama ekleyin — Gündem ve Takvim ekranlarında otomatik görünür.
- **Etiketler:** Ayarlar ekranından kendi etiketlerinizi tanımlayıp (renk seçerek) öğrenci dosyalarına ekleyebilir, Öğrenciler listesinde bu etikete göre filtreleyebilirsiniz.

---

### Raporlar ve dönem sonu faaliyet raporu (sürüm 1.4)

- **Raporlar** ekranının üstünde, seçtiğiniz döneme göre görüşme sayıları ve **önceki döneme göre değişim** (▲/▼ yüzde) görünür.
- **Kapsama**: her sınıfta öğrencilerin yüzde kaçıyla (veya velisiyle) en az bir kez görüşüldüğü.
- **Takip Uyarı Listesi**: etiketi olan (Kaynaştırma, Devamsızlık Riski vb.) ama son 30 gündür görüşülmeyen öğrenciler. Panel'de de ilk 6'sı görünür. Öğrenci adı içerdiği için yazdırılan rapora eklenmez.
- **Başvuru şekli** ve **yapılan çalışma türü** dağılımları, **katılınan toplantılar** (sayı ve süre) tabloları.
- **Dönem Sonu Faaliyet Raporu** düğmesi: kapak sayfası, özet, tablolar ve imza alanı olan, idareye sunulabilir bir rapor açar. "Genel Değerlendirme" bölümüne tıklayıp yazabilirsiniz; ardından "Yazdır / PDF olarak kaydet". Bu raporda öğrenci adı yer almaz.

## 5. Veri güvenliği ve yedekleme

- Tüm veriniz `veri` klasöründedir. Programı silseniz bile `veri` klasörünü sakladığınız sürece kayıtlarınız güvendedir.
- Bir öğrenciyi silerseniz kaydı tamamen yok olmaz, `veri/yedek/` klasörüne taşınır — yanlışlıkla sildiyseniz o klasörden dosyayı bulup `veri/ogrenciler/` klasörüne geri koyabilirsiniz (program kapalıyken yapın).
- **Öneri:** `veri` klasörünü arada bir (örn. haftada bir) bir USB bellek, harici disk veya bulut yedekleme klasörüne kopyalayın. Bilgisayarınızda bir sorun olursa kayıtlarınızı kaybetmezsiniz.
- Programı ve verinizi başka bir bilgisayara taşımak isterseniz, `Ogrenci-Rehberlik-Takip` klasörünün tamamını (içindeki `veri` klasörüyle birlikte) kopyalamanız yeterlidir.

---

## 6. Sorun giderme

**"Python bulunamadı" hatası:** Adım 2'deki Python kurulumunu yapın; Windows'ta "Add python.exe to PATH" kutucuğunu işaretlediğinizden emin olun.

**Tarayıcı otomatik açılmadı:** `Baslat` penceresinde yazan adresi (örn. `http://localhost:8090/`) elle tarayıcınıza yazıp Enter'a basabilirsiniz.

**Sesli yazım çalışmıyor / "desteklenmiyor" diyor:** Sesli yazım yalnızca Chrome veya Edge tarayıcısında çalışır (Firefox ve Safari desteklemez). Ayrıca tarayıcının mikrofon izni istediğinde "İzin Ver" demeniz ve internet bağlantınızın olması gerekir. Sesli yazım olmadan da not alanına elle yazabilirsiniz.

**e-Okul listesi doğru okunmadı:** Dosyanın gerçekten e-Okul'un "Sınıf Listesi" raporu olduğundan emin olun (başka bir rapor türü farklı bir sayfa düzeni kullanabilir). PDF çalışmazsa aynı raporu Excel (.xlsx) veya CSV olarak indirip tekrar deneyin.

**"Program zaten açık" mesajı çıktı:** Program zaten arka planda çalışıyor demektir — bu normaldir, tarayıcı otomatik olarak o pencereye yönlendirilir. İkinci pencereyi kapatabilirsiniz.

**Yazdırırken sayfanın üstünde tarih/başlık, altında site adresi/sayfa numarası çıkıyor:** Bunlar formun bir parçası değildir — tarayıcının (Chrome/Edge) yazdırma penceresine otomatik eklediği "üstbilgi ve altbilgi" özelliğidir; bir web sayfası bunu kod ile kapatamaz, sadece yazdırma penceresinden kapatılabilir. Yazdır'a bastığınızda açılan pencerede **"Diğer ayarlar"** (veya "Daha fazla ayar") bölümünü açın, **"Üstbilgiler ve altbilgiler"** kutucuğunun işaretini kaldırın ve öyle yazdırın. Bunu bir kez yaptığınızda tarayıcı bu tercihi hatırlar; bir sonraki yazdırmalarınızda tekrar işaretli gelmez. (Not: form zaten tek A4 sayfasına sığacak şekilde tasarlanmıştır — pencerenin sağ alt köşesindeki "1/1" ibaresi bunu gösterir; üstbilgi/altbilgi sayfa sayısını artırmaz, sadece görünümü kalabalıklaştırır.)

**"Dosya başka bir işlem tarafından kullanılıyor" hatası, veya klasör silinmiyor / "Kullanılabilirlik durumu: Eşitleme beklemede" mesajı çıkıyor:** Bu, klasörünüzün **OneDrive** ile eşitlenen bir konumda olduğunun işaretidir (bkz. "Adım 1" — genellikle "Masaüstü" veya "Belgelerim" bilmeden OneDrive'a yönlendirilmiş olur). Çözüm:

1. Görev çubuğunda, saatin yanındaki OneDrive (bulut) simgesine sağ tıklayın → **"Duraklat" / "İşlemi Duraklat"** deyip birkaç saat seçin. Bu, OneDrive'ın dosyaları kilitlemesini geçici olarak durdurur.
2. Şimdi klasörü silmeyi/taşımayı tekrar deneyin — genellikle hemen çalışır. Olmazsa bilgisayarı yeniden başlatıp tekrar deneyin.
3. Kalıcı çözüm için programı **OneDrive dışında** bir klasöre taşıyın (örn. `C:\OgrenciRehberlikTakip`) ve bundan sonra hep oradan çalıştırın. OneDrive'ı tekrar aktif hale getirebilirsiniz — sorun yalnızca bu programın klasörünün OneDrive içinde olmasından kaynaklanıyordu.

**Siyah pencere bir anlığına açılıp hemen kapanıyor, hiçbir yazı okuyamıyorum:** Bu genellikle `Baslat.bat` bir hataya çarpıp anında kapandığı, ama hatayı görecek zamanınız olmadığı anlamına gelir. Hatayı görmek için:

1. Klavyeden Windows tuşuna basıp **"cmd"** yazın, çıkan **"Komut İstemi"**na tıklayın (siyah bir pencere açılır, bu sefer kapanmaz).
2. Açılan pencereye `cd ` yazıp (sonuna boşluk bırakın), sonra `Ogrenci-Rehberlik-Takip` klasörünü bu pencerenin içine **sürükleyip bırakın** (klasörün tam yolu otomatik yazılır), Enter'a basın.
3. Şimdi `Baslat.bat` yazıp Enter'a basın. Bu sefer pencere kapanmayacağı için hatayı okuyup bana (veya destek alacağınız kişiye) aynen iletebilirsiniz.

Bu şekilde bir antivirüs/Windows Defender uyarısı görürseniz (özellikle "engellendi", "tehdit" gibi kelimeler geçiyorsa), programın klasörünü antivirüs yazılımınızda "istisna" (exception/allow) listesine eklemeniz gerekebilir — bu programın internete çıkmadığını, dosyalarınızı dışarı göndermediğini unutmayın, yalnızca kendi bilgisayarınızda masaüstü kısayolu oluşturmaya çalışır.

**"Bu Bilgisayarda Kilitli" ekranı çıktı:** Bu, program klasörünün **başka bir bilgisayara kopyalandığının** işaretidir (örn. yeni bir bilgisayara geçtiniz, ya da klasör bir yedekten farklı bir makineye açıldı). Kendi bilgisayarınızda ilk kurulumda belirlediğiniz **kopyalamaya karşı şifreyi** girerek bu bilgisayarı yeniden etkinleştirebilirsiniz; şifre doğru girildiğinde program bu bilgisayarda normal şekilde çalışmaya devam eder. Aynı klasörü gerçekten iki farklı bilgisayarda (örn. eski ve yeni bilgisayarınızda) kullanacaksanız, hangisini kullanıyorsanız o an sadece o bilgisayarı etkinleştirin.

**Kopyalamaya karşı şifreyi unuttum:** Program bu şifreyi geri getiremez (şifre okunabilir şekilde saklanmaz, sadece doğrulanabilir). Eğer program hâlâ orijinal (yetkili) bilgisayarınızda açılıyorsa — yani kilit ekranı görmüyorsanız — sorun yok: **Ayarlar → Lisans / Etkinleştirme** bölümünden mevcut şifrenizi bilmeden yeni bir şifre belirleyemezsiniz, ama o bilgisayar zaten yetkili olduğu için şifreye hiç ihtiyacınız kalmaz. Kilit ekranıyla karşılaşıp şifreyi de hatırlamıyorsanız, `veri/lisans.json` dosyasını (program kapalıyken) silebilirsiniz — bu, etkinleştirme kaydını sıfırlar ve program bir sonraki açılışta yeni bir şifre belirlemenizi ister; öğrenci/görüşme verileriniz bundan etkilenmez, sadece bu şifre sıfırlanır.

**Başka bir hata mesajı çıkarsa:** `Baslat.bat` çalıştırdığınızda oluşan `hata.log` dosyasındaki metni olduğu gibi kopyalayıp destek alacağınız kişiye iletebilirsiniz.

---

Kolay gelsin.

## Okul logosu

Ayarlar → Okul ve Öğretmen → **Okul Logosu** bölümünden "Logo Seç…" ile okulunuzun logosunu yükleyin (PNG, JPG veya WEBP; en iyisi kare ve arka planı şeffaf PNG). Logo şu yerlerde görünür:

- Öğrenci ve veli görüşme formlarının başlığında, MEB başlığının solunda (çıktı yine tek sayfa)
- Dönem sonu faaliyet raporunun kapak sayfasında
- Raporlar sayfasının yazdırma çıktısında, okul adının yanında
- Sol menünün en üstünde (menü daraltıldığında da)

Logo `veri/okul-logo.png` dosyasında saklanır; internete gönderilmez, program güncellemelerinde silinmez. "Logoyu Kaldır" ile kaldırılabilir.

## Görünüm: açık / koyu tema ve cam kartlar (sürüm 1.6–1.7)

Ayarlar → **Görünüm** sekmesinden "Açık", "Koyu" veya "Bilgisayara göre" (Windows'un açık/koyu ayarını izler) seçilir; seçim hemen uygulanır ve hatırlanır. Resmi görüşme formları ekranda da beyaz kâğıt görünümünde kalır; yazdırılan her şey her zaman açık renklidir.

Geliştirici notu: `web/koyu.css` otomatik üretilir. `stil.css` veya `tasarim.css` değiştiğinde `python gelistirme/koyu_tema_uret.py` çalıştırın (tinycss2 gerekir); elle ayarlar `gelistirme/koyu-elle.css` dosyasındadır.

## Sürüm 1.8 yenilikleri

- **Görüşme konusuna göre süzme:** Öğrenciler ekranında "Görüşme Konusu" seçilince o konuda (öğrenci veya veli görüşmesinde) görüşülen bütün öğrenciler listelenir; görüşme sütununda o konudaki görüşme sayısı da yazar.
- **Toplu form çıktısı:** Ayarlar → Toplu Çıktı. Tarih aralığı (isteğe bağlı tür, sınıf, konu) seçilir, "Çıktıyı Hazırla" ile her görüşme formu ayrı A4 sayfası olarak açılır; Yazdır penceresinden yazıcıya ya da tek PDF dosyasına alınabilir.
- **Dönem sonu faaliyet raporu:** "Görüşülen farklı öğrenci" satırı kaldırıldı; "Katılınan toplantı" ifadesi "Yapılan toplantı" oldu.

## Sürüm 1.9 — Sınıf etkinliği çizelgesini dosyadan ekleme

Sınıf Etkinliği ekranında **"Çizelgeden Toplu Ekle"** bölümüne rehberlik dersi çizelgenizi (tarih, ders saati, sınıf, sınıf öğretmeni sütunları olan tablo) sürükleyin. Desteklenen dosyalar: Word (.docx), Word'den kaydedilmiş PDF, Excel (.xlsx), CSV. Program başlıktan etkinlik adını, satırlardan tarih/ders saati/sınıfı okur; önizlemede düzeltip "… sınıf etkinliğini ekle" ile kaydedersiniz. Ders saatlerinin başlama saatleri (1. ders 08:30 vb.) bir kez düzeltilince hatırlanır. Aynı etkinlik iki kez eklenmez. Sürüm 2.0'dan itibaren **fotoğraf (JPG/PNG)** da yüklenebilir: Windows 10/11'in kendi yazı tanıma özelliği kullanılır (internet ve ek kurulum gerekmez). Fotoğrafta okunamayan sınıflar önizlemede kırmızı gösterilir, elle düzeltilir. En iyi sonuç için kâğıdı düz, aydınlık ve tablonun tamamı görünecek şekilde çekin. Taranmış (resim) PDF yerine fotoğrafı JPG olarak yükleyin.

## Sürüm 2.1 — Etkinlik bildirimleri (alarm)

Program açıkken, saati girilmiş sınıf etkinliği, toplantı ve öğrenci hatırlatmalarının vakti yaklaşınca (varsayılan 10 dk önce) ekranın sağ üstünde bildirim kartı çıkar; vakti gelince zil çalar ve kart sallanır. Karttan **Tamamlandı**, **5 dk ertele**, **Aç** veya **✕ (bugün bir daha gösterme)** seçilebilir. Ayarlar → Görünüm ve Bildirim'den açılıp kapatılır, kaç dakika önce geleceği ve zil sesi ayarlanır; istenirse program arka plandayken Windows bildirimi de gösterilir. Başlangıçtan 1 saat sonrasına kadar gösterilir. İnternet gerekmez.

## Sürüm 2.2 — Renkli dönem sonu faaliyet raporu

Faaliyet raporu renkli ve kabartmalı (3B) görünüme geçti: renkli kapak şeridi, her bölüm için renkli numaralı başlık, 3B özet kartları, yuvarlak köşeli gölgeli tablolar, sınıf kapsamasında renkli rozetler (yeşil ≥%70, turuncu %40–69, kırmızı <%40). Her bölüm başlığı tablosuyla aynı sayfada kalır. Renkler yazdırırken otomatik basılır.

## Sürüm 2.3 — Otomatik veri yedekleme

Program açık olduğu her gün bütün veriler (öğrenciler, görüşmeler, etkinlikler, toplantılar, ayarlar, logo) `veri/yedekler/` klasörüne tek bir zip olarak yedeklenir. Ayarlar → **Yedekler** sekmesinden: "Şimdi Yedekle", otomatik yedeklerin kaç gün saklanacağı (elle alınanlar siz silene kadar kalır), isteğe bağlı **ek yedek klasörü** (USB bellek / başka disk) ve yedek listesi. Listede her yedek **İndir** ile zip olarak alınabilir, **Bu tarihe geri dön** ile o güne dönülür. Geri dönmeden önce o anki durum "Geri dönüş öncesi" yedeği olarak saklanır; yani geri dönüş de geri alınabilir. Lisans bilgisi geri dönüşten etkilenmez.

## Sürüm 2.4 — Görüşme saati

Öğrenci ve veli görüşme formlarında "Görüşme Tarihi"nin altında **Görüşme Saati** var (yeni görüşmede o anki saat gelir, tarih gibi değiştirilebilir; rakamları yazmanız yeterli, iki nokta kendiliğinden konur). Saat; formun çıktısında, toplu çıktıda, öğrenci dosyasındaki görüşme listesinde, Gündem'de ve Takvim'de (haftalık görünümde ilgili saat satırında, aylık görünümde saat sırasıyla) görünür. Saati girilmemiş eski görüşmeler takvimde "Tüm gün" satırında kalır; formu açıp saat ekleyip kaydedince yerine oturur. Ayrıca etkinlik bildirim kartları artık sayfanın araç tuşlarının altında çıkar ve 15 saniye sonra küçük bir zil rozetine dönüşür (üzerine gelince açılır).

## Sürüm 2.5 — Görüşme formunda seçim kolaylığı

Formdaki çoktan seçmeli kutularda (Başvurma Şekli, Görüşme Konusu, Yapılan Çalışma, Kurum) fareyle üzerine gelinen seçenek büyür ve gölgelenir; işaretlenen seçenekler kalın yazı ve açık yeşil zeminle vurgulanır. Bu vurgu yalnızca ekrandadır, çıktı resmi formdaki gibi sade basılır. Tarih/saat kutusu başlık alanına sığacak şekilde sıkılaştırıldı.

## Sürüm 2.6–2.7 — Panel özet kutuları

Panelin üst satırında 4 kutu var:
- **Bugünkü Görüşme:** bugünkü öğrenci · veli görüşmeleri; altında bekleyen izleme etiketi (tıklayınca Gündem açılır).
- **Bu Ay Görüşme:** bu ayki görüşmeler, öğrenci · veli dağılımı ve geçen aya göre değişim.
- **Toplam Görüşme:** içinde bulunulan eğitim yılında (1 Eylül'den bugüne) yapılan tüm görüşmeler; altında öğrenci ve veli görüşmesi sayıları ve oran çubuğu.
- **Görüşülen Öğrenci:** kendisiyle veya velisiyle en az bir kez görüşülen FARKLI öğrenci sayısı / toplam öğrenci ve kapsama yüzdesi. Aynı öğrenciyle yapılan tekrar görüşmeler burada bir kez sayılır; bu yüzden bu sayı öğrenci görüşmesi sayısından farklı olabilir. Kutunun altında bu sayı ikiye ayrılır: **Kendisiyle** (en az bir öğrenci görüşmesi yapılan öğrenci) ve **Yalnız velisiyle** (kendisiyle hiç görüşülmemiş, yalnızca velisiyle görüşülmüş öğrenci). Bu iki sayının toplamı Görüşülen Öğrenci sayısına eşittir.

## Sürüm 2.9 — Okul Raporu (birden çok rehber öğretmen)

Sol menüde **Analiz → Okul Raporu** bölümü var. Okulda birden çok rehber öğretmen varsa, herkes kendi bilgisayarında kendi öğrencileriyle çalışır; okul geneli faaliyet raporu ise şöyle hazırlanır:

1. **Her öğretmen** Okul Raporu sayfasında **"Paketimi indir"** düğmesine basar. İndirilen `.json` dosyasını başkan öğretmene WhatsApp ya da e-posta ile gönderir. Dosyada öğrenci adı, numarası, görüşme notu, özet, telefon ya da adres **yoktur**; yalnızca tarih, sınıf, görüşme türü, konu, başvuru şekli, yapılan çalışma, yönlendirme, sınıf etkinlikleri ve toplantılar vardır. Dönem seçilmez; her ay yeni paket gönderilebilir, yenisi eskisinin yerine geçer.
2. **Başkan öğretmen** gelen dosyaları "Gelen Paketler" alanına sürükler. Kendi verileri otomatik olarak dahil edilir (istenirse kapatılabilir). Elle değiştirilmiş ya da bozuk dosyalar kabul edilmez; 35 günden eski paketler için uyarı çıkar.
3. Başkan dönemi seçer (Bu eğitim yılı / Bu ay / Geçen ay ya da istediği tarihler) ve **"Okul Faaliyet Raporunu Aç"** ile raporu alır.

Rapor, dönem sonu faaliyet raporuyla aynı tasarımdadır. Sütunlar **sınıf düzeyleridir** (Ana sınıfı, 1., 2., 3., 4. sınıf); şube ve öğrenci adı yer almaz. Raporda öğretmen adı yer almaz. Ek olarak: aylara göre görüşme grafiği, sınıf düzeylerinin öne çıkan konuları, 100 öğrenciye düşen görüşme, öğrenci başına görüşme, veli görüşmesi oranı, öğrenci ihtiyaç etiketleri ve veri kaynaklarının tarih notu. 7. bölümü (Genel Değerlendirme) başkan doldurur.

Başkan her yıl değişebilir: bu bölüm her programda vardır; yeni başkan paketleri kendi programına ekler.

### Sürüm 3.0
- Okul raporunda ayrı "Kurumlara Yönlendirmeler" bölümü kaldırıldı (yönlendirilen öğrenci sayısı 1. bölümdeki tabloda var). Bölümler 1–8 oldu.
- 1. bölümdeki tablodan "Gerçekleştirilen sınıf etkinliği" satırı kaldırıldı (ayrıntısı 6. bölümde).
- Ek analizler raporda turuncu **"★ Ek analiz"** rozetiyle işaretlendi: aylık grafik, öne çıkan konular, ihtiyaç etiketleri; tablolarda ★ işaretli sütun/satırlar (veli görüşmesi oranı, 100 öğrenciye düşen görüşme, öğrenci başına görüşme) ve renkli yoğunluk hücreleri.

### Sürüm 3.1
- Okul raporundan ayrı "Yapılan Toplantılar" bölümü kaldırıldı (toplam toplantı sayısı ve süresi 1. bölümde). Bölümler 1–7 oldu; raporda öğretmen adı yer almaz.
- Yıldız işaretleri kaldırıldı; "Sınıf Düzeylerinin Öne Çıkan Konuları" düzenli bir tabloya dönüştürüldü (her düzey bir satır, 1-2-3. sıradaki konu ve yüzde çubuğu).

### Sürüm 3.2
- Öğrenciler sayfasındaki "Etiket Filtrele" listesi ve öğrenci dosyasındaki "+ Etiket Ekle" listesi artık üstteki kutunun içinde kırpılmıyor; tamamı görünüyor.

## Sürüm 3.4 — Hakkında ve Kullanım Koşulları

- Program ücretsizdir. Kullanım koşulları program klasöründeki **KULLANIM-KOSULLARI.txt** dosyasında ve programda **Ayarlar → Hakkında** sekmesindedir.
- İlk kurulumda (Program Etkinleştirme ekranı) koşulların kabul edilmesi zorunludur. Daha önce kurulmuş programlarda, ilk açılışta koşulları gösteren bir onay penceresi çıkar; onaylanınca bir daha sorulmaz (koşullar değişirse yeniden sorulur).
- Ayarlar → Hakkında: program sürümü, lisans türü, geliştirici iletişim bilgileri, verilerin tutulduğu klasör ve üçüncü taraf bileşen lisansları.
