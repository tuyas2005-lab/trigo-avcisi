#!/bin/bash
# Ogrenci Rehberlik Takip Sistemi - Mac / Linux baslatici
cd "$(dirname "$0")"

PYTHON_EXE=""
SURUM_DENE='import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)'

# 1) Once bu klasorun icindeki "python" adli tasinabilir Python'a bak
if [ -x "./python/bin/python3" ] && "./python/bin/python3" -c "$SURUM_DENE" >/dev/null 2>&1; then
    PYTHON_EXE="./python/bin/python3"
fi

# 2) Yoksa sistemdeki "python3" komutunu dene. Not: yeni macOS surumlerinde
#    python3 ilk calistirildiginda "Komut satiri gelistirici araclari"
#    kurulumunu onerebilir; bu durumda asagidaki mesaj gosterilir.
if [ -z "$PYTHON_EXE" ] && command -v python3 >/dev/null 2>&1 && python3 -c "$SURUM_DENE" >/dev/null 2>&1; then
    PYTHON_EXE="python3"
fi

# 3) O da yoksa "python" komutunu dene
if [ -z "$PYTHON_EXE" ] && command -v python >/dev/null 2>&1 && python -c "$SURUM_DENE" >/dev/null 2>&1; then
    PYTHON_EXE="python"
fi

if [ -z "$PYTHON_EXE" ]; then
    echo "================================================================"
    echo " Programi calistirmak icin Python 3 gerekiyor (bir kez kurulur)."
    echo "================================================================"
    echo ""
    echo " Ekranda 'komut satiri gelistirici araclarini yuklemek ister"
    echo " misiniz?' penceresi acildiysa 'Yukle' deyin; kurulum bitince"
    echo " Baslat.command dosyasina tekrar cift tiklayin."
    echo ""
    echo " Boyle bir pencere acilmadiysa:"
    echo "   1. https://www.python.org/downloads/ adresine gidin"
    echo "   2. 'Download Python' ile Mac icin .pkg dosyasini indirin"
    echo "   3. Indirilen dosyayi acip kurulumu tamamlayin"
    echo "   4. Baslat.command dosyasina tekrar cift tiklayin"
    echo ""
    echo " Ayrintili anlatim: rehberliktakip.com"
    echo "================================================================"
    read -p " Kapatmak icin Enter'a basin..." _
    exit 1
fi

# Masaustunde kisayol yoksa sessizce olustur (sadece macOS'ta calisir;
# basarisiz olursa program yine de normal calismaya devam eder).
if [ "$(uname)" = "Darwin" ] && [ ! -e "$HOME/Desktop/Ogrenci Rehberlik Takip.command" ]; then
    {
        ln -sf "$(pwd)/Baslat.command" "$HOME/Desktop/Ogrenci Rehberlik Takip.command"
        if [ -f "$(pwd)/simge.png" ]; then
            osascript -l JavaScript -e '
                ObjC.import("AppKit");
                var ws = $.NSWorkspace.sharedWorkspace;
                var icon = $.NSImage.alloc.initWithContentsOfFile("'"$(pwd)/simge.png"'");
                ws.setIconForFileOptions(icon, "'"$HOME/Desktop/Ogrenci Rehberlik Takip.command"'", 0);
            '
        fi
    } >/dev/null 2>&1 || true
fi

echo "Kullanilan Python: $PYTHON_EXE"
echo "Ogrenci Rehberlik Takip Sistemi baslatiliyor..."
echo ""

"$PYTHON_EXE" uygulama/sunucu.py

echo ""
echo "Sunucu kapandi."
read -p "Kapatmak icin Enter'a basin..." _
