@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title Ogrenci Rehberlik Takip Sistemi
cd /d "%~dp0"

rem Onceki calistirmalardan kalan gecici hata dosyalarini silmeyi dene
rem (basarisiz olsa bile sorun degil, asagida aciklaniyor).
del "%~dp0hata_*.tmp" >nul 2>nul

rem ONEMLI: hata ciktisi HER ZAMAN bu calistirmaya OZEL, benzersiz bir
rem dosya adina yazilir (sabit "hata.log" adina degil). Sebep: program
rem penceresi calisirken (sunucu acikken) pencere X ile kapatilirsa,
rem sabit adli bir hata dosyasi bos halde ortada kalabiliyor; hemen
rem ardindan bir sonraki acilista Windows/antivirus bu kucuk dosyayi kisa
rem bir sure tarayip kilitleyebiliyor, bu da cmd.exe'nin ayni dosyayi
rem yeniden acmaya calistigi anda "dosya baska bir islem tarafindan
rem kullaniliyor" hatasina yol aciyordu. Her calistirmada yeni/rastgele
rem bir dosya adi kullanildiginda ise, o dosya hicbir zaman daha once var
rem olmadigi icin kilitli olma ihtimali kalmiyor.
set "GECICI_HATA=%~dp0hata_%RANDOM%%RANDOM%.tmp"

set "PYTHON_EXE="

rem 1) Once bu klasorun icindeki "python" klasorundeki tasinabilir Python'a bak
rem    (Windows paketinde hazir gelir; kurulum gerektirmez). Gercekten
rem    calistigi da denenir (cok eski Windows surumlerinde calismayabilir).
if exist "%~dp0python\python.exe" (
    "%~dp0python\python.exe" -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=%~dp0python\python.exe"
)

rem 2) Yoksa sistemde kurulu "python" komutunu dene. ONEMLI: Python kurulu
rem    olmayan Windows 10/11'de "python" adinda Microsoft Store kisayolu
rem    bulunur; bu kisayol gercek Python degildir. Bu yuzden komutun
rem    gercekten calisip calismadigi (ve surumun 3.8+ oldugu) denenir.
if not defined PYTHON_EXE (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=python"
)

rem 3) O da olmazsa "py" baslaticisini dene (Windows'un resmi Python baslaticisi)
if not defined PYTHON_EXE (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>nul
    if not errorlevel 1 set "PYTHON_EXE=py"
)

if not defined PYTHON_EXE (
    echo ================================================================
    echo  HATA: Programi calistiracak Python bulunamadi.
    echo ================================================================
    echo.
    echo  En kolay cozum: rehberliktakip.com adresinden "WINDOWS ICIN"
    echo  paketini indirin. Windows paketinin icinde Python hazir gelir,
    echo  hicbir sey kurmaniz gerekmez. Zip dosyasini bir klasore
    echo  cikartip Baslat.bat dosyasina cift tiklamaniz yeterlidir.
    echo.
    echo  Windows paketini kullandiginiz halde bu mesaji goruyorsaniz:
    echo    - Zip dosyasinin TAMAMINI bir klasore cikarttiginizdan emin
    echo      olun (zip'in icinden dogrudan calistirmayin).
    echo    - Bilgisayariniz 32 bit Windows ya da Windows 7/8 ise paket
    echo      calismaz; https://www.python.org/downloads/ adresinden
    echo      Python kurup kurulumda "Add python.exe to PATH" kutucugunu
    echo      isaretleyin, sonra Baslat.bat'a tekrar cift tiklayin.
    echo.
    echo  Program internete cikmaz, veri disari gondermez.
    echo ================================================================
    pause
    exit /b 1
)

call :KISAYOL_OLUSTUR

echo Kullanilan Python: %PYTHON_EXE%
echo Ogrenci Rehberlik Takip Sistemi baslatiliyor...
echo.

"%PYTHON_EXE%" uygulama\sunucu.py 2>"%GECICI_HATA%"

echo.
echo Sunucu kapandi.

if exist "%GECICI_HATA%" (
    for %%A in ("%GECICI_HATA%") do set HATA_BOYUTU=%%~zA
    if not "!HATA_BOYUTU!"=="0" (
        echo.
        echo ================ HATA MESAJI ================
        type "%GECICI_HATA%"
        echo ===============================================
        echo Bu mesaji oldugu gibi kopyalayip destek alacaginiz
        echo kisiye iletebilirsiniz. (Ayni mesaj bu klasordeki
        echo hata.log dosyasina da kaydedildi.)
        copy /y "%GECICI_HATA%" "%~dp0hata.log" >nul 2>nul
    )
    del "%GECICI_HATA%" >nul 2>nul
)

pause
goto :eof

:KISAYOL_OLUSTUR
rem Masaustunde kisayol yoksa sessizce olustur (ikon: simge.ico).
rem [Environment]::GetFolderPath('Desktop') kullanilir; boylece OneDrive
rem tarafindan yonlendirilmis bir Masaustu olsa bile kisayol kullanicinin
rem GERCEKTEN gordugu konuma eklenir. Kisayol zaten varsa tekrar
rem olusturulmaz. Basarisiz olursa program yine de normal calismaya devam
rem eder, hata gostermez. (Not: "-ExecutionPolicy Bypass -File <script>"
rem kalibi kimi antivirus yazilimlari tarafindan supheli kabul edilebildigi
rem icin bilerek kullanilmiyor; tek satirlik "-Command" kullanilir.)
powershell -NoProfile -WindowStyle Hidden -Command "$d=[Environment]::GetFolderPath('Desktop'); $p=Join-Path $d 'Ogrenci Rehberlik Takip.lnk'; if (-not (Test-Path -LiteralPath $p)) { $s=(New-Object -ComObject WScript.Shell).CreateShortcut($p); $s.TargetPath='%~dp0Baslat.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0simge.ico'; $s.Description='Ogrenci Rehberlik Takip Sistemi'; $s.Save() }" >nul 2>nul
goto :eof
